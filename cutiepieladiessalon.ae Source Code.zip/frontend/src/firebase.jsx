const VITE_FIREBASE_APP_API_KEY = import.meta.env.VITE_FIREBASE_APP_API_KEY;
const VITE_FIREBASE_APP_AUTH_DOMAIN = import.meta.env.VITE_FIREBASE_APP_AUTH_DOMAIN;
const VITE_FIREBASE_APP_PROJECT_ID = import.meta.env.VITE_FIREBASE_APP_PROJECT_ID;
const VITE_FIREBASE_APP_STORAGE_BUCKET = import.meta.env.VITE_FIREBASE_APP_STORAGE_BUCKET;
const VITE_FIREBASE_APP_MESSAGING_SENDER_ID = import.meta.env.VITE_FIREBASE_APP_MESSAGING_SENDER_ID;
const VITE_FIREBASE_APP_APP_ID = import.meta.env.VITE_FIREBASE_APP_APP_ID;

import { initializeApp } from "firebase/app";


// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBFl9kRLEG4Gwyq_lra4eRT8w0aLop29DE",
  authDomain: "cutiepie-fa2c8.firebaseapp.com",
  projectId: "cutiepie-fa2c8",
  storageBucket: "cutiepie-fa2c8.firebasestorage.app",
  messagingSenderId: "640899678532",
  appId: "1:640899678532:web:fcde43d547863d8489d711",
  measurementId: "G-1YEBDTZN3F"
};

// Initialize Firebase
export const firebaseApp = initializeApp(firebaseConfig);

