import React, { useEffect, useMemo, useState } from "react";
import { formatPrice } from "../../utils/formatPrice";
import { getTamaraInstallmentAmount } from "../../utils/tamara";

const TAMARA_WIDGET_SCRIPT_ID = "tamara-widget-v2-script";
const TAMARA_WIDGET_SCRIPT_URL = "https://cdn.tamara.co/widget-v2/tamara-widget.js";
const TAMARA_LOGO_URL = "https://cdn.tamara.co/assets/png/tamara-logo-badge-en.png";

const ensureTamaraWidgetScript = () => {
  if (typeof window === "undefined") {
    return Promise.resolve();
  }

  if (window.TamaraWidgetV2?.refresh) {
    return Promise.resolve();
  }

  if (window.__tamaraWidgetLoaderPromise) {
    return window.__tamaraWidgetLoaderPromise;
  }

  window.__tamaraWidgetLoaderPromise = new Promise((resolve, reject) => {
    const existingScript = document.getElementById(TAMARA_WIDGET_SCRIPT_ID);

    if (existingScript) {
      existingScript.addEventListener("load", resolve, { once: true });
      existingScript.addEventListener("error", reject, { once: true });
      return;
    }

    const script = document.createElement("script");
    script.id = TAMARA_WIDGET_SCRIPT_ID;
    script.src = TAMARA_WIDGET_SCRIPT_URL;
    script.async = true;
    script.onload = () => resolve();
    script.onerror = (error) => reject(error);
    document.body.appendChild(script);
  });

  return window.__tamaraWidgetLoaderPromise;
};

const TamaraPromoWidget = ({
  amount,
  publicKey = "",
  countryCode = "AE",
  lang = "en",
  installments = 4,
  inlineType = "3",
  inlineVariant = "text",
  className = "",
  title = "Split into 4 payments",
  description = "No late fees. Sharia compliant.",
}) => {
  const [widgetReady, setWidgetReady] = useState(false);
  const [widgetFailed, setWidgetFailed] = useState(false);

  const safeAmount = useMemo(() => Number(amount || 0), [amount]);
  const installmentAmount = useMemo(
    () => getTamaraInstallmentAmount(safeAmount, installments),
    [installments, safeAmount]
  );

  useEffect(() => {
    if (!publicKey || !safeAmount || typeof window === "undefined") {
      setWidgetReady(false);
      return undefined;
    }

    let isMounted = true;
    setWidgetFailed(false);

    window.tamaraWidgetConfig = {
      lang,
      country: countryCode,
      publicKey,
    };

    ensureTamaraWidgetScript()
      .then(() => {
        if (!isMounted) return;
        window.TamaraWidgetV2?.refresh?.();
        setWidgetReady(true);
      })
      .catch(() => {
        if (!isMounted) return;
        setWidgetReady(false);
        setWidgetFailed(true);
      });

    return () => {
      isMounted = false;
    };
  }, [countryCode, lang, publicKey, safeAmount]);

  useEffect(() => {
    if (!widgetReady || typeof window === "undefined") return;

    window.tamaraWidgetConfig = {
      lang,
      country: countryCode,
      publicKey,
    };

    window.TamaraWidgetV2?.refresh?.();
  }, [countryCode, inlineType, inlineVariant, lang, publicKey, safeAmount, widgetReady]);

  if (!safeAmount) return null;

  return (
    <div className={`rounded-[20px] border border-[#eef2f6] bg-[#fcfdff] p-4 ${className}`}>
      <div className="flex items-center gap-3">
        <img src={TAMARA_LOGO_URL} alt="Tamara" className="h-8 w-auto object-contain" />
        <div>
          <p className="m-0 text-[13px] font-[800] uppercase tracking-[0.12em] text-[#0d6efd]">
            {title}
          </p>
          <p className="m-0 mt-1 text-[12px] text-[#6b7280]">{description}</p>
        </div>
      </div>

      <div className="mt-3">
        {widgetReady && !widgetFailed && publicKey ? (
          React.createElement("tamara-widget", {
            type: "tamara-summary",
            amount: safeAmount.toFixed(2),
            "inline-type": String(inlineType),
            "inline-variant": inlineVariant,
            key: `${publicKey}-${countryCode}-${lang}-${inlineType}-${safeAmount.toFixed(2)}`,
          })
        ) : (
          <p className="m-0 text-[14px] font-[700] leading-6 text-[#111827]">
            Split into {installments} interest-free payments of {formatPrice(installmentAmount)} with Tamara.
          </p>
        )}
      </div>
    </div>
  );
};

export default TamaraPromoWidget;
