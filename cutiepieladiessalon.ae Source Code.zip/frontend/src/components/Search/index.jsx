import React, { useContext, useState } from "react";
import "../Search/style.css";
import Button from "@mui/material/Button";
import { IoSearch } from "react-icons/io5";
import { MyContext } from "../../App";
import { useNavigate } from "react-router-dom";
import { postData } from "../../utils/api";
import CircularProgress from '@mui/material/CircularProgress';

const Search = ({
  className = "searchBox w-[100%] h-[50px] bg-[#e5e5e5] rounded-[5px] relative p-2",
  inputClassName = "w-full h-[35px] focus:outline-none bg-inherit p-2 text-[15px]",
  buttonClassName = "!absolute top-[8px] right-[5px] z-50 !w-[37px] !min-w-[37px] h-[37px] !rounded-full !text-black",
  placeholder = "Search in Salon for women...",
  buttonMode = "icon",
  buttonLabel = "Search",
}) => {

  const [searchQuery, setSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const context = useContext(MyContext);

  const history = useNavigate();

  const onChangeInput = (e) => {
    setSearchQuery(e.target.value);
  }


  const search = async () => {
    const normalizedQuery = searchQuery.trim();

    if (normalizedQuery === "") return;

    setIsLoading(true);

    const obj = {
      page: 1,
      limit: 3,
      query: normalizedQuery
    };

    try {
      const res = await postData(`/api/product/search/get`, obj);
      if (res) {
        context?.setSearchData(res);
        context?.setOpenSearchPanel(false);
        history("/search");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form
      className={className}
      onSubmit={(event) => {
        event.preventDefault();
        search();
      }}
    >
      <input
        type="text"
        placeholder={placeholder}
        className={inputClassName}
        value={searchQuery}
        onChange={onChangeInput}
      />
      <Button type="submit" className={buttonClassName}>
        {
          isLoading === true ? (
            <CircularProgress />
          ) : buttonMode === "label" ? (
            buttonLabel
          ) : (
            <IoSearch className="text-[#4e4e4e] text-[22px]" />
          )
        }


      </Button>
    </form>
  );
};

export default Search;
