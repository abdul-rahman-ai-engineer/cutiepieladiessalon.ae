import React, { useContext, useState } from "react";
import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import { IoCloseSharp } from "react-icons/io5";
import { CategoryCollapse } from "../../CategoryCollapse";
import { Button } from "@mui/material";
import { MyContext } from "../../../App";
import { Link } from "react-router-dom";
import { fetchDataFromApi } from "../../../utils/api";
import { useNavigate } from "react-router-dom";

const CategoryPanel = (props) => {

  const context = useContext(MyContext);
  const navigate = useNavigate();

  const toggleDrawer = (newOpen) => () => {
    props.setIsOpenCatPanel(newOpen);
    props.propsSetIsOpenCatPanel?.(newOpen)
  };


  const DrawerList = (
    <Box sx={{ width: 250 }} role="presentation" className="categoryPanel">

      <div className="p-3">
        <img
          src={localStorage.getItem('logo') || "/logo2.jpg"}
          alt="Cutie Pie Beauty Salon"
          className="w-[170px]"
        />
      </div>

      <h3 className="p-3 text-[16px] font-[500] flex items-center justify-between">
        Browse Salon Services{" "}
        <IoCloseSharp
          onClick={toggleDrawer(false)}
          className="cursor-pointer text-[20px]"
        />
      </h3>

      {
        props?.data?.length !== 0 && <CategoryCollapse data={props?.data} />
      }

      {
        context?.windowWidth < 992 && context?.isLogin === false &&
        <Link to="/login" className="p-3 block" onClick={() => {
          props.setIsOpenCatPanel(false);
          props.propsSetIsOpenCatPanel(false)
        }}>
          <Button className="btn-org w-full">Login</Button>
        </Link>
      }


      {
        context?.windowWidth < 992 && context?.isLogin === true &&
        <div className="p-3 block" onClick={() => {
          props.setIsOpenCatPanel(false);
          props.propsSetIsOpenCatPanel?.(false)
          fetchDataFromApi(`/api/user/logout`).finally(() => {
            context?.clearAuthState?.();
            navigate("/");
          })
        }}>
          <Button className="btn-org w-full">Logout</Button>
        </div>
      }


    </Box>
  );

  return (
    <>
      <Drawer open={props.isOpenCatPanel} onClose={toggleDrawer(false)}>
        {DrawerList}
      </Drawer>
    </>
  );
};

export default CategoryPanel;
