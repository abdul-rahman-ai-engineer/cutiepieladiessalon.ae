import Button from "@mui/material/Button";
import React, { useContext, useEffect, useState } from "react";
import { RiMenu2Fill } from "react-icons/ri";
import { LiaAngleDownSolid } from "react-icons/lia";
import { Link } from "react-router-dom";
import { LuMapPin } from "react-icons/lu";
import CategoryPanel from "./CategoryPanel";

import "../Navigation/style.css";
import { MyContext } from "../../../App";
import MobileNav from "./MobileNav";

const Navigation = (props) => {
  const [isOpenCatPanel, setIsOpenCatPanel] = useState(false);
  const [catData, setCatData] = useState([]);

  const context = useContext(MyContext);

  useEffect(() => {
    setCatData(context?.catData);
  }, [context?.catData]);

  useEffect(() => {
    setIsOpenCatPanel(props.isOpenCatPanel);
  }, [props.isOpenCatPanel])

  const openCategoryPanel = () => {
    setIsOpenCatPanel(true);
  };

  return (
    <>
      <nav className="navigation border-b border-[rgba(22,32,50,0.06)] bg-white">
        <div className="container flex items-center justify-start gap-4 lg:gap-8">
          {
            context?.windowWidth > 992 &&
            <div className="col_1 w-[22%]">
              <Button
                className="!w-full !justify-start !rounded-[18px] !bg-[var(--brand-shell)] !px-4 !py-3 !text-[13px] !font-[800] !tracking-[0.12em] !text-[var(--brand-ink)]"
                onClick={openCategoryPanel}
              >
                <RiMenu2Fill className="text-[18px]" />
                Salon Services
                <LiaAngleDownSolid className="ml-auto text-[13px] font-bold" />
              </Button>
            </div>
          }


          <div className="col_2 w-full lg:w-[58%]">
            <ul className="nav flex items-center gap-1 lg:gap-2">
              <li className="list-none">
                <Button
                  component={Link}
                  to="/"
                  className="link transition !rounded-full !px-4 !py-3 !font-[700] !text-[rgba(22,32,50,0.82)] hover:!bg-[var(--brand-shell-warm)] hover:!text-[var(--brand-coral)]"
                >
                  Home
                </Button>
              </li>

              {
                catData?.length !== 0 && catData?.map((cat, index) => {
                  return (
                    <li className="list-none relative" key={index}>
                      <Button
                        component={Link}
                        to={`/products?catId=${cat?._id}`}
                        className="link transition !rounded-full !px-4 !py-3 !font-[700] !text-[rgba(22,32,50,0.82)] hover:!bg-[var(--brand-shell-warm)] hover:!text-[var(--brand-coral)]"
                      >
                        {cat?.name}
                      </Button>

                      {
                        cat?.children?.length !== 0 &&
                        <div className="submenu absolute left-[0%] top-[120%] min-w-[180px] bg-white opacity-0 shadow-md transition-all">
                          <ul>
                            {
                              cat?.children?.map((subCat, index_) => {
                                return (
                                  <li className="list-none w-full relative" key={index_}>
                                    <Button
                                      component={Link}
                                      to={`/products?subCatId=${subCat?._id}`}
                                      className="!w-full !justify-start !rounded-[12px] !px-3 !py-2.5 !text-left !text-[rgba(22,32,50,0.84)]"
                                    >
                                      {subCat?.name}
                                    </Button>

                                    {
                                      subCat?.children?.length !== 0 &&
                                      <div className="submenu absolute left-[100%] top-[0%] min-w-[180px] bg-white opacity-0 shadow-md transition-all">
                                        <ul>
                                          {
                                            subCat?.children?.map((thirdLavelCat, index__) => {
                                              return (
                                                <li className="list-none w-full" key={index__}>
                                                  <Button
                                                    component={Link}
                                                    to={`/products?thirdLavelCatId=${thirdLavelCat?._id}`}
                                                    className="!w-full !justify-start !rounded-[12px] !px-3 !py-2.5 !text-left !text-[rgba(22,32,50,0.84)]"
                                                  >
                                                    {thirdLavelCat?.name}
                                                  </Button>
                                                </li>)
                                            })
                                          }
                                        </ul>
                                      </div>
                                    }
                                  </li>
                                )
                              })
                            }




                          </ul>
                        </div>
                      }

                    </li>
                  )
                })
              }


            </ul>
          </div>

          <div className="col_3 hidden w-[20%] lg:block">
            <p className="m-0 flex items-center justify-end gap-3 text-[13px] font-[700] leading-tight text-[var(--brand-muted)]">
              <LuMapPin className="text-[17px] text-[var(--brand-sky-deep)]" />
              Dubai home salon services
            </p>
          </div>
        </div>
      </nav>

      {/* category panel component */}
      {
        catData?.length !== 0 &&
        <CategoryPanel
          isOpenCatPanel={isOpenCatPanel}
          setIsOpenCatPanel={setIsOpenCatPanel}
          propsSetIsOpenCatPanel={props.setIsOpenCatPanel}
          data={catData}
        />
      }


      {
        context?.windowWidth < 992 && <MobileNav />
      }



    </>
  );
};

export default Navigation;
