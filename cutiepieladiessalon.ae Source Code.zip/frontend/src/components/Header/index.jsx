import React, { useContext, useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import Search from "../Search";
import IconButton from "@mui/material/IconButton";
import Tooltip from "@mui/material/Tooltip";
import Navigation from "./Navigation";
import { MyContext } from "../../App";
import { Button } from "@mui/material";
import { FaRegUser } from "react-icons/fa";

import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import { MdKeyboardArrowDown } from "react-icons/md";
import { IoBagCheckOutline } from "react-icons/io5";
import { IoIosLogOut } from "react-icons/io";
import { fetchDataFromApi } from "../../utils/api";
import { LuMapPin } from "react-icons/lu";
import { HiOutlineMenu } from "react-icons/hi";
import { getAddressLocationLabel, getLatestAddress } from "../../utils/address";

const FALLBACK_LOGO = "/logo2.jpg";


const Header = () => {
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);

  const [isOpenCatPanel, setIsOpenCatPanel] = useState(false);
  const [logoUrl, setLogoUrl] = useState(() => localStorage.getItem("logo") || FALLBACK_LOGO);

  const context = useContext(MyContext);

  const history = useNavigate();
  const location = useLocation();
  const primaryAddress = getLatestAddress(context?.userData?.address_details);
  const locationLabel = primaryAddress
    ? getAddressLocationLabel(primaryAddress)
    : "Dubai, UAE";
  const loginRedirectState = {
    from: `${location.pathname}${location.search}${location.hash}`,
  };

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  useEffect(() => {
    let isMounted = true;

    fetchDataFromApi("/api/logo").then((res) => {
      const nextLogo = res?.logo?.[0]?.logo || FALLBACK_LOGO;

      if (!isMounted) return;

      setLogoUrl(nextLogo);
      localStorage.setItem("logo", nextLogo);
    });

    return () => {
      isMounted = false;
    };
  }, []);

  const handleAccountAction = (event) => {
    if (!context?.isLogin) {
      history("/login", { state: loginRedirectState });
      return;
    }

    handleClick(event);
  };

  const handleOpenLocation = () => {
    if (!context?.isLogin) {
      history("/login", { state: loginRedirectState });
      return;
    }

    context?.setAddressMode("add");
    context?.setOpenAddressPanel(true);
  };

  const logout = () => {
    setAnchorEl(null);

    fetchDataFromApi(`/api/user/logout`).finally(() => {
      context?.clearAuthState?.();
      history("/");
    });

  }

  return (
    <>
      <header className="fixed left-0 top-0 z-[101] w-full bg-white lg:sticky lg:-top-[45px]">
        <div className="top-strip hidden border-y border-[rgba(22,32,50,0.06)] bg-[var(--brand-shell)] py-2 lg:block">
          <div className="container">
            <div className="flex items-center justify-between">
              <div className="col1 w-[50%] hidden lg:block">
                <p className="m-0 text-[12px] font-[600] text-[var(--brand-muted)]">
                  Home salon bookings with transparent pricing and curated offers
                </p>
              </div>

              <div className="col2 flex items-center justify-between w-full lg:w-[50%] lg:justify-end">
                <ul className="flex items-center gap-3 w-full justify-between lg:w-[200px]">
                  <li className="list-none">
                    <Link
                      to="/help-center"
                      className="link text-[11px] font-[600] transition lg:text-[13px]"
                    >
                      Help Center{" "}
                    </Link>
                  </li>
                  <li className="list-none">
                    <Link
                      to="/order-tracking"
                      className="link text-[11px] font-[600] transition lg:text-[13px]"
                    >
                      Order Tracking
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <div className="header border-b border-[rgba(22,32,50,0.06)] bg-white py-3 lg:py-4">
          <div className="container relative flex min-h-[52px] items-center justify-between gap-3 lg:min-h-0 lg:gap-6">
            {
              context?.windowWidth < 992 &&
              <Button className="!h-[42px] !min-w-[42px] !w-[42px] !rounded-full !border !border-[var(--brand-border)] !text-[var(--brand-ink)]" onClick={() => setIsOpenCatPanel(true)}><HiOutlineMenu size={22} /></Button>
            }

            <div className="col1 absolute left-1/2 top-1/2 z-[1] w-[132px] -translate-x-1/2 -translate-y-1/2 lg:static lg:w-auto lg:translate-x-0 lg:translate-y-0 lg:min-w-[190px]">
              <Link to={"/"} className="flex justify-center lg:justify-start">
                <img
                  src={logoUrl || FALLBACK_LOGO}
                  alt="Cutie Pie Beauty Salon"
                  className="mx-auto max-h-[44px] w-auto max-w-[132px] rounded-none object-contain lg:mx-0 lg:max-h-none lg:max-w-[205px]"
                />
              </Link>
            </div>

            <div className="hidden min-w-0 flex-1 items-center gap-4 lg:flex">
              <button
                type="button"
                onClick={handleOpenLocation}
                className="inline-flex min-w-[150px] items-center gap-3 rounded-[18px] border border-[var(--brand-border)] bg-[var(--brand-shell)] px-4 py-3 text-left shadow-[0_10px_26px_rgba(15,23,42,0.04)] transition hover:border-[var(--brand-sky)]"
              >
                <span className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-[var(--brand-sky-soft)] text-[var(--brand-sky-deep)]">
                  <LuMapPin className="text-[18px]" />
                </span>
                <span className="min-w-0">
                  <span className="block text-[10px] font-[800] uppercase tracking-[0.18em] text-[var(--brand-muted)]">
                    Location
                  </span>
                  <span className="block truncate text-[14px] font-[700] text-[var(--brand-ink)]">
                    {locationLabel}
                  </span>
                </span>
              </button>

              <Search
                className="searchBox relative h-[58px] flex-1 rounded-[20px] border border-[var(--brand-border)] bg-[#f6f8fb] px-4 py-2 shadow-[0_10px_26px_rgba(15,23,42,0.04)]"
                inputClassName="h-full w-full bg-transparent pr-14 text-[15px] text-[var(--brand-ink)] outline-none placeholder:text-[rgba(22,32,50,0.55)]"
                buttonClassName="!absolute !right-[10px] !top-[10px] !h-[38px] !min-w-[38px] !w-[38px] !rounded-full !bg-white !text-[var(--brand-ink)] shadow-none"
                placeholder="Search in Salon for women..."
              />
            </div>

            <div className="col3 ml-auto flex w-[42px] items-center justify-end lg:ml-0 lg:w-auto lg:min-w-[316px]">
              <ul className="flex w-full items-center justify-end gap-1.5 lg:gap-3">
                <li className="hidden lg:block">
                  <Button
                    className="!rounded-[18px] !border !border-[var(--brand-border)] !bg-[var(--brand-shell)] !px-3 !py-2.5 !text-[var(--brand-ink)]"
                    onClick={handleAccountAction}
                  >
                    <span className="flex !h-[42px] !w-[42px] !min-w-[42px] items-center justify-center rounded-full bg-[rgba(22,32,50,0.08)]">
                      <FaRegUser className="text-[16px] text-[var(--brand-ink)]" />
                    </span>
                    <span className="ml-3 hidden min-w-0 text-left xl:block">
                      <span className="block truncate text-[14px] font-[700] capitalize text-[var(--brand-ink)]">
                        {context?.isLogin ? context?.userData?.name || "My profile" : "Sign in"}
                      </span>
                      <span className="block truncate text-[12px] text-[var(--brand-muted)]">
                        {context?.isLogin
                          ? context?.userData?.email || "Manage your account"
                          : "Manage bookings"}
                      </span>
                    </span>
                  </Button>

                  <Menu
                    anchorEl={anchorEl}
                    id="account-menu"
                    open={open}
                    onClose={handleClose}
                    onClick={handleClose}
                    slotProps={{
                      paper: {
                        elevation: 0,
                        sx: {
                          overflow: "visible",
                          filter: "drop-shadow(0px 10px 24px rgba(15,23,42,0.12))",
                          mt: 1.5,
                          borderRadius: "16px",
                          "& .MuiAvatar-root": {
                            width: 32,
                            height: 32,
                            ml: -0.5,
                            mr: 1,
                          },
                          "&::before": {
                            content: '""',
                            display: "block",
                            position: "absolute",
                            top: 0,
                            right: 14,
                            width: 10,
                            height: 10,
                            bgcolor: "background.paper",
                            transform: "translateY(-50%) rotate(45deg)",
                            zIndex: 0,
                          },
                        },
                      },
                    }}
                    transformOrigin={{ horizontal: "right", vertical: "top" }}
                    anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
                  >
                    <Link to="/my-account" className="block w-full">
                      <MenuItem
                        onClick={handleClose}
                        className="flex gap-2 !py-2"
                      >
                        <FaRegUser className="text-[18px]" />{" "}
                        <span className="text-[14px]">My Account</span>
                      </MenuItem>
                    </Link>
                    <Link to="/address" className="block w-full">
                      <MenuItem
                        onClick={handleClose}
                        className="flex gap-2 !py-2"
                      >
                        <LuMapPin className="text-[18px]" />{" "}
                        <span className="text-[14px]">Address</span>
                      </MenuItem>
                    </Link>
                    <Link to="/my-bookings" className="block w-full">
                      <MenuItem
                        onClick={handleClose}
                        className="flex gap-2 !py-2"
                      >
                        <IoBagCheckOutline className="text-[18px]" />{" "}
                        <span className="text-[14px]">My Bookings</span>
                      </MenuItem>
                    </Link>
                    <MenuItem
                      onClick={logout}
                      className="flex gap-2 !py-2"
                    >
                      <IoIosLogOut className="text-[18px]" />{" "}
                      <span className="text-[14px]">Logout</span>
                    </MenuItem>
                  </Menu>
                </li>

                {context?.windowWidth <= 992 ? (
                  <li>
                    <Tooltip title={context?.isLogin ? "My Account" : "Login"}>
                      <IconButton
                        aria-label="account"
                        onClick={() =>
                          history(
                            context?.isLogin ? "/my-account" : "/login",
                            context?.isLogin ? undefined : { state: loginRedirectState }
                          )
                        }
                        className="!border !border-[var(--brand-border)] !bg-white"
                      >
                        <FaRegUser />
                      </IconButton>
                    </Tooltip>
                  </li>
                ) : null}

              </ul>
            </div>
          </div>

          <div className="container mt-4 lg:hidden">
            <div className="flex flex-col gap-3">
              <button
                type="button"
                onClick={handleOpenLocation}
                className="inline-flex w-full items-center gap-3 rounded-[18px] border border-[var(--brand-border)] bg-[var(--brand-shell)] px-4 py-3 text-left shadow-[0_10px_26px_rgba(15,23,42,0.04)] transition hover:border-[var(--brand-sky)]"
              >
                <span className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[var(--brand-sky-soft)] text-[var(--brand-sky-deep)]">
                  <LuMapPin className="text-[18px]" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-[10px] font-[800] uppercase tracking-[0.18em] text-[var(--brand-muted)]">
                    Location
                  </span>
                  <span className="block truncate text-[14px] font-[700] text-[var(--brand-ink)]">
                    {locationLabel}
                  </span>
                </span>
                <MdKeyboardArrowDown className="shrink-0 text-[20px] text-[var(--brand-muted)]" />
              </button>
            </div>
          </div>

          <div className={`fixed left-0 top-0 z-50 h-full w-full bg-white p-3 lg:hidden ${context?.openSearchPanel === true ? 'block' : 'hidden'}`}>
            <div className="mb-3 flex items-center justify-between">
              <p className="m-0 text-[15px] font-[700] text-[var(--brand-ink)]">Search services</p>
              <Button
                className="!min-w-[40px] !rounded-full !text-[var(--brand-ink)]"
                onClick={() => context?.setOpenSearchPanel(false)}
              >
                Close
              </Button>
            </div>
            <Search
              className="searchBox relative h-[56px] rounded-[18px] border border-[var(--brand-border)] bg-[var(--brand-shell)] px-4 py-2"
              inputClassName="h-full w-full bg-transparent pr-14 text-[15px] text-[var(--brand-ink)] outline-none"
              buttonClassName="!absolute !right-[10px] !top-[10px] !h-[36px] !min-w-[36px] !w-[36px] !rounded-full !bg-white !text-[var(--brand-ink)]"
            />
          </div>
        </div>

        <Navigation isOpenCatPanel={isOpenCatPanel} setIsOpenCatPanel={setIsOpenCatPanel} />
      </header>


      <div className="afterHeader mt-[176px] lg:mt-0"></div>

    </>
  );
};

export default Header;
