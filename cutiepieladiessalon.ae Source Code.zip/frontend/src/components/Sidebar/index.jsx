import React, { useContext, useEffect, useState } from "react";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import "../Sidebar/style.css";
import { Collapse } from "react-collapse";
import { FaAngleDown } from "react-icons/fa6";
import Button from "@mui/material/Button";
import { FaAngleUp } from "react-icons/fa6";
import RangeSlider from "react-range-slider-input";
import "react-range-slider-input/dist/style.css";
import { MyContext } from "../../App";
import { useLocation } from "react-router-dom";
import { postData } from "../../utils/api";
import { MdOutlineFilterAlt } from "react-icons/md";
import { formatPrice } from "../../utils/formatPrice";


export const Sidebar = (props) => {
  const [isOpenCategoryFilter, setIsOpenCategoryFilter] = useState(true);

  const [filters, setFilters] = useState({
    catId: [],
    subCatId: [],
    thirdsubCatId: [],
    minPrice: '',
    maxPrice: '',
    rating: '',
    page: 1,
    limit: 25
  })



  const [price, setPrice] = useState([0, 10000]);

  const context = useContext(MyContext);

  const location = useLocation();


  const handleCheckboxChange = (field, value) => {

    context?.setSearchData([]);

    const currentValues = filters[field] || []
    const updatedValues = currentValues?.includes(value) ?
      currentValues.filter((item) => item !== value) :
      [...currentValues, value];

    setFilters((prev) => ({
      ...prev,
      [field]: updatedValues
    }))


    if (field === "catId") {
      setFilters((prev) => ({
        ...prev,
        subCatId: [],
        thirdsubCatId: []
      }))
    }

  }


  useEffect(() => {

    const url = window.location.href;
    const queryParameters = new URLSearchParams(location.search);

    if (url.includes("catId")) {
      const categoryId = queryParameters.get("catId");
      const catArr = [];
      catArr.push(categoryId);
      filters.catId = catArr;
      filters.subCatId = [];
      filters.thirdsubCatId = [];
      filters.rating = [];
      context?.setSearchData([]);
    }

    if (url.includes("subCatId")) {
      const subcategoryId = queryParameters.get("subCatId");
      const subcatArr = [];
      subcatArr.push(subcategoryId);
      filters.subCatId = subcatArr;
      filters.catId = [];
      filters.thirdsubCatId = [];
      filters.rating = [];
      context?.setSearchData([]);
    }


    if (url.includes("thirdLavelCatId")) {
      const thirdcategoryId = queryParameters.get("thirdLavelCatId");
      const thirdcatArr = [];
      thirdcatArr.push(thirdcategoryId);
      filters.subCatId = [];
      filters.catId = [];
      filters.thirdsubCatId = thirdcatArr;
      filters.rating = [];
      context?.setSearchData([]);
    }

    filters.page = 1;

    setTimeout(() => {
      filtesData();
    }, 200);




  }, [location]);



  const filtesData = () => {
    props.setIsLoading(true);

    //console.log(context?.searchData)

    if (context?.searchData?.products?.length > 0) {
      props.setProductsData(context?.searchData);
      props.setIsLoading(false);
      props.setTotalPages(context?.searchData?.totalPages)
      window.scrollTo(0, 0);
    } else {
      postData(`/api/product/filters`, filters).then((res) => {
        props.setProductsData(res);
        props.setIsLoading(false);
        props.setTotalPages(res?.totalPages)
        window.scrollTo(0, 0);
      })
    }


  }



  useEffect(() => {
    filters.page = props.page;
    filtesData();
  }, [filters, props.page])


  useEffect(() => {
    setFilters((prev) => ({
      ...prev,
      minPrice: price[0],
      maxPrice: price[1]
    }))
  }, [price]);


  return (
    <aside className="sidebar static rounded-[30px] border border-[var(--brand-border)] bg-white p-5 shadow-[0_22px_48px_rgba(15,23,42,0.06)] lg:sticky lg:top-[168px] lg:p-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="m-0 text-[11px] font-[800] uppercase tracking-[0.18em] text-[var(--brand-sky-deep)]">
            Filter services
          </p>
          <h2 className="mt-2 text-[24px] font-[800] leading-none text-[var(--brand-ink)]">
            Book by category
          </h2>
        </div>
      </div>

      <div className="mt-6 max-h-[60vh] w-full overflow-auto lg:max-h-none lg:overflow-visible">
        <div className="box rounded-[24px] border border-[rgba(22,32,50,0.06)] bg-[var(--brand-shell)] p-4">
          <h3 className="mb-3 flex w-full items-center pr-1 text-[14px] font-[800] uppercase tracking-[0.12em] text-[var(--brand-ink)]">
            Categories
            <Button
              className="!ml-auto !h-[34px] !min-w-[34px] !w-[34px] !rounded-full !text-[var(--brand-ink)]"
              onClick={() => setIsOpenCategoryFilter(!isOpenCategoryFilter)}
            >
              {isOpenCategoryFilter === true ? <FaAngleUp /> : <FaAngleDown />}
            </Button>
          </h3>
          <Collapse isOpened={isOpenCategoryFilter}>
            <div className="scroll relative -left-[8px] px-1">


              {
                context?.catData?.length !== 0 && context?.catData?.map((item, index) => {
                  return (
                    <FormControlLabel
                      key={index}
                      value={item?._id}
                      control={<Checkbox />}
                      checked={filters?.catId?.includes(item?._id)}
                      label={item?.name}
                      onChange={() => handleCheckboxChange('catId', item?._id)}
                      className="w-full rounded-[14px] px-2 py-1.5 hover:bg-white"
                    />
                  )
                })
              }

            </div>
          </Collapse>
        </div>

        <div className="box mt-5 rounded-[24px] border border-[rgba(22,32,50,0.06)] bg-white p-4">
          <h3 className="mb-4 flex w-full items-center pr-5 text-[14px] font-[800] uppercase tracking-[0.12em] text-[var(--brand-ink)]">
            Filter by price
          </h3>

          <RangeSlider
            value={price}
            onInput={setPrice}
            min={0}
            max={10000}
            setp={5}
          />
          <div className="priceRange flex pt-5 pb-1">
            <span className="text-[13px] text-[var(--brand-muted)]">
              From: <strong className="text-[var(--brand-ink)]">{formatPrice(price[0], { omitDecimals: true })}</strong>
            </span>
            <span className="ml-auto text-[13px] text-[var(--brand-muted)]">
              To: <strong className="text-[var(--brand-ink)]">{formatPrice(price[1], { omitDecimals: true })}</strong>
            </span>
          </div>
        </div>
      </div>
      <br />
      <Button className="btn-org w-full !flex lg:!hidden" onClick={() => context?.setOpenFilter(false)}><MdOutlineFilterAlt size={20} /> Filters</Button>


    </aside>
  );
};
