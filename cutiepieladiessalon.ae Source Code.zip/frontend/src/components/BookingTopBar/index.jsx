import React, { useContext, useEffect, useMemo, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import {
  MdKeyboardArrowDown,
  MdOutlineLocationOn,
  MdOutlineLogout,
  MdOutlinePersonOutline,
  MdOutlineShoppingBag,
} from "react-icons/md";
import { MyContext } from "../../App";
import { fetchDataFromApi } from "../../utils/api";
import Search from "../Search";

const FALLBACK_LOGO = "/logo2.jpg";

const getInitials = (name = "") =>
  String(name || "")
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() || "")
    .join("") || "CP";

const BookingTopBar = ({
  locationLabel,
  onOpenLocation,
  categories = [],
  activeCategoryId = "",
  onSelectCategory,
  hideCategoryRail = false,
}) => {
  const context = useContext(MyContext);
  const navigate = useNavigate();
  const location = useLocation();
  const [anchorEl, setAnchorEl] = useState(null);
  const [logoUrl, setLogoUrl] = useState(() => localStorage.getItem("logo") || FALLBACK_LOGO);

  const profileName = context?.userData?.name || "Guest";
  const profileMeta = context?.isLogin ? context?.userData?.email || "Manage your profile" : "Sign in";
  const profileInitials = useMemo(() => getInitials(profileName), [profileName]);
  const profileMenuOpen = Boolean(anchorEl);
  const loginRedirectState = {
    from: `${location.pathname}${location.search}${location.hash}`,
  };

  useEffect(() => {
    let isMounted = true;

    fetchDataFromApi("/api/logo").then((res) => {
      const nextLogo = res?.logo?.[0]?.logo || FALLBACK_LOGO;

      if (!isMounted) return;

      setLogoUrl(nextLogo);
      localStorage.setItem("logo", nextLogo);
    });

    return () => {
      isMounted = false;
    };
  }, []);

  const handleAccountClick = (event) => {
    if (!context?.isLogin) {
      navigate("/login", { state: loginRedirectState });
      return;
    }

    setAnchorEl(event.currentTarget);
  };

  const handleCloseMenu = () => {
    setAnchorEl(null);
  };

  const handleGoTo = (path) => {
    handleCloseMenu();
    navigate(path);
  };

  const handleLogout = async () => {
    handleCloseMenu();

    await fetchDataFromApi(`/api/user/logout`);
    context?.clearAuthState?.();
    navigate("/");
  };

  const handleCategoryClick = (category) => {
    if (typeof onSelectCategory === "function") {
      onSelectCategory(category?._id);
      return;
    }

    navigate(`/products?catId=${category?._id}`);
  };

  return (
    <header className="border-b border-[#e7edf4] bg-[#f8f9fa]/95 backdrop-blur-xl">
      <div className="container py-4">
        <div className="flex flex-col gap-4">
          <div className="flex flex-col gap-4 xl:flex-row xl:items-center">
            <div className="flex items-center justify-between gap-3 xl:min-w-[190px]">
              <Link
                to="/"
                className="inline-flex items-center rounded-[18px] border border-[var(--brand-border)] bg-white px-3 py-2"
                aria-label="Go to home"
              >
                <img
                  src={logoUrl || FALLBACK_LOGO}
                  alt="Cutie Pie Beauty Salon"
                  className="h-10 w-auto max-w-[150px] object-contain"
                />
              </Link>

              <button
                type="button"
                onClick={handleAccountClick}
                className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-[var(--brand-border)] bg-white text-[var(--brand-ink)] xl:hidden"
              >
                <span className="text-[13px] font-[800]">{profileInitials}</span>
              </button>
            </div>

            <div className="flex min-w-0 flex-1 flex-col gap-4 lg:flex-row lg:items-center">
              <button
                type="button"
                onClick={onOpenLocation}
                className="inline-flex min-w-0 items-center gap-3 rounded-[18px] border border-[var(--brand-border)] bg-white px-4 py-3 text-left transition hover:border-[var(--brand-sky)] lg:min-w-[190px]"
              >
                <span className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[var(--brand-sky-soft)] text-[var(--brand-sky-deep)]">
                  <MdOutlineLocationOn className="text-[20px]" />
                </span>
                <span className="min-w-0">
                  <span className="block text-[10px] font-[800] uppercase tracking-[0.18em] text-[var(--brand-muted)]">
                    Location
                  </span>
                  <span className="block truncate text-[14px] font-[700] text-[var(--brand-ink)]">
                    {locationLabel || "Dubai, UAE"}
                  </span>
                </span>
                <MdKeyboardArrowDown className="ml-auto shrink-0 text-[18px] text-[var(--brand-muted)]" />
              </button>

              <Search
                className="searchBox relative h-[58px] flex-1 rounded-[20px] border border-[var(--brand-border)] bg-white px-4 py-2"
                inputClassName="h-full w-full bg-transparent pl-2 pr-[120px] text-[15px] text-[var(--brand-ink)] outline-none placeholder:text-[rgba(22,32,50,0.55)]"
                buttonClassName="!absolute !right-[8px] !top-[8px] !h-[42px] !min-w-[100px] !rounded-[14px] !bg-[var(--brand-sky)] !px-5 !text-[14px] !font-[800] !text-white"
                placeholder="Search in Salon for women..."
                buttonMode="label"
                buttonLabel="Search"
              />
            </div>

            <div className="hidden items-center justify-end gap-3 xl:flex xl:min-w-[320px]">
              <button
                type="button"
                onClick={handleAccountClick}
                className="inline-flex min-w-0 items-center gap-3 rounded-[18px] border border-[var(--brand-border)] bg-white px-3 py-2 text-left transition hover:border-[var(--brand-sky)]"
              >
                <span className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[linear-gradient(135deg,#0f172a_0%,#334155_100%)] text-[13px] font-[800] text-white">
                  {profileInitials}
                </span>
                <span className="min-w-0">
                  <span className="block truncate text-[14px] font-[800] text-[var(--brand-ink)]">
                    {context?.isLogin ? profileName : "Sign in"}
                  </span>
                  <span className="block truncate text-[12px] text-[var(--brand-muted)]">
                    {profileMeta}
                  </span>
                </span>
                <MdKeyboardArrowDown className="shrink-0 text-[18px] text-[var(--brand-muted)]" />
              </button>
            </div>
          </div>

          {!hideCategoryRail ? (
            <div className="rounded-[22px] border border-[var(--brand-border)] bg-white px-3 py-2">
              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                <Link
                  to="/"
                  className="whitespace-nowrap rounded-full px-4 py-2.5 text-[13px] font-[800] text-[var(--brand-ink)] transition hover:bg-[var(--brand-shell-warm)] hover:text-[var(--brand-coral)]"
                >
                  Home
                </Link>
                {categories.map((category) => {
                  const isActive = category?._id === activeCategoryId;

                  return (
                    <button
                      key={category?._id}
                      type="button"
                      onClick={() => handleCategoryClick(category)}
                      className={`whitespace-nowrap rounded-full px-4 py-2.5 text-[13px] font-[800] transition ${
                        isActive
                          ? "bg-[var(--brand-shell-warm)] text-[var(--brand-coral)]"
                          : "text-[var(--brand-ink)] hover:bg-[var(--brand-shell-warm)] hover:text-[var(--brand-coral)]"
                      }`}
                    >
                      {category?.name}
                    </button>
                  );
                })}
              </div>
            </div>
          ) : null}
        </div>
      </div>

      <Menu
        anchorEl={anchorEl}
        open={profileMenuOpen}
        onClose={handleCloseMenu}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        <MenuItem onClick={() => handleGoTo("/my-account")}>
          <MdOutlinePersonOutline className="mr-3 text-[18px]" />
          My account
        </MenuItem>
        <MenuItem onClick={() => handleGoTo("/address")}>
          <MdOutlineLocationOn className="mr-3 text-[18px]" />
          Addresses
        </MenuItem>
        <MenuItem onClick={() => handleGoTo("/my-bookings")}>
          <MdOutlineShoppingBag className="mr-3 text-[18px]" />
          My Bookings
        </MenuItem>
        <MenuItem onClick={handleLogout}>
          <MdOutlineLogout className="mr-3 text-[18px]" />
          Logout
        </MenuItem>
      </Menu>
    </header>
  );
};

export default BookingTopBar;
