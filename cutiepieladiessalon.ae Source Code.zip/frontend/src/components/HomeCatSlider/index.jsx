import React from "react";
import { Link } from "react-router-dom";

const HomeCatSlider = (props) => {
  const categories = Array.isArray(props?.data)
    ? props.data.filter((cat) => cat?._id)
    : [];
  const trackStyle = {
    "--home-cat-count": Math.max(categories.length, 1),
  };

  const getCategoryFallback = (name) => {
    if (!name) return "C";

    return name
      .split(" ")
      .filter(Boolean)
      .slice(0, 2)
      .map((part) => part[0]?.toUpperCase())
      .join("");
  };

  return (
    <section className="homeCatSlider pt-0 lg:pt-4 py-4 lg:py-8">
      <div className="container">
        <div className="homeCatSlider__shell">
          <div className="homeCatSlider__header">
            <div className="homeCatSlider__copy">
            
              
             
            </div>

            
          </div>

          <div className="homeCatSlider__hint" aria-hidden="true">
            Swipe to explore
          </div>

          <div
            className="homeCatSlider__track"
            style={trackStyle}
            aria-label="Salon categories"
          >
            {categories.map((cat) => (
              <Link
                key={cat?._id || cat?.name}
                to={`/products?catId=${cat?._id}`}
                className="homeCatSlider__link"
              >
                <article className="item homeCatSlider__card">
                  <div className="homeCatSlider__imageWrap">
                    {cat?.images?.[0] ? (
                      <img
                        src={cat.images[0]}
                        alt={cat?.name || "Category"}
                        className="homeCatSlider__image"
                      />
                    ) : (
                      <span className="homeCatSlider__fallback">
                        {getCategoryFallback(cat?.name)}
                      </span>
                    )}
                  </div>

                  <div className="homeCatSlider__cardContent">
                    <h3 className="homeCatSlider__name">{cat?.name}</h3>
                   
                  </div>
                </article>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HomeCatSlider;
