import React, { useEffect, useMemo, useRef } from "react";
import L from "leaflet";
import { MapContainer, Marker, TileLayer, useMap, useMapEvents } from "react-leaflet";
import "leaflet/dist/leaflet.css";

const DEFAULT_ZOOM = 13;

const pinIcon = L.divIcon({
  className: "booking-pin-marker",
  html: '<span class="booking-pin-marker__pulse"></span><span class="booking-pin-marker__dot"></span>',
  iconSize: [34, 34],
  iconAnchor: [17, 30],
});

const ViewportController = ({ center, zoom = DEFAULT_ZOOM }) => {
  const map = useMap();

  useEffect(() => {
    const timeoutId = window.setTimeout(() => {
      map.invalidateSize();
    }, 120);

    return () => {
      window.clearTimeout(timeoutId);
    };
  }, [map, center?.lat, center?.lng]);

  useEffect(() => {
    if (!center?.lat || !center?.lng) {
      return;
    }

    map.setView([center.lat, center.lng], zoom, {
      animate: true,
      duration: 0.4,
    });
  }, [center?.lat, center?.lng, map, zoom]);

  return null;
};

const MapClickHandler = ({ interactive, onPositionChange }) => {
  useMapEvents({
    click(event) {
      if (!interactive) {
        return;
      }

      onPositionChange?.({
        lat: event.latlng.lat,
        lng: event.latlng.lng,
      });
    },
  });

  return null;
};

const LocationPickerMap = ({
  position,
  center,
  zoom = DEFAULT_ZOOM,
  interactive = true,
  height = 360,
  className = "",
  minZoom = 10,
  maxZoom = 18,
  maxBounds = null,
  onPositionChange,
}) => {
  const markerRef = useRef(null);
  const resolvedCenter = center || position;
  const markerHandlers = useMemo(
    () => ({
      dragend() {
        const marker = markerRef.current;
        if (!marker) {
          return;
        }

        const latLng = marker.getLatLng();
        onPositionChange?.({
          lat: latLng.lat,
          lng: latLng.lng,
        });
      },
    }),
    [onPositionChange]
  );

  if (!resolvedCenter?.lat || !resolvedCenter?.lng) {
    return null;
  }

  return (
    <div className={`overflow-hidden ${className}`} style={{ height }}>
      <MapContainer
        center={[resolvedCenter.lat, resolvedCenter.lng]}
        zoom={zoom}
        scrollWheelZoom={interactive}
        dragging
        doubleClickZoom={interactive}
        touchZoom
        boxZoom={interactive}
        keyboard={interactive}
        zoomControl={interactive}
        attributionControl
        minZoom={minZoom}
        maxZoom={maxZoom}
        maxBounds={maxBounds}
        maxBoundsViscosity={maxBounds ? 0.8 : 0}
        style={{ height: "100%", width: "100%" }}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <ViewportController center={resolvedCenter} zoom={zoom} />
        <MapClickHandler interactive={interactive} onPositionChange={onPositionChange} />
        {position?.lat && position?.lng ? (
          <Marker
            position={[position.lat, position.lng]}
            icon={pinIcon}
            draggable={interactive}
            autoPan={interactive}
            eventHandlers={markerHandlers}
            ref={markerRef}
          />
        ) : null}
      </MapContainer>
    </div>
  );
};

export default LocationPickerMap;
