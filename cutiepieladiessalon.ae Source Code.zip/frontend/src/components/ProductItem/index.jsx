import React from "react";
import "../ProductItem/style.css";
import { Link, useNavigate } from "react-router-dom";
import Rating from "@mui/material/Rating";
import Button from "@mui/material/Button";
import { formatPrice } from "../../utils/formatPrice";
import {
  getDiscountPercent,
  getPriceSuffix,
  getSavingsAmount,
} from "../../utils/productPricing";
import { isServiceCatalogItem } from "../../utils/productType";

const ProductItem = (props) => {
  const navigate = useNavigate();
  const item = props?.item || {};
  const compact = Boolean(props?.compact);
  const separated = Boolean(props?.separated);
  const isLast = Boolean(props?.isLast);
  const discountPercent = getDiscountPercent(item);
  const savingsAmount = getSavingsAmount(item);
  const isServiceItem = isServiceCatalogItem(item);
  const productLink = `/product/${item?._id}`;
  const primaryImage = item?.images?.[0] || "/homeBannerPlaceholder.jpg";
  const secondaryImage = item?.images?.[1] || primaryImage;
  const productName = item?.name || "Service";
  const brandLabel = item?.brand || "Cutie Pie Beauty Salon";
  const ratingValue = Number(item?.rating || 0);
  const ratingCount = Number(item?.ratingCount || 0);
  const durationMinutes = Number(item?.durationMinutes || 0);
  const serviceDescription =
    item?.shortDescription ||
    item?.description ||
    `Book ${productName.toLowerCase()} at home with Cutie Pie Beauty Salon.`;
  const locationLabel =
    item?.locationType === "salon" ? "IN-SALON SESSION" : "AT-HOME SESSION";
  const serviceMetaLabel =
    durationMinutes > 0 ? `${durationMinutes} MINS ${locationLabel}` : locationLabel;
  const compactMetaLabel =
    durationMinutes > 0
      ? `${durationMinutes} mins • ${item?.locationType === "salon" ? "salon" : "home"}`
      : item?.locationType === "salon"
        ? "Salon service"
        : "Home service";
  const hasOriginalPrice = Number(item?.oldPrice) > Number(item?.price);

  const handleBookNow = () => {
    navigate(productLink, {
      state: { autoAdd: isServiceItem ? 1 : true },
    });
  };

  if (compact) {
    return (
      <article
        className={`serviceCard serviceCard--compact group flex h-full flex-col overflow-hidden ${
          separated
            ? `bg-white px-4 py-4 sm:px-5 sm:py-5 ${!isLast ? "border-b border-[rgba(22,32,50,0.08)]" : ""}`
            : "rounded-[28px] border border-[var(--brand-border)] bg-white p-3 shadow-[0_18px_38px_rgba(15,23,42,0.05)] transition hover:-translate-y-[2px] hover:border-[rgba(0,191,255,0.22)] sm:p-4"
        }`}
      >
        <div className="flex min-w-0 gap-3 sm:gap-4">
          <Link to={productLink} className="block shrink-0">
            <div className="serviceCard__compactThumb relative h-[84px] w-[84px] overflow-hidden rounded-[18px] bg-[linear-gradient(180deg,#fff4ef_0%,#f6fbff_100%)] sm:h-[96px] sm:w-[96px] lg:h-[108px] lg:w-[108px]">
              <img
                src={primaryImage}
                alt={productName}
                className="serviceCard__primaryImage h-full w-full object-cover"
                loading="lazy"
              />

              {item?.images?.length > 1 ? (
                <img
                  src={secondaryImage}
                  alt={productName}
                  className="absolute left-0 top-0 h-full w-full object-cover opacity-0 group-hover:scale-[1.04] group-hover:opacity-100"
                  loading="lazy"
                />
              ) : null}

              <div className="pointer-events-none absolute left-2 top-2 z-20 flex items-start gap-2">
                <span className="serviceCard__promoBadge serviceCard__promoBadge--coral serviceCard__promoBadge--compact">
                  {discountPercent > 0 ? `${discountPercent}% OFF` : "TOP"}
                </span>
                {!separated && savingsAmount > 0 ? (
                  <span className="serviceCard__promoBadge serviceCard__promoBadge--sky serviceCard__promoBadge--compact">
                    SAVE
                  </span>
                ) : null}
              </div>
            </div>
          </Link>

          <div className="flex min-w-0 flex-1 flex-col">
            <p className="text-[9px] font-[700] uppercase tracking-[0.14em] text-[rgba(22,32,50,0.42)] sm:text-[10px]">
              {brandLabel}
            </p>

            <h3 className="mt-1 text-[15px] font-[800] leading-[1.15] text-[var(--brand-ink)] sm:text-[18px] lg:text-[22px]">
              <Link to={productLink} className="serviceCard__compactTitle transition-all">
                {productName}
              </Link>
            </h3>

            <p className="serviceCard__compactDescription mt-1.5 text-[11px] leading-[1.5] text-[var(--brand-muted)] sm:text-[12px] lg:text-[13px]">
              {serviceDescription}
            </p>

            <div className="mt-2 flex items-center gap-1.5 sm:gap-2">
              <Rating
                name={`service-rating-${item?._id}`}
                value={ratingValue}
                precision={0.5}
                size="small"
                readOnly
              />
              <span className="text-[11px] font-[700] text-[rgba(22,32,50,0.48)]">
                ({ratingCount})
              </span>
            </div>

            <div className="mt-auto flex items-end justify-between gap-2 pt-3">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                  <span
                    className={`text-[11px] font-[600] text-[rgba(22,32,50,0.38)] ${
                      hasOriginalPrice ? "line-through" : "opacity-0"
                    }`}
                  >
                    {hasOriginalPrice
                      ? formatPrice(item?.oldPrice)
                      : formatPrice(item?.price)}
                  </span>

                  <span className="text-[16px] font-[800] leading-none text-[var(--brand-coral)] sm:text-[18px] lg:text-[20px]">
                    {formatPrice(item?.price)} {getPriceSuffix(item)}
                  </span>
                </div>

                <p className="mt-2 text-[10px] font-[700] tracking-[0.04em] text-[rgba(22,32,50,0.52)]">
                  {separated ? compactMetaLabel : serviceMetaLabel}
                </p>
              </div>

              <Button
                className="serviceCard__bookButton serviceCard__bookButton--compact !min-w-[96px] !rounded-full sm:!min-w-[104px]"
                size="small"
                onClick={handleBookNow}
              >
                BOOK NOW
              </Button>
            </div>
          </div>
        </div>
      </article>
    );
  }

  return (
    <div className="productItem serviceCard group flex h-full flex-col overflow-hidden">
      <div className="imgWrapper relative w-full overflow-hidden">
        <Link to={productLink}>
          <div className="serviceCard__image relative aspect-square overflow-hidden bg-[linear-gradient(180deg,#fff4ef_0%,#f6fbff_100%)]">
            <img
              src={primaryImage}
              alt={productName}
              className="serviceCard__primaryImage h-full w-full object-cover"
              loading="lazy"
            />

            {item?.images?.length > 1 ? (
              <img
                src={secondaryImage}
                alt={productName}
                className="absolute left-0 top-0 h-full w-full object-cover opacity-0 group-hover:scale-[1.05] group-hover:opacity-100"
                loading="lazy"
              />
            ) : null}
          </div>
        </Link>

        <div className="pointer-events-none absolute inset-x-4 top-4 z-20 flex items-start justify-between gap-3">
          <span className="serviceCard__promoBadge serviceCard__promoBadge--coral">
            {discountPercent > 0 ? `${discountPercent}% OFF` : "BEST VALUE"}
          </span>
          <span className="serviceCard__promoBadge serviceCard__promoBadge--sky">
            {savingsAmount > 0
              ? `SAVE ${formatPrice(savingsAmount, { omitDecimals: true })}`
              : "HOME SERVICE"}
          </span>
        </div>
      </div>

      <div className="info flex flex-1 flex-col p-5">
        <h6 className="text-[11px] font-[600] uppercase tracking-[0.16em] text-[rgba(22,32,50,0.42)]">
          <span>{brandLabel}</span>
        </h6>

        <h3 className="serviceCard__title mt-2 text-[20px] font-[800] text-[var(--brand-ink)]">
          <Link to={productLink} className="serviceCard__titleLink transition-all">
            {productName}
          </Link>
        </h3>

        <div className="mt-3 flex items-center gap-2">
          <Rating
            name={`service-rating-${item?._id}`}
            value={ratingValue}
            precision={0.5}
            size="small"
            readOnly
          />
          <span className="text-[12px] font-[700] text-[rgba(22,32,50,0.48)]">
            ({ratingCount})
          </span>
        </div>

        <div className="mt-4 flex items-end justify-between gap-3">
          <span
            className={`oldPrice text-[13px] font-[600] text-[rgba(22,32,50,0.38)] ${
              hasOriginalPrice ? "line-through" : "opacity-0"
            }`}
          >
            {hasOriginalPrice
              ? formatPrice(item?.oldPrice)
              : formatPrice(item?.price)}
          </span>

          <span className="price text-[22px] font-[800] text-[var(--brand-coral)]">
            {formatPrice(item?.price)} {getPriceSuffix(item)}
          </span>
        </div>

        <div className="serviceCard__meta mt-4 pt-4">
          <p className="text-[11px] font-[800] uppercase tracking-[0.2em] text-[rgba(22,32,50,0.48)]">
            {serviceMetaLabel}
          </p>
        </div>

        <div className="mt-auto pt-5">
          <Button
            className="serviceCard__bookButton flex w-full !rounded-full"
            size="small"
            onClick={handleBookNow}
          >
            BOOK NOW
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ProductItem;
