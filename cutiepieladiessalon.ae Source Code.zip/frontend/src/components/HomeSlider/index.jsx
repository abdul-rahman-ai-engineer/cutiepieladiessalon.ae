import React, { useContext } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/navigation";

import { Navigation, Autoplay } from "swiper/modules";
import { MyContext } from "../../App";

const HomeSlider = (props) => {

  const context  = useContext(MyContext);
  const slides = Array.isArray(props?.data) ? props.data.slice().reverse() : [];
  const shouldLoop = slides.length > 1;

  return (
    <div className="homeSlider relative z-[99] pb-3 pt-4 lg:pb-5 lg:pt-6">
      <div className="container">
        <Swiper
          loop={shouldLoop}
          watchOverflow={true}
          spaceBetween={16}
          navigation={context?.windowWidth < 992 ? false : true}
          modules={[Navigation, Autoplay]}
          autoplay={
            shouldLoop
              ? {
                  delay: 2500,
                  disableOnInteraction: false,
                }
              : false
          }
          className="sliderHome"
        >
          {
            slides.length !== 0 && slides.map((item, index) => {
              return (
                <SwiperSlide key={index}>
                  <div className="item overflow-hidden rounded-[12px] bg-[#fff4ef] sm:rounded-[14px] lg:rounded-[16px]">
                    <img
                      src={item?.images[0]}
                      alt="Banner slide"
                      className="block w-full h-auto"
                    />
                  </div>
                </SwiperSlide>
              )
            })
          }

        </Swiper>
      </div>
    </div>
  );
};

export default HomeSlider;
