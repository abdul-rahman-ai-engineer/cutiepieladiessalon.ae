import React from "react";
import { IoMdCheckmark } from "react-icons/io";

const statusStyles = {
  pending: "bg-primary text-white",
  confirm: "bg-green-500 text-white",
  delivered: "bg-green-700 text-white",
  confirmed: "bg-green-100 text-green-700",
  scheduled: "bg-sky-100 text-sky-700",
  in_progress: "bg-violet-100 text-violet-700",
  completed: "bg-emerald-700 text-white",
  cancelled: "bg-rose-100 text-rose-700",
  authorized: "bg-blue-100 text-blue-700",
  paid: "bg-green-100 text-green-700",
  failed: "bg-rose-100 text-rose-700",
  cash_on_visit: "bg-amber-100 text-amber-700",
};

const Badge = ({ status }) => {
  const normalizedStatus = String(status || "unknown").toLowerCase();
  const shouldShowCheck = ["confirm", "confirmed", "delivered", "completed", "paid"].includes(normalizedStatus);

  return (
    <span
      className={`inline-flex items-center justify-center gap-1 rounded-full px-4 py-1 text-[11px] capitalize ${
        statusStyles[normalizedStatus] || "bg-gray-100 text-gray-700"
      }`}
    >
      {shouldShowCheck && <IoMdCheckmark size={13} />}
      {normalizedStatus.replace(/_/g, " ")}
    </span>
  );
};

export default Badge;
