import React, { useEffect } from "react";
import { MdClose, MdOutlineLocationOn } from "react-icons/md";
import {
  formatAddressExtras,
  formatAddressMeta,
  getAddressTitle,
} from "../../utils/address";

const BookingAddressModal = ({
  open,
  addresses = [],
  selectedAddressId = "",
  onSelect,
  onClose,
  onAddNew,
  onConfirm,
}) => {
  const normalizedAddresses = Array.isArray(addresses) ? addresses.filter(Boolean) : [];

  useEffect(() => {
    if (!open) return undefined;

    const previousOverflow = document.body.style.overflow;
    const handleKeyDown = (event) => {
      if (event.key === "Escape") {
        onClose?.();
      }
    };

    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", handleKeyDown);

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [onClose, open]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[140] flex items-center justify-center bg-[rgba(15,23,42,0.5)] px-4 py-8 backdrop-blur-[3px]"
      onClick={onClose}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="address-selection-title"
        className="w-full max-w-[640px] overflow-hidden rounded-[24px] border border-[var(--booking-border)] bg-white shadow-[0_28px_90px_rgba(15,23,42,0.22)]"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 border-b border-[#edf2f7] px-5 py-5 sm:px-6">
          <div className="flex items-start gap-4">
            <span className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-[var(--booking-accent-soft)] text-[var(--booking-accent-strong)]">
              <MdOutlineLocationOn className="text-[24px]" />
            </span>
            <div>
              <h2
                id="address-selection-title"
                className="m-0 text-[24px] font-[800] text-[var(--booking-text)]"
              >
                Select location
              </h2>
              <p className="mt-2 text-[14px] leading-6 text-[var(--booking-muted)]">
                Choose where your salon professional should arrive in Dubai.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-[var(--booking-border)] text-[var(--booking-text)] transition hover:border-[var(--booking-accent-strong)] hover:text-[var(--booking-accent-strong)]"
            aria-label="Close address selection"
          >
            <MdClose className="text-[22px]" />
          </button>
        </div>

        <div className="px-5 py-5 sm:px-6">
          <button
            type="button"
            onClick={onAddNew}
            className="inline-flex items-center text-[15px] font-[800] text-[var(--booking-accent-strong)] transition hover:text-[#0b65bb]"
          >
            + Add new location
          </button>

          <div className="mt-5 max-h-[52vh] space-y-3 overflow-y-auto pr-1">
            {normalizedAddresses.length ? (
              normalizedAddresses.map((address) => {
                const isSelected = selectedAddressId === address._id;

                return (
                  <label
                    key={address._id}
                    className={`flex cursor-pointer items-start gap-4 rounded-[18px] border px-4 py-4 transition ${
                      isSelected
                        ? "border-[var(--booking-accent-strong)] bg-[var(--booking-accent-soft)] shadow-[0_14px_34px_rgba(15,122,223,0.08)]"
                        : "border-[var(--booking-border)] bg-white hover:border-[var(--booking-border-strong)]"
                    }`}
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <p className="m-0 text-[12px] font-[800] uppercase tracking-[0.16em] text-[var(--booking-muted)]">
                            {address.addressType || "Saved location"}
                          </p>
                          <p className="mt-2 text-[16px] font-[700] leading-6 text-[var(--booking-text)]">
                            {getAddressTitle(address)}
                          </p>
                        </div>
                        <input
                          type="radio"
                          name="booking-address"
                          checked={isSelected}
                          onChange={() => onSelect?.(address._id)}
                          className="mt-1 h-5 w-5 shrink-0 accent-[var(--booking-accent-strong)]"
                        />
                      </div>

                      <p className="mt-2 text-[13px] leading-6 text-[var(--booking-muted)]">
                        {formatAddressMeta(address)}
                      </p>

                      {formatAddressExtras(address) ? (
                        <p className="mt-1 text-[13px] leading-6 text-[#8b9aae]">
                          {formatAddressExtras(address)}
                        </p>
                      ) : null}
                    </div>
                  </label>
                );
              })
            ) : (
              <div className="rounded-[18px] border border-dashed border-[var(--booking-border)] px-5 py-12 text-center">
                <p className="m-0 text-[16px] font-[700] text-[var(--booking-text)]">
                  No saved locations yet
                </p>
                <p className="mt-2 text-[14px] leading-6 text-[var(--booking-muted)]">
                  Add a Dubai location to keep your booking moving.
                </p>
              </div>
            )}
          </div>
        </div>

        <div className="border-t border-[#edf2f7] px-5 py-5 sm:px-6">
          <button
            type="button"
            onClick={onConfirm}
            disabled={!selectedAddressId}
            className="w-full rounded-full bg-[linear-gradient(135deg,var(--booking-accent-strong)_0%,var(--booking-accent)_100%)] px-5 py-4 text-[15px] font-[800] text-white shadow-[0_16px_34px_rgba(15,122,223,0.3)] transition hover:brightness-[1.02] disabled:cursor-not-allowed disabled:opacity-60"
          >
            Confirm location
          </button>
        </div>
      </div>
    </div>
  );
};

export default BookingAddressModal;
