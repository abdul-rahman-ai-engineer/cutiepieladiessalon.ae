import React from "react";
import "../ProductItem/style.css";
import { Link, useNavigate } from "react-router-dom";
import Rating from "@mui/material/Rating";
import Button from "@mui/material/Button";
import { MdAccessTime, MdOutlineLocationOn } from "react-icons/md";
import { formatPrice } from "../../utils/formatPrice";
import {
  getDiscountPercent,
  getPriceSuffix,
  getSavingsAmount,
} from "../../utils/productPricing";
import { isServiceCatalogItem } from "../../utils/productType";

const ProductItemListView = (props) => {
  const navigate = useNavigate();
  const item = props?.item || {};
  const productLink = `/product/${item?._id}`;
  const primaryImage = item?.images?.[0] || "/homeBannerPlaceholder.jpg";
  const secondaryImage = item?.images?.[1] || primaryImage;
  const discountPercent = getDiscountPercent(item);
  const savingsAmount = getSavingsAmount(item);
  const hasOriginalPrice = Number(item?.oldPrice) > Number(item?.price);
  const isServiceItem = isServiceCatalogItem(item);
  const durationMinutes = Number(item?.durationMinutes || 60);
  const serviceDescription =
    item?.shortDescription ||
    item?.description ||
    `Book ${item?.name?.toLowerCase?.() || "this service"} at home with Cutie Pie Beauty Salon.`;

  const handleBookNow = () => {
    navigate(productLink, {
      state: { autoAdd: isServiceItem ? 1 : true },
    });
  };

  return (
    <article className="group overflow-hidden rounded-[28px] border border-[var(--brand-border)] bg-white p-3 shadow-[0_18px_42px_rgba(15,23,42,0.05)] transition hover:-translate-y-[2px] hover:border-[rgba(0,191,255,0.24)] sm:p-4 lg:p-5">
      <div className="grid gap-4 md:grid-cols-[110px_minmax(0,1fr)] xl:grid-cols-[118px_minmax(0,1fr)_150px] xl:items-center">
        <div className="relative overflow-hidden rounded-[20px] bg-[linear-gradient(180deg,#fff4ef_0%,#f6fbff_100%)]">
          <Link to={productLink}>
            <img
              src={primaryImage}
              alt={item?.name}
              className="h-[108px] w-full object-cover transition duration-500 group-hover:scale-[1.03] sm:h-[120px] xl:h-[126px]"
            />

            {item?.images?.length > 1 ? (
              <img
                src={secondaryImage}
                alt={item?.name}
                className="absolute inset-0 h-[108px] w-full object-cover opacity-0 transition duration-500 group-hover:scale-[1.03] group-hover:opacity-100 sm:h-[120px] xl:h-[126px]"
              />
            ) : null}
          </Link>

          <div className="pointer-events-none absolute inset-x-2 top-2 z-20 flex items-start justify-between gap-2">
            <span className="serviceCard__promoBadge serviceCard__promoBadge--coral serviceCard__promoBadge--compact">
              {discountPercent > 0 ? `${discountPercent}% OFF` : "BEST VALUE"}
            </span>
            <span className="serviceCard__promoBadge serviceCard__promoBadge--sky serviceCard__promoBadge--compact">
              {savingsAmount > 0
                ? "SAVE"
                : "HOME"}
            </span>
          </div>
        </div>

        <div className="min-w-0">
          <p className="m-0 text-[10px] font-[700] uppercase tracking-[0.16em] text-[rgba(22,32,50,0.42)] sm:text-[11px]">
            {item?.brand || "Cutie Pie Beauty Salon"}
          </p>
          <h3 className="mt-1.5 text-[20px] font-[800] leading-[1.08] text-[var(--brand-ink)] sm:text-[22px]">
            <Link to={productLink} className="serviceCard__compactTitle transition-all">
              {item?.name}
            </Link>
          </h3>

          <p className="serviceCard__compactDescription mt-2 text-[13px] leading-[1.6] text-[var(--brand-muted)]">
            {serviceDescription}
          </p>

          <div className="mt-3 flex items-center gap-2">
            <Rating
              name={`list-rating-${item?._id}`}
              value={item?.rating}
              size="small"
              readOnly
            />
            <span className="text-[12px] font-[700] text-[rgba(22,32,50,0.48)]">
              ({Number(item?.ratingCount || 0)})
            </span>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            <span className="inline-flex items-center gap-2 rounded-full border border-[var(--brand-border)] bg-[var(--brand-shell)] px-3 py-2 text-[11px] font-[700] text-[var(--brand-ink)]">
              <MdAccessTime className="text-[16px] text-[var(--brand-sky-deep)]" />
              {durationMinutes} mins
            </span>
            <span className="inline-flex items-center gap-2 rounded-full border border-[var(--brand-border)] bg-[var(--brand-shell)] px-3 py-2 text-[11px] font-[700] text-[var(--brand-ink)]">
              <MdOutlineLocationOn className="text-[16px] text-[var(--brand-sky-deep)]" />
              Home Service
            </span>
          </div>
        </div>

        <div className="flex flex-col gap-3 md:pl-[126px] xl:items-end xl:pl-0">
          <div className="w-full rounded-[24px] border border-[var(--brand-border)] bg-[var(--brand-shell)] p-4 xl:max-w-[150px]">
            {hasOriginalPrice ? (
              <p className="m-0 text-[13px] font-[700] text-[rgba(22,32,50,0.38)] line-through">
                {formatPrice(item?.oldPrice)}
              </p>
            ) : (
              <div className="h-[22px]" />
            )}
            <p className="mt-1.5 text-[28px] font-[800] leading-none text-[var(--brand-coral)] xl:text-[30px]">
              {formatPrice(item?.price)} {getPriceSuffix(item)}
            </p>
            <p className="mt-2 text-[10px] font-[800] uppercase tracking-[0.16em] text-[rgba(22,32,50,0.5)]">
              {durationMinutes} mins at-home session
            </p>
          </div>

          <Button
            className="serviceCard__bookButton serviceCard__bookButton--compact !rounded-full xl:min-w-[150px]"
            size="small"
            onClick={handleBookNow}
          >
            BOOK NOW
          </Button>
        </div>
      </div>
    </article>
  );
};

export default ProductItemListView;
