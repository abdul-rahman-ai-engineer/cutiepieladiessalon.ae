import React from "react";
import {
  MdOutlineCalendarMonth,
  MdOutlineEdit,
  MdOutlineLocationOn,
  MdOutlinePayment,
  MdOutlineSpa,
} from "react-icons/md";
import { formatPrice } from "../../utils/formatPrice";
import {
  formatAddressMeta,
  getAddressLocationLabel,
} from "../../utils/address";

const DetailRow = ({ icon: Icon, label, value, muted = false, action = null }) => (
  <div className="flex items-start gap-3 rounded-[16px] border border-[#edf2f7] bg-[#f8f9fa] px-4 py-3">
    <span className="mt-0.5 inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white text-[var(--booking-accent-strong)]">
      <Icon className="text-[18px]" />
    </span>

    <div className="min-w-0 flex-1">
      <p className="m-0 text-[11px] font-[800] uppercase tracking-[0.16em] text-[var(--booking-muted)]">
        {label}
      </p>
      <p
        className={`m-0 mt-1 text-[14px] leading-6 ${
          muted ? "text-[var(--booking-muted)]" : "font-[600] text-[var(--booking-text)]"
        }`}
      >
        {value}
      </p>
    </div>

    {action}
  </div>
);

const MoneyRow = ({ label, value, emphasis = false, tone = "default" }) => (
  <div className="flex items-center justify-between gap-3 text-[14px]">
    <span className={emphasis ? "font-[700] text-[var(--booking-text)]" : "text-[var(--booking-muted)]"}>
      {label}
    </span>
    <span
      className={`${
        tone === "positive"
          ? "font-[700] text-[#16a34a]"
          : emphasis
          ? "font-[700] text-[var(--booking-text)]"
          : "font-[600] text-[var(--booking-text)]"
      }`}
    >
      {value}
    </span>
  </div>
);

const SummaryCard = ({
  service,
  summary,
  quantity,
  selectedAddOns,
  selectedDateLabel,
  selectedSlotLabel,
  instantRequested,
  paymentMethod,
  selectedAddress,
  onEditAddress,
  currentStep,
  steps,
  onNext,
  onBack,
  onConfirm,
  isSubmitting,
  isPrimaryActionDisabled,
}) => {
  const totalSteps = steps?.length || 4;
  const hasSelectedService = Number(quantity) > 0;
  const serviceDurationLabel = Number(service?.durationMinutes || 0)
    ? `${service.durationMinutes} mins`
    : "";
  const subtotalValue = Number(summary?.subtotal || 0);
  const discountValue = Number(summary?.discount || 0);
  const totalValue = Number(summary?.total || 0);
  const actionLabel =
    currentStep === totalSteps - 1
      ? isSubmitting
        ? paymentMethod === "tamara"
          ? "Opening Tamara..."
          : "Completing booking..."
        : paymentMethod === "tamara"
        ? "Continue to Tamara"
        : "Complete booking"
      : currentStep === 0
      ? "Continue to add-ons"
      : currentStep === 1
      ? "Continue to date & time"
      : "Continue to checkout";
  const handlePrimaryAction = currentStep === totalSteps - 1 ? onConfirm : onNext;
  const addressLabel = selectedAddress
    ? `${getAddressLocationLabel(selectedAddress)}${formatAddressMeta(selectedAddress) ? `, ${formatAddressMeta(selectedAddress)}` : ""}`
    : "Choose or add a Dubai location";
  const scheduleLabel = !hasSelectedService
    ? "Choose a service first"
    : instantRequested
    ? "Instant booking"
    : selectedDateLabel && selectedSlotLabel
    ? `${selectedDateLabel}, ${selectedSlotLabel}`
    : "Choose your preferred date and time";
  const addOnLabel = hasSelectedService
    ? selectedAddOns?.length
      ? `${selectedAddOns.length} add-on${selectedAddOns.length > 1 ? "s" : ""} selected`
      : "No add-ons selected"
    : "Add-ons appear after choosing a service";
  const paymentLabel =
    paymentMethod === "tamara"
      ? "Tamara"
      : paymentMethod === "cash"
      ? "Cash on visit"
      : "Credit / Debit Card";
  const shellClassName = "rounded-[22px] border border-[#e7edf4] bg-white p-4 sm:p-5";
  const detailCardClassName = hasSelectedService
    ? "rounded-[22px] border border-[#cfe7f7] bg-white p-5 sm:p-6"
    : shellClassName;
  const selectedServiceLabel = hasSelectedService
    ? `${quantity}x ${service?.name || "Selected service"}`
    : "";

  return (
    <aside className="space-y-3">
      <div className={detailCardClassName}>
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="m-0 text-[12px] font-[800] uppercase tracking-[0.18em] text-[var(--booking-muted)]">
              Booking details
            </p>
            <h2 className="mt-2 text-[24px] font-[800] leading-[1.12] text-[var(--booking-text)]">
              Your booking
            </h2>
            <p className="m-0 mt-2 text-[14px] leading-6 text-[var(--booking-muted)]">
              {hasSelectedService
                ? `${selectedServiceLabel} is ready for scheduling and checkout.`
                : "Choose a service to start building the booking."}
            </p>
          </div>

          <button
            type="button"
            onClick={onEditAddress}
            className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-[#e2e8f0] bg-white text-[var(--booking-text)] transition hover:border-[var(--booking-accent-strong)] hover:text-[var(--booking-accent-strong)]"
            aria-label="Edit booking address"
          >
            <MdOutlineEdit className="text-[18px]" />
          </button>
        </div>

        <div className="mt-4 space-y-3">
          <DetailRow
            icon={MdOutlineLocationOn}
            label="Location"
            value={addressLabel}
            muted={!selectedAddress}
          />
          <DetailRow
            icon={MdOutlineSpa}
            label="Service"
            value={
              hasSelectedService
                ? [serviceDurationLabel, `${quantity}x ${service?.name || "Selected service"}`]
                    .filter(Boolean)
                    .join(" - ")
                : "No service selected yet"
            }
            muted={!hasSelectedService}
          />
          <DetailRow
            icon={MdOutlineCalendarMonth}
            label="Date & time"
            value={scheduleLabel}
            muted={!hasSelectedService}
          />
          <DetailRow icon={MdOutlineSpa} label="Add-ons" value={addOnLabel} muted={!selectedAddOns?.length} />
          <DetailRow
            icon={MdOutlinePayment}
            label="Payment"
            value={paymentLabel}
            muted={currentStep < totalSteps - 1}
          />
        </div>
      </div>

      <div className={shellClassName}>
        <div className="flex items-center justify-between gap-3">
          <div>
            <p className="m-0 text-[12px] font-[800] uppercase tracking-[0.18em] text-[var(--booking-muted)]">
              Payment summary
            </p>
            <p className="m-0 mt-1 text-[13px] text-[var(--booking-muted)]">
              Updated live while you build the booking.
            </p>
          </div>

          {hasSelectedService ? (
            <span className="rounded-full bg-[#f2fbff] px-3 py-1 text-[11px] font-[800] uppercase tracking-[0.14em] text-[var(--booking-accent-strong)]">
              {quantity} item{quantity > 1 ? "s" : ""}
            </span>
          ) : null}
        </div>

        {hasSelectedService ? (
          <div className="mt-4 rounded-[18px] border border-[#edf2f7] bg-[#f8f9fa] px-4 py-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="m-0 text-[14px] font-[700] text-[var(--booking-text)]">
                  {quantity}x {service?.name || "Selected service"}
                </p>
                <p className="m-0 mt-1 text-[13px] leading-6 text-[var(--booking-muted)]">
                  {selectedAddOns?.length
                    ? `${selectedAddOns.length} add-on${selectedAddOns.length > 1 ? "s" : ""} attached`
                    : "No add-ons attached yet"}
                </p>
              </div>

              {serviceDurationLabel ? (
                <span className="rounded-full border border-[#dbe9f3] bg-white px-3 py-1 text-[11px] font-[800] uppercase tracking-[0.12em] text-[var(--booking-accent-strong)]">
                  {serviceDurationLabel}
                </span>
              ) : null}
            </div>
          </div>
        ) : null}

        <div className="mt-4 space-y-3">
          <MoneyRow label="Subtotal" value={formatPrice(subtotalValue)} />
          {discountValue > 0 ? (
            <MoneyRow label="Discounts" value={`- ${formatPrice(discountValue)}`} tone="positive" />
          ) : null}
        </div>

        <div className="mt-4 rounded-[16px] border border-[#e2ebf3] bg-[#f7f9fa] px-4 py-4">
          <MoneyRow label="Total" value={formatPrice(totalValue)} emphasis />
        </div>
      </div>

      <div className="rounded-[22px] border border-[#e7edf4] bg-white p-3.5 sm:p-4">
        {currentStep > 0 ? (
          <button
            type="button"
            onClick={onBack}
            className="mb-3 w-full rounded-[14px] border border-[#e2e8f0] px-5 py-3 text-[14px] font-[700] text-[var(--booking-text)] transition hover:border-[var(--booking-accent-strong)] hover:text-[var(--booking-accent-strong)]"
          >
            Back
          </button>
        ) : null}

        <button
          type="button"
          onClick={handlePrimaryAction}
          disabled={isSubmitting || isPrimaryActionDisabled}
          className="w-full rounded-[14px] bg-[var(--booking-accent-strong)] px-5 py-4 text-[15px] font-[800] text-white transition hover:brightness-[0.98] disabled:cursor-not-allowed disabled:opacity-60"
        >
          {actionLabel}
        </button>
      </div>
    </aside>
  );
};

export default SummaryCard;
