import React, { useMemo } from "react";
import Button from "@mui/material/Button";
import Rating from "@mui/material/Rating";
import { useNavigate } from "react-router-dom";
import { MdAccessTime, MdOutlineLocationOn } from "react-icons/md";
import { formatPrice } from "../../utils/formatPrice";
import { getPriceSuffix } from "../../utils/productPricing";
import { isServiceCatalogItem } from "../../utils/productType";

export const ProductDetailsComponent = (props) => {
  const navigate = useNavigate();
  const specifications = Array.isArray(props?.item?.specifications)
    ? props.item.specifications
    : [];
  const isServiceItem = isServiceCatalogItem(props?.item);

  const visibleSpecifications = useMemo(() => {
    return specifications.filter((spec) => spec?.visible !== false);
  }, [specifications]);

  const isEmptySpecValue = (value) => {
    const normalized = String(value || "").trim().toLowerCase();
    return !normalized || normalized === "-" || normalized === "n/a" || normalized === "na" || normalized === "null";
  };

  const getSpecText = (spec) => {
    if (Array.isArray(spec?.values) && spec.values.length) {
      const value = spec.values
        .map((entry) => String(entry || "").trim())
        .filter((entry) => !isEmptySpecValue(entry))
        .join(", ")
        .trim();
      return value || "-";
    }

    const single = String(spec?.value || "").trim();
    return single || "-";
  };

  const findSpecByAliases = (aliases = []) => {
    return visibleSpecifications.find((spec) => {
      const specName = String(spec?.name || "").trim().toLowerCase();
      return aliases.some((alias) => specName.includes(alias.toLowerCase()));
    });
  };

  const mappedSpecs = [
    { label: "Dimensions", aliases: ["dimensions", "dimension", "size", "l x w x h", "lxwxh"] },
    { label: "Material", aliases: ["material"] },
    { label: "Brand", aliases: ["brand", "manufacturer"] },
    { label: "Installation", aliases: ["installation", "installation type", "setup"] },
  ];

  const usedSpecNames = new Set();

  const mappedRows = mappedSpecs.map((item) => {
    const matchedSpec = findSpecByAliases(item.aliases);
    if (matchedSpec?.name) {
      usedSpecNames.add(String(matchedSpec.name).trim().toLowerCase());
    }

    if (item.label === "Brand") {
      return {
        label: item.label,
        value: String(props?.item?.brand || getSpecText(matchedSpec) || "-").trim() || "-",
      };
    }

    return {
      label: item.label,
      value: matchedSpec ? getSpecText(matchedSpec) : "-",
    };
  });

  const additionalRows = visibleSpecifications
    .filter((spec) => !usedSpecNames.has(String(spec?.name || "").trim().toLowerCase()))
    .map((spec) => ({
      label: String(spec?.name || "Attribute").trim() || "Attribute",
      value: getSpecText(spec),
    }));

  const detailRows = [...mappedRows, ...additionalRows].filter((row) => {
    const label = String(row?.label || "").trim();
    return label && !isEmptySpecValue(row?.value);
  });

  const handleBookNow = () => {
    navigate(`/product/${props?.item?._id}`, {
      state: { autoAdd: isServiceItem ? 1 : true },
    });
  };

  return (
    <>
      <h1 className="mb-2 text-[18px] font-[600] sm:text-[22px]">
        {props?.item?.name}
      </h1>

      <div className="flex flex-col items-start justify-start gap-3 sm:flex-row sm:items-center md:flex-row lg:flex-row lg:items-center">
        <span className="text-[13px] text-gray-400">
          Brand:{" "}
          <span className="font-[500] text-black opacity-75">
            {props?.item?.brand}
          </span>
        </span>

        <Rating name="size-small" value={props?.item?.rating} size="small" readOnly />
        <span className="cursor-pointer text-[13px]" onClick={props.gotoReviews}>
          Review ({props.reviewsCount})
        </span>
      </div>

      <div className="mt-4 flex flex-col items-start gap-4 sm:flex-row sm:items-center md:flex-row lg:flex-row">
        <div className="flex items-center gap-4">
          <span className="oldPrice text-[20px] font-[500] text-gray-500 line-through">
            {formatPrice(props?.item?.oldPrice)}
          </span>
          <span className="price text-[20px] font-[600] text-primary">
            {formatPrice(props?.item?.price)} {getPriceSuffix(props?.item)}
          </span>
        </div>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        <span className="inline-flex items-center gap-2 rounded-full border border-[rgba(0,0,0,0.1)] bg-[#f7f9fa] px-3 py-2 text-[12px] font-[700] text-[#111827]">
          <MdAccessTime className="text-[16px] text-primary" />
          {Number(props?.item?.durationMinutes || 60)} mins
        </span>
        <span className="inline-flex items-center gap-2 rounded-full border border-[rgba(0,0,0,0.1)] bg-[#f7f9fa] px-3 py-2 text-[12px] font-[700] text-[#111827]">
          <MdOutlineLocationOn className="text-[16px] text-primary" />
          {props?.item?.locationType === "salon" ? "In-salon service" : "At-home service"}
        </span>
      </div>

      <p className="mb-5 mt-3 pr-10">
        {props?.item?.description}
      </p>

      <div className="mt-6 overflow-hidden rounded-md border border-[rgba(0,0,0,0.12)]">
        <div className="border-b border-[rgba(0,0,0,0.08)] bg-[#f6f6f6] px-4 py-3">
          <h3 className="text-[16px] font-[600]">Service Details</h3>
        </div>
        <div className="grid grid-cols-1 gap-0 md:grid-cols-2">
          {detailRows.map((row, index) => (
            <div
              key={`${row.label}-${index}`}
              className="grid grid-cols-2 border-b border-[rgba(0,0,0,0.08)]"
            >
              <span className="border-r border-[rgba(0,0,0,0.08)] bg-[#fafafa] px-4 py-3 text-[13px] font-[500]">
                {row.label}
              </span>
              <span className="px-4 py-3 text-[13px]">{row.value}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="py-4">
        <Button className="btn-org flex !min-w-[150px] gap-2" onClick={handleBookNow}>
          BOOK NOW
        </Button>
      </div>
    </>
  );
};
