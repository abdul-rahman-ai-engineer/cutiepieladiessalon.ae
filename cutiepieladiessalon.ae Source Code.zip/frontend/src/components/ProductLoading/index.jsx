import React from "react";

const ProductLoading = () => {
  const skeletonItems = Array.from({ length: 4 });

  return (
    <div className="grid grid-cols-1 gap-6 py-2 sm:grid-cols-2 lg:grid-cols-4">
      {skeletonItems.map((_, index) => (
        <div
          key={index}
          className="animate-pulse overflow-hidden rounded-[12px] border border-[#eee5e3] bg-white shadow-[0_8px_24px_rgba(29,18,18,0.06)]"
        >
          <div className="aspect-square bg-[#f3ecea]"></div>
          <div className="space-y-3 p-4">
            <div className="h-2.5 w-28 rounded-full bg-[#efe8e6]"></div>
            <div className="h-4 w-full rounded-full bg-[#f3ecea]"></div>
            <div className="h-4 w-4/5 rounded-full bg-[#f3ecea]"></div>
            <div className="flex items-center gap-2">
              <div className="h-3 w-20 rounded-full bg-[#f1e8df]"></div>
              <div className="h-3 w-10 rounded-full bg-[#efe8e6]"></div>
            </div>
            <div className="flex items-end justify-between gap-3">
              <div className="h-3 w-16 rounded-full bg-[#efe8e6]"></div>
              <div className="h-4 w-24 rounded-full bg-[#ffd6d1]"></div>
            </div>
            <div className="h-px w-full bg-[#f3ecea]"></div>
            <div className="h-3 w-40 rounded-full bg-[#efe8e6]"></div>
            <div className="flex items-center gap-2 pt-2">
              <div className="h-11 flex-1 rounded-full bg-[#ffd6d1]"></div>
              <div className="h-11 w-11 rounded-full bg-[#fbe7e4]"></div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ProductLoading;
