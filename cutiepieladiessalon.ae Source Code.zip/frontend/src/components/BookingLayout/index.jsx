import React from "react";
import { MdArrowBack, MdCheck } from "react-icons/md";

const BookingLayout = ({
  topBar,
  headerTitle,
  headerDescription,
  currentStep = 0,
  steps = [],
  onBack,
  categoryRail,
  sidebar,
  children,
}) => {
  const totalSteps = steps.length || 4;
  const progress = Math.min(100, Math.max(0, ((currentStep + 1) / totalSteps) * 100));
  const activeStep = steps[currentStep];
  const resolvedHeaderTitle =
    headerTitle === undefined ? "Book your home salon service" : headerTitle;
  const resolvedHeaderDescription =
    headerDescription === undefined
      ? "Move through service selection, add-ons, scheduling, and payment in a cleaner step-by-step flow."
      : headerDescription;
  const showHeaderCopy = Boolean(resolvedHeaderTitle || resolvedHeaderDescription);

  return (
    <section
      className="bg-[linear-gradient(180deg,#f5f7fb_0%,#ffffff_22%)] pb-8 lg:pb-10"
      style={{ fontFamily: '"Inter", sans-serif' }}
    >
      {topBar ? <div className="sticky top-0 z-40">{topBar}</div> : null}

      <div className="border-b border-[#edf2f7] bg-white/80 backdrop-blur-xl">
        <div className="container py-4 lg:py-5">
          <div className="rounded-[24px] border border-[#e7edf4] bg-white px-4 py-4 shadow-[0_18px_38px_rgba(15,23,42,0.04)] sm:px-5 lg:px-6">
            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={onBack}
                className="inline-flex items-center gap-2 rounded-full border border-[#e2e8f0] bg-[#f8f9fa] px-4 py-2 text-[14px] font-[700] text-[var(--booking-text)] transition hover:border-[var(--booking-accent-strong)] hover:text-[var(--booking-accent-strong)]"
              >
                <MdArrowBack className="text-[19px]" />
                Back
              </button>

              <span className="rounded-full bg-[#f7f9fa] px-4 py-2 text-[13px] font-[700] text-[var(--booking-text)]">
                Step {currentStep + 1} of {totalSteps}
              </span>

              {activeStep ? (
                <span className="rounded-full border border-[#e2e8f0] px-4 py-2 text-[12px] font-[800] uppercase tracking-[0.16em] text-[var(--booking-accent-strong)]">
                  {activeStep.title}
                </span>
              ) : null}
            </div>

            {showHeaderCopy ? (
              <div className="mt-5">
                {resolvedHeaderTitle ? (
                  <h1 className="max-w-3xl text-[28px] font-[800] leading-[1.05] text-[var(--booking-text)] lg:text-[36px]">
                    {resolvedHeaderTitle}
                  </h1>
                ) : null}
                {resolvedHeaderDescription ? (
                  <p className="mt-3 max-w-2xl text-[15px] leading-7 text-[var(--booking-muted)]">
                    {resolvedHeaderDescription}
                  </p>
                ) : null}
              </div>
            ) : null}

            <div className={showHeaderCopy ? "mt-5" : "mt-4"}>
              <div className="h-1.5 rounded-full bg-[#edf2f7]">
                <div
                  className="h-full rounded-full bg-[var(--booking-accent-strong)] transition-[width] duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>

              <div className="mt-3 grid gap-3 lg:grid-cols-4">
                {steps.map((step, index) => {
                  const isComplete = index < currentStep;
                  const isActive = index === currentStep;

                  return (
                    <div
                      key={step.key || step.label || index}
                      className={`rounded-[16px] border px-4 py-3.5 transition ${
                        isActive
                          ? "border-[var(--booking-accent-strong)] bg-[#f2fbff]"
                          : isComplete
                          ? "border-[#d8edf7] bg-[#f8fcff]"
                          : "border-[#e8edf3] bg-white"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span
                          className={`inline-flex h-8 w-8 items-center justify-center rounded-full border text-[12px] font-[800] ${
                            isActive
                              ? "border-[var(--booking-accent-strong)] bg-white text-[var(--booking-accent-strong)]"
                              : isComplete
                              ? "border-[#bfe1ef] bg-[#eefdff] text-[var(--booking-accent-strong)]"
                              : "border-[#d8e1eb] bg-[#f7f9fa] text-[var(--booking-muted)]"
                          }`}
                        >
                          {isComplete ? <MdCheck className="text-[18px]" /> : index + 1}
                        </span>

                        <div className="min-w-0">
                          <p className="m-0 text-[11px] font-[800] uppercase tracking-[0.18em] text-[var(--booking-muted)]">
                            {step.label}
                          </p>
                          <p className="m-0 mt-1 text-[14px] font-[700] text-[var(--booking-text)]">
                            {step.title}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {categoryRail ? <div className="mt-6">{categoryRail}</div> : null}
          </div>
        </div>
      </div>

      <div className="container py-5 lg:py-6">
        <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_340px] 2xl:grid-cols-[minmax(0,1fr)_360px]">
          <div className="min-w-0">{children}</div>
          <div className="xl:sticky xl:top-24 xl:self-start">{sidebar}</div>
        </div>
      </div>
    </section>
  );
};

export default BookingLayout;
