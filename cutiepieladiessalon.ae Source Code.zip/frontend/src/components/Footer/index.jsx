import React, { useContext } from "react";
import {
  TbBuildingStore,
  TbCalendarTime,
  TbCircleCheck,
  TbHeadset,
  TbScissors,
} from "react-icons/tb";
import { Link } from "react-router-dom";
import { IoChatboxOutline } from "react-icons/io5";

import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import { FaFacebookF } from "react-icons/fa";
import { AiOutlineYoutube } from "react-icons/ai";
import { FaPinterestP } from "react-icons/fa";
import { FaInstagram } from "react-icons/fa";

import Drawer from "@mui/material/Drawer";
import { MyContext } from "../../App";
import BookingFooter from "../BookingFooter";


import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import { ProductZoom } from "../ProductZoom";
import { IoCloseSharp } from "react-icons/io5";
import { ProductDetailsComponent } from "../ProductDetails";
import AddAddress from "../../Pages/MyAccount/addAddress";

const bookingSteps = [
  {
    title: "Choose Your Service",
    description:
      "",
    Icon: TbScissors,
  },
  {
    title: "Select a Services",
    description:
      "",
    Icon: TbBuildingStore,
  },
  {
    title: "Choose Date & Time",
    description:
      "",
    Icon: TbCalendarTime,
  },
  {
    title: "Confirm Your Booking",
    description:
      "",
    Icon: TbCircleCheck,
  },
  {
    title: "Enjoy & Get Support",
    description:
      "",
    Icon: TbHeadset,
  },
];

const Footer = ({ hideChrome = false }) => {
  const context = useContext(MyContext);

  return (
    <>
      {!hideChrome ? (
        <>
          <footer className="py-6 bg-[#fafafa]">
        <div className="container">
          <section className="px-0 py-4 lg:px-4 lg:py-8">
            <div className="mx-auto max-w-3xl text-center">
              <span className="inline-flex rounded-full bg-[rgba(255,82,82,0.08)] px-4 py-1 text-[11px] font-[600] uppercase tracking-[0.22em] text-primary">
                How It Works
              </span>
              
             
            </div>

            <div className="mt-8 grid grid-cols-1 gap-4 sm:mt-10 sm:gap-5 md:grid-cols-2 lg:grid-cols-5">
              {bookingSteps.map(({ title, description, Icon }, index) => (
                <article
                  key={title}
                  className="group flex h-full flex-col items-center rounded-[28px] border border-[rgba(15,23,42,0.08)] bg-white px-5 py-6 text-center shadow-[0_10px_30px_rgba(15,23,42,0.04)] transition-all duration-300 hover:-translate-y-[5px] hover:border-[rgba(255,82,82,0.14)] hover:shadow-[0_18px_40px_rgba(15,23,42,0.08)]"
                >
                  <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-[rgba(255,82,82,0.08)] text-3xl text-[#1f2937] transition-all duration-300 group-hover:bg-primary group-hover:text-white">
                    <Icon />
                  </div>
                  <span className="mt-4 rounded-full bg-[rgba(15,23,42,0.04)] px-3 py-1 text-[11px] font-[600] uppercase tracking-[0.18em] text-gray-400">
                    Step {index + 1}
                  </span>
                  <h3 className="mt-4 text-base font-semibold text-[#1f2937] transition-colors duration-300 group-hover:text-primary">
                    {title}
                  </h3>
                  <p className="mt-3 text-sm leading-6 text-gray-500">
                    {description}
                  </p>
                </article>
              ))}
            </div>

            <div className="mt-10 h-px w-full bg-[rgba(15,23,42,0.08)]" />
          </section>

          <div className="footer flex px-3 lg:px-0 flex-col lg:flex-row py-8">
            <div className="part1 w-full lg:w-[25%] border-r border-[rgba(0,0,0,0.1)]">
              <h2 className="text-[18px] font-[600] mb-4">Contact us</h2>
              <p className="text-[13px] font-[400] pb-4">
                📍 Shop G06, Cambridge Business Center,
                <br />
                Dubai Silicon Oasis, Dubai,
                 <br />
                United Arab Emirates, Pincode 341041.
              </p>

              <Link
                className="link text-[13px]"
                to="mailto:cutiepiesalonfze@gmail.com"
              >
                ✉  cutiepiesalonfze@gmail.com
              </Link>

              

              <span className="text-[22px] font-[600] block w-full mt-3 mb-5 text-primary">
                (+971) 52 977 5859
              </span>

              <div className="flex items-center gap-2">
                <IoChatboxOutline className="text-[40px] text-primary" />
                <span className="text-[16px] font-[600]">
                  Online Chat
                  <br />
                  Get Expert Help
                </span>
              </div>
            </div>

            <div className="part2  w-full lg:w-[40%] flex pl-0 lg:pl-8 mt-5 lg:mt-0">
              <div className="part2_col1 w-[50%]">
                <h2 className="text-[18px] font-[600] mb-4">Know About Us</h2>

                <ul className="list">
                  <li className="list-none text-[14px] w-full mb-2">
                    <Link to="/" className="link">
                      ✅ Help & FAQs
                    </Link>
                  </li>
                  <li className="list-none text-[14px] w-full mb-2">
                    <Link to="/" className="link">
                      ✅ Blogs
                    </Link>
                  </li>
                  <li className="list-none text-[14px] w-full mb-2">
                    <Link to="/" className="link">
                      ✅ About Us
                    </Link>
                  </li>
                  <li className="list-none text-[14px] w-full mb-2">
                    <Link to="/" className="link">
                      ✅ Contact Us
                    </Link>
                  </li>
                  <li className="list-none text-[14px] w-full mb-2">
                    <Link to="/" className="link">
                      ✅ Career
                    </Link>
                  </li>
                  <li className="list-none text-[14px] w-full mb-2">
                    <Link to="/" className="link">
                      ✅ Make an Enquiry
                    </Link>
                  </li>
                </ul>
              </div>

              <div className="part2_col2 w-[50%]">
                <h2 className="text-[18px] font-[600] mb-4">Find us on social</h2>

                <ul className="list">
                  <li className="list-none text-[14px] w-full mb-2">
                    <Link to="https://www.youtube.com/@Cutie-Pie-Beauty-Salon" className="link">
                      ✅ youtube
                    </Link>
                  </li>
                  <li className="list-none text-[14px] w-full mb-2">
                    <Link to="https://www.facebook.com/beautysaloncutiepie" className="link">
                      ✅ facebook
                    </Link>
                  </li>
                  <li className="list-none text-[14px] w-full mb-2">
                    <Link to="https://www.instagram.com/cutiepiebeautysalon/" className="link">
                      ✅ instagram
                    </Link>
                  </li>
                  <li className="list-none text-[14px] w-full mb-2">
                    <Link to="/" className="link">
                      ✅ linkedin
                    </Link>
                  </li>
                  <li className="list-none text-[14px] w-full mb-2">
                    <Link to="https://in.pinterest.com/cutiepiecute606/" className="link">
                      ✅ pinterest
                    </Link>
                  </li>
                  <li className="list-none text-[14px] w-full mb-2">
                    <Link to="https://www.tiktok.com/@cutiepiebeautysalon" className="link">
                      ✅ tiktok
                    </Link>
                  </li>
                  <li className="list-none text-[14px] w-full mb-2">
                    <Link to="https://x.com/cutiepie9350" className="link">
                      ✅ twitter
                    </Link>
                  </li>
                </ul>
              </div>
            </div>

            <div className="part2 w-full lg:w-[35%] flex pl-0 lg:pl-8 flex-col pr-8 mt-5 lg:mt-0">
  <h2 className="text-[18px] font-[600] mb-4">
    Location
  </h2>

  {/* Google Map */}
  <div className="w-full h-[220px] rounded-md overflow-hidden border border-gray-700">
    <iframe
      title="Cutie Pie Beauty Salon"
      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3612.5609657983305!2d55.372097000000004!3d25.1167189!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f6575cf74afd7%3A0x45f1d72d8e6e68cf!2sCutie%20Pie%20Beauty%20Salon!5e0!3m2!1sen!2sae!4v1776752444138!5m2!1sen!2sae"
      className="w-full h-full"
      loading="lazy"
      referrerPolicy="no-referrer-when-downgrade"
    />
  </div>


</div>

          </div>


        </div>

        
          </footer>

          <div className="bottomStrip border-t border-[rgba(0,0,0,0.1)] pt-3 pb-[100px] lg:pb-3 bg-white">
        <div className="container flex items-center justify-between flex-col lg:flex-row gap-4 lg:gap-0">
          <ul className="flex items-center gap-2">
            <li className="list-none">
              <Link
                to="https://www.facebook.com/beautysaloncutiepie"
                target="_blank"
                className="w-[35px] h-[35px] rounded-full border border-[rgba(0,0,0,0.1)] flex items-center justify-center group hover:bg-primary transition-all"
              >
                <FaFacebookF className="text-[17px] group-hover:text-white" />
              </Link>
            </li>

            <li className="list-none">
              <Link
                to="https://www.youtube.com/@Cutie-Pie-Beauty-Salon"
                target="_blank"
                className="w-[35px] h-[35px] rounded-full border border-[rgba(0,0,0,0.1)] flex items-center justify-center group hover:bg-primary transition-all"
              >
                <AiOutlineYoutube className="text-[21px] group-hover:text-white" />
              </Link>
            </li>

            <li className="list-none">
              <Link
                to="https://in.pinterest.com/cutiepiecute606/"
                target="_blank"
                className="w-[35px] h-[35px] rounded-full border border-[rgba(0,0,0,0.1)] flex items-center justify-center group hover:bg-primary transition-all"
              >
                <FaPinterestP className="text-[17px] group-hover:text-white" />
              </Link>
            </li>

            <li className="list-none">
              <Link
                to="https://www.instagram.com/cutiepiebeautysalon/"
                target="_blank"
                className="w-[35px] h-[35px] rounded-full border border-[rgba(0,0,0,0.1)] flex items-center justify-center group hover:bg-primary transition-all"
              >
                <FaInstagram className="text-[17px] group-hover:text-white" />
              </Link>
            </li>
          </ul>

          <p className="text-[13px] text-center mb-0">
            © 2026 - CUTIE PIE BEAUTY SALON - FZE
          </p>


          <div className="flex items-center gap-1">
            <img src="/carte_bleue.png" alt="image" />
            <img src="/visa.png" alt="image" />
            <img src="/master_card.png" alt="image" />
            <img src="/american_express.png" alt="image" />
            <img src="/paypal.png" alt="image" />
          </div>


        </div>
          </div>
        </>
      ) : (
        <BookingFooter />
      )}


      {/* Address Panel */}
      <Drawer
        open={context.openAddressPanel}
        onClose={context.toggleAddressPanel(false)}
        anchor={"right"}
        className="addressPanel"
      >
        <div className="flex items-center justify-between py-3 px-4 gap-3 border-b border-[rgba(0,0,0,0.1)] overflow-hidden">
          <h4>{`${context?.addressMode === "add" ? "Add" : "Edit"} Location`}</h4>
          <IoCloseSharp className="text-[20px] cursor-pointer" onClick={context.toggleAddressPanel(false)} />
        </div>



        <div className="w-full max-h-[100vh] overflow-auto">
          <AddAddress />
        </div>



      </Drawer>





      <Dialog
        open={context?.openProductDetailsModal.open}
        fullWidth={context?.fullWidth}
        maxWidth={context?.maxWidth}
        onClose={context?.handleCloseProductDetailsModal}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        className="productDetailsModal"
      >
        <DialogContent>
          <div className="flex items-center w-full productDetailsModalContainer relative">
            <Button
              className="!w-[40px] !h-[40px] !min-w-[40px] !rounded-full !text-[#000] !absolute top-[15px] right-[15px] !bg-[#f1f1f1]"
              onClick={context?.handleCloseProductDetailsModal}
            >
              <IoCloseSharp className="text-[20px]" />
            </Button>
            {
              context?.openProductDetailsModal?.item?.length !== 0 &&
              <>
                <div className="col1 w-[40%] px-3 py-8">
                  <ProductZoom images={context?.openProductDetailsModal?.item?.images} />
                </div>

                <div className="col2 w-[60%] py-8 px-8 pr-16 productContent ">
                  <ProductDetailsComponent item={context?.openProductDetailsModal?.item} />
                </div>
              </>
            }

          </div>
        </DialogContent>
      </Dialog>



    </>
  );
};

export default Footer;



