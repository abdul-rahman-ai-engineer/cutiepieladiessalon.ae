import React from "react";
import { Link } from "react-router-dom";
import {
  MdOutlineEmail,
  MdOutlineLocationOn,
  MdOutlinePhoneInTalk,
} from "react-icons/md";

const serviceAreaPills = [
  "Home Salon",
  "Classic Manicure",
  "Classic Pedicure",
  "Hair Styling",
  "Hair Removal",
  "Facial Treatments",
  "Massage",
  "Henna Service",
  "Bridal Packages",
  "Combos",
];

const cityPills = ["Dubai", "Sharjah", "Ajman", "Abu Dhabi"];

const footerLinks = [
  { label: "Contact Us", to: "/" },
  { label: "F.A.Q", to: "/" },
  { label: "Terms", to: "/" },
  { label: "Privacy", to: "/" },
  { label: "Sitemap", to: "/" },
  { label: "Blog", to: "/" },
  { label: "Career", to: "/" },
];

const pillClassName =
  "inline-flex items-center rounded-full border border-white/10 bg-black/35 px-3 py-2 text-[12px] font-[700] text-white/92 transition hover:border-[var(--booking-accent)] hover:text-white";

const BookingFooter = () => {
  return (
    <footer className="border-t border-white/6 bg-[#1f1f1f] text-white">
      <div className="container py-10 lg:py-12">
        <div className="grid gap-8 xl:grid-cols-[minmax(0,1.05fr)_minmax(320px,0.95fr)] xl:items-start">
          <div>
            <p className="m-0 text-[11px] font-[800] uppercase tracking-[0.2em] text-white/55">
              Cutie Pie At Home
            </p>
            <h2 className="mt-3 text-[28px] font-[800] leading-[1.05] text-white">
              Beauty bookings designed to move as smoothly as the service itself.
            </h2>
            <p className="mt-3 max-w-2xl text-[14px] leading-7 text-white/65">
              Compare services, choose your preferred time, and complete the booking without
              losing the live summary on the right.
            </p>

            <div className="mt-7">
              <p className="m-0 text-[14px] font-[700] text-white">Service areas</p>
              <div className="mt-4 flex flex-wrap gap-3">
                {serviceAreaPills.map((item) => (
                  <span key={item} className={pillClassName}>
                    {item}
                  </span>
                ))}
              </div>
            </div>

            <div className="mt-8">
              <p className="m-0 text-[14px] font-[700] text-white">United Arab Emirates</p>
              <div className="mt-4 flex flex-wrap gap-3">
                {cityPills.map((item) => (
                  <span key={item} className={pillClassName}>
                    {item}
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div className="rounded-[28px] border border-white/8 bg-white/[0.04] p-6 shadow-[0_20px_48px_rgba(0,0,0,0.18)]">
            <p className="m-0 text-[11px] font-[800] uppercase tracking-[0.2em] text-white/55">
              Need help?
            </p>
            <h3 className="mt-3 text-[24px] font-[800] text-white">We keep support close.</h3>
            <p className="mt-3 text-[14px] leading-7 text-white/65">
              Reach out before checkout if you need help with service availability, location
              coverage, or booking changes.
            </p>

            <div className="mt-6 space-y-3">
              <a
                href="tel:+971529775859"
                className="flex items-center gap-3 rounded-[18px] border border-white/8 bg-black/20 px-4 py-4 text-white no-underline transition hover:border-[var(--booking-accent)]"
              >
                <span className="inline-flex h-11 w-11 items-center justify-center rounded-full bg-white/8 text-[var(--booking-accent)]">
                  <MdOutlinePhoneInTalk className="text-[20px]" />
                </span>
                <span>
                  <span className="block text-[11px] font-[800] uppercase tracking-[0.16em] text-white/50">
                    Call
                  </span>
                  <span className="block text-[14px] font-[700] text-white">+971 52 977 5859</span>
                </span>
              </a>

              <a
                href="mailto:cutiepiesalonfze@gmail.com"
                className="flex items-center gap-3 rounded-[18px] border border-white/8 bg-black/20 px-4 py-4 text-white no-underline transition hover:border-[var(--booking-accent)]"
              >
                <span className="inline-flex h-11 w-11 items-center justify-center rounded-full bg-white/8 text-[var(--booking-accent)]">
                  <MdOutlineEmail className="text-[20px]" />
                </span>
                <span>
                  <span className="block text-[11px] font-[800] uppercase tracking-[0.16em] text-white/50">
                    Email
                  </span>
                  <span className="block text-[14px] font-[700] text-white">
                    cutiepiesalonfze@gmail.com
                  </span>
                </span>
              </a>

              <div className="flex items-center gap-3 rounded-[18px] border border-white/8 bg-black/20 px-4 py-4">
                <span className="inline-flex h-11 w-11 items-center justify-center rounded-full bg-white/8 text-[var(--booking-accent)]">
                  <MdOutlineLocationOn className="text-[20px]" />
                </span>
                <span>
                  <span className="block text-[11px] font-[800] uppercase tracking-[0.16em] text-white/50">
                    Base
                  </span>
                  <span className="block text-[14px] font-[700] text-white">
                    Dubai Silicon Oasis, Dubai, United Arab Emirates
                  </span>
                </span>
              </div>
            </div>

            <div className="mt-6 flex flex-wrap gap-3">
              <Link
                to="/"
                className="rounded-[16px] border border-white/10 bg-white/6 px-4 py-3 text-[13px] font-[700] text-white no-underline transition hover:border-[var(--booking-accent)]"
              >
                Download on the App Store
              </Link>
              <Link
                to="/"
                className="rounded-[16px] border border-white/10 bg-white/6 px-4 py-3 text-[13px] font-[700] text-white no-underline transition hover:border-[var(--booking-accent)]"
              >
                Get it on Google Play
              </Link>
            </div>
          </div>
        </div>

        <div className="mt-10 flex flex-col gap-4 border-t border-white/8 pt-6 text-[13px] text-white/60 lg:flex-row lg:items-center lg:justify-between">
          <p className="m-0">2026 Cutie Pie Beauty Salon - FZE. Home salon bookings across the UAE.</p>
          <div className="flex flex-wrap gap-4">
            {footerLinks.map((item) => (
              <Link
                key={item.label}
                to={item.to}
                className="text-white/70 no-underline transition hover:text-white"
              >
                {item.label}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
};

export default BookingFooter;
