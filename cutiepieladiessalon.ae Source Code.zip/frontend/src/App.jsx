import React, { createContext, useContext, useEffect, useRef, useState } from "react";
import { BrowserRouter, Navigate, Route, Routes, useLocation } from "react-router-dom";
import "./App.css";
import "./responsive.css";
import Header from "./components/Header";
import Footer from "./components/Footer";
import Home from "./Pages/Home";
import ProductListing from "./Pages/ProductListing";
import { ProductDetails } from "./Pages/ProductDetails";





import Login from "./Pages/Login";
import Register from "./Pages/Register";
import Verify from "./Pages/Verify";
import ForgotPassword from "./Pages/ForgotPassword";
import MyAccount from "./Pages/MyAccount";
import Bookings from "./Pages/Bookings";

import toast, { Toaster } from 'react-hot-toast';
import { fetchDataFromApi, postData } from "./utils/api";
import {
  clearUserSession,
  getStoredAccessToken,
  getStoredRefreshToken,
  isAdminUser,
  normalizeUserRole,
  setUserSession,
} from "./utils/authSession";
import Address from "./Pages/MyAccount/address";
import { OrderSuccess } from "./Pages/Orders/success";
import { OrderFailed } from "./Pages/Orders/failed";
import SearchPage from "./Pages/Search";


const MyContext = createContext();

const normalizeAuthenticatedUser = (user = null) => {
  if (!user) {
    return null;
  }

  const adminAccount = isAdminUser(user);

  return {
    ...user,
    role: adminAccount ? "ADMIN" : normalizeUserRole(user?.role),
    isAdmin: adminAccount,
  };
};

const ProtectedRoute = ({ children }) => {
  const context = useContext(MyContext);
  const location = useLocation();

  if (!context?.isAuthReady) {
    return (
      <section className="section py-10">
        <div className="container text-center text-[14px] text-[rgba(0,0,0,0.6)]">
          Loading your account...
        </div>
      </section>
    );
  }

  if (!context?.isLogin) {
    return (
      <Navigate
        to="/login"
        replace
        state={{ from: `${location.pathname}${location.search}${location.hash}` }}
      />
    );
  }

  return children;
};

const AppShell = () => {
  return (
    <>
      <Header />
      <Routes>
        <Route path={"/"} exact={true} element={<Home />} />
        <Route
          path={"/products"}
          exact={true}
          element={<ProductListing />}
        />
        <Route
          path={"/product/:id"}
          exact={true}
          element={<ProductDetails />}
        />
        <Route path={"/login"} exact={true} element={<Login />} />
        <Route path={"/register"} exact={true} element={<Register />} />
        <Route path={"/cart"} exact={true} element={<Navigate to="/" replace />} />
        <Route path={"/verify"} exact={true} element={<Verify />} />
        <Route path={"/forgot-password"} exact={true} element={<ForgotPassword />} />
        <Route path={"/checkout"} exact={true} element={<Navigate to="/" replace />} />
        <Route path={"/my-account"} exact={true} element={<ProtectedRoute><MyAccount /></ProtectedRoute>} />
        <Route path={"/my-list"} exact={true} element={<Navigate to="/" replace />} />
        <Route path={"/my-bookings"} exact={true} element={<ProtectedRoute><Bookings /></ProtectedRoute>} />
        <Route path={"/my-orders"} exact={true} element={<Navigate to="/my-bookings" replace />} />
        <Route path={"/booking/success"} exact={true} element={<OrderSuccess />} />
        <Route path={"/booking/failed"} exact={true} element={<OrderFailed />} />
        <Route path={"/order/success"} exact={true} element={<OrderSuccess />} />
        <Route path={"/order/failed"} exact={true} element={<OrderFailed />} />
        <Route path={"/address"} exact={true} element={<ProtectedRoute><Address /></ProtectedRoute>} />
        <Route path={"/search"} exact={true} element={<SearchPage />} />
      </Routes>
      <Footer />
    </>
  );
};

function App() {
  const [openProductDetailsModal, setOpenProductDetailsModal] = useState({
    open: false,
    item: {}
  });
  const [authToken, setAuthToken] = useState(() => getStoredAccessToken());
  const [refreshToken, setRefreshToken] = useState(() => getStoredRefreshToken());
  const [isLogin, setIsLogin] = useState(() => Boolean(getStoredAccessToken()));
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [userData, setUserData] = useState(null);
  const [catData, setCatData] = useState([]);
  const [cartData, setCartData] = useState([]);
  const [myListData, setMyListData] = useState([]);
  const hasBootstrappedRef = useRef(false);

  const [openCartPanel, setOpenCartPanel] = useState(false);
  const [openAddressPanel, setOpenAddressPanel] = useState(false);

  const [addressMode, setAddressMode] = useState("add");
  const [addressId, setAddressId] = useState("");
  const [searchData, setSearchData] = useState([]);
  const [windowWidth, setWindowWidth] = useState(window.innerWidth);

  const [openFilter, setOpenFilter] = useState(false);
  const [isFilterBtnShow, setisFilterBtnShow] = useState(false);

  const [openSearchPanel, setOpenSearchPanel] = useState(false);

  const handleOpenProductDetailsModal = (status, item) => {
    setOpenProductDetailsModal({
      open: status,
      item: item
    });
  }

  const handleCloseProductDetailsModal = () => {
    setOpenProductDetailsModal({
      open: false,
      item: {}
    });
  };

  const toggleCartPanel = (newOpen) => () => {
    setOpenCartPanel(newOpen);
  };

  const toggleAddressPanel = (newOpen) => () => {
    if (newOpen == false) {
      setAddressMode("add");
    }

    setOpenAddressPanel(newOpen);
  };

  const resetAuthState = () => {
    setAuthToken("");
    setRefreshToken("");
    setIsLogin(false);
    setUserData(null);
    setCartData([]);
    setMyListData([]);
  };

  const clearAuthState = () => {
    clearUserSession();
    resetAuthState();
  };

  const setAuthSession = (authPayload = {}) => {
    const nextAccessToken = authPayload?.accesstoken || authPayload?.accessToken || "";
    const nextRefreshToken = authPayload?.refreshToken || "";
    const normalizedUser = normalizeAuthenticatedUser(authPayload?.user || authPayload);

    if (!nextAccessToken) {
      clearAuthState();
      return null;
    }

    setUserSession({
      accessToken: nextAccessToken,
      refreshToken: nextRefreshToken,
      role: normalizedUser?.role || authPayload?.role,
      isAdmin: normalizedUser?.isAdmin ?? authPayload?.isAdmin,
    });

    setAuthToken(nextAccessToken);
    setRefreshToken(nextRefreshToken);
    setIsLogin(true);

    if (normalizedUser) {
      setUserData((currentUser) => ({
        ...(currentUser || {}),
        ...normalizedUser,
      }));
    }

    return normalizedUser;
  };


  const getUserDetails = async ({ silent = false } = {}) => {
    const res = await fetchDataFromApi(`/api/user/user-details`);

    if (res?.error === false && res?.data) {
      const normalizedUser = normalizeAuthenticatedUser(res.data);
      setUserData(normalizedUser);

      setUserSession({
        accessToken: authToken,
        refreshToken,
        role: normalizedUser?.role,
        isAdmin: normalizedUser?.isAdmin,
      });

      return normalizedUser;
    }

    if (res?.message === "You have not login") {
      clearAuthState();

      if (!silent && hasBootstrappedRef.current) {
        alertBox("error", "Your session is closed please login again");
      }
    }

    return null;
  };


  useEffect(() => {
    let isMounted = true;

    localStorage.removeItem("userEmail");

    const syncAuthSession = async () => {
      if (!authToken) {
        if (!isMounted) return;

        resetAuthState();
        setIsAuthReady(true);
        hasBootstrappedRef.current = true;
        return;
      }

      setIsLogin(true);

      const normalizedUser = await getUserDetails({ silent: true });

      if (!isMounted) return;

      if (normalizedUser) {
        getCartItems();
        getMyListData();
      }

      setIsAuthReady(true);
      hasBootstrappedRef.current = true;
    };

    syncAuthSession();

    return () => {
      isMounted = false;
    };
  }, [authToken, refreshToken]);



  useEffect(() => {
    fetchDataFromApi("/api/category").then((res) => {
      if (res?.error === false) {
        setCatData(res?.data);
      }
    })

    const handleResize = () => {
      setWindowWidth(window.innerWidth);
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };

  }, []);

  const alertBox = (type, msg) => {
    if (type === "success") {
      toast.success(msg)
    }
    if (type === "error") {
      toast.error(msg)
    }
  }



  const addToCart = (product, userId, quantity) => {

    if (userId === undefined) {
      alertBox("error", "you are not login please login first");
      return false;
    }

    const data = {
      productTitle: product?.name,
      image: product?.image,
      rating: product?.rating,
      price: product?.price,
      oldPrice: product?.oldPrice,
      discount: product?.discount,
      quantity: quantity,
      subTotal: parseInt(product?.price * quantity),
      productId: product?._id,
      countInStock: product?.countInStock,
      brand: product?.brand,
      size: product?.size,
      weight: product?.weight,
      ram: product?.ram,
      serviceType: product?.serviceType
    }


    postData("/api/cart/add", data).then((res) => {
      if (res?.error === false) {
        alertBox("success", res?.message);

        getCartItems();


      } else {
        alertBox("error", res?.message);
      }

    })


  }



  const getCartItems = () => {
    fetchDataFromApi(`/api/cart/get`).then((res) => {
      if (res?.error === false) {
        setCartData(res?.data);
      }
    })
  }



  const getMyListData = () => {
    fetchDataFromApi("/api/myList").then((res) => {
      if (res?.error === false) {
        setMyListData(res?.data)
      }
    })
  }

  const values = {
    openProductDetailsModal,
    setOpenProductDetailsModal,
    handleOpenProductDetailsModal,
    handleCloseProductDetailsModal,
    setOpenCartPanel,
    toggleCartPanel,
    openCartPanel,
    setOpenAddressPanel,
    toggleAddressPanel,
    openAddressPanel,
    authToken,
    refreshToken,
    isAuthReady,
    isLogin,
    setIsLogin,
    setAuthSession,
    clearAuthState,
    alertBox,
    setUserData,
    userData,
    setCatData,
    catData,
    addToCart,
    cartData,
    setCartData,
    getCartItems,
    myListData,
    setMyListData,
    getMyListData,
    getUserDetails,
    setAddressMode,
    addressMode,
    addressId,
    setAddressId,
    setSearchData,
    searchData,
    windowWidth,
    setOpenFilter,
    openFilter,
    setisFilterBtnShow,
    isFilterBtnShow,
    setOpenSearchPanel,
    openSearchPanel
  };

  return (
    <>
      <BrowserRouter>
        <MyContext.Provider value={values}>
          <AppShell />
        </MyContext.Provider>
      </BrowserRouter>





      <Toaster />


    </>
  );
}

export default App;

export { MyContext };
