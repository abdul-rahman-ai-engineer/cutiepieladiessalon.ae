import React, { useContext, useEffect, useState } from "react";
import { Button, CircularProgress, TextField } from "@mui/material";
import {
  MdArrowBack,
  MdEditLocationAlt,
  MdLocationOn,
  MdMyLocation,
  MdSearch,
} from "react-icons/md";
import LocationPickerMap from "../../components/LocationPickerMap";
import { MyContext } from "../../App";
import { editData, fetchDataFromApi, postData } from "../../utils/api";

const DUBAI_CITY = "Dubai";
const DUBAI_STATE = "Dubai";
const UAE_COUNTRY = "United Arab Emirates";
const UNSUPPORTED_LOCATION_MESSAGE = "We currently operate only in Dubai.";
const DUBAI_MAP_CENTER = { lat: 25.2048, lng: 55.2708 };
const DUBAI_MAP_BOUNDS = [
  [24.85, 54.95],
  [25.45, 55.65],
];

const DUBAI_QUICK_LOCATIONS = [
  { title: "Dubai Marina", area: "Dubai Marina", lat: 25.0806, lng: 55.1404 },
  { title: "Downtown Dubai", area: "Downtown Dubai", lat: 25.1972, lng: 55.2744 },
  { title: "Business Bay", area: "Business Bay", lat: 25.1861, lng: 55.2637 },
  { title: "Jumeirah", area: "Jumeirah", lat: 25.2048, lng: 55.2423 },
  { title: "Al Barsha", area: "Al Barsha", lat: 25.1124, lng: 55.2011 },
  { title: "Dubai Silicon Oasis", area: "Dubai Silicon Oasis", lat: 25.1258, lng: 55.3867 },
  { title: "Jumeirah Lake Towers", area: "JLT", lat: 25.0736, lng: 55.1416 },
  { title: "Deira", area: "Deira", lat: 25.2847, lng: 55.3301 },
];

const compact = (values = []) =>
  values
    .map((value) => String(value ?? "").trim())
    .filter(Boolean);

const uniqueCompact = (values = []) => Array.from(new Set(compact(values)));

const sanitizePhoneForPayload = (value) => String(value ?? "").replace(/[^\d]/g, "").trim();

const normalizeSavedAddressType = (value = "") => {
  const normalized = String(value || "").trim().toLowerCase();

  if (normalized === "work" || normalized === "office") {
    return "Work";
  }

  if (normalized === "other") {
    return "Other";
  }

  return "Home";
};

const createEmptyForm = (userId = "", mobile = "") => ({
  address_line1: "",
  city: DUBAI_CITY,
  state: DUBAI_STATE,
  pincode: "",
  country: UAE_COUNTRY,
  mobile,
  userId,
  addressType: "Home",
  landmark: "",
});

const isDubaiLocation = (value = {}) => {
  const haystack = [
    value?.display_name,
    value?.name,
    ...Object.values(value?.address || {}),
  ]
    .join(" ")
    .toLowerCase();

  const blockedKeywords = [
    "sharjah",
    "abu dhabi",
    "ajman",
    "ras al khaimah",
    "umm al quwain",
    "fujairah",
    "al ain",
  ];

  return haystack.includes("dubai") && !blockedKeywords.some((keyword) => haystack.includes(keyword));
};

const buildQuickLocation = (location) => ({
  title: location.title,
  area: location.area,
  displayName: `${location.title}, Dubai, United Arab Emirates`,
  lat: location.lat,
  lng: location.lng,
  postcode: "",
});

const normalizeLocationResult = (item = {}) => {
  const address = item?.address || {};
  const streetLine = compact([address?.house_number, address?.road]).join(" ");
  const area = uniqueCompact([
    address?.suburb,
    address?.neighbourhood,
    address?.city_district,
    address?.residential,
    address?.quarter,
    address?.city,
    DUBAI_CITY,
  ])[0];
  const title =
    uniqueCompact([
      streetLine,
      address?.amenity,
      address?.building,
      address?.shop,
      address?.tourism,
      area,
    ])
      .slice(0, 2)
      .join(", ") ||
    compact(String(item?.display_name || "").split(",")).slice(0, 2).join(", ") ||
    DUBAI_CITY;

  return {
    title,
    area: area || DUBAI_CITY,
    displayName: item?.display_name || `${title}, Dubai, United Arab Emirates`,
    lat: Number(item?.lat) || DUBAI_MAP_CENTER.lat,
    lng: Number(item?.lon) || DUBAI_MAP_CENTER.lng,
    postcode: String(address?.postcode || "").trim(),
  };
};

const mergeLocations = (...lists) => {
  const seen = new Set();
  const output = [];

  lists.flat().forEach((location) => {
    const key = `${String(location?.title || "").toLowerCase()}-${String(
      location?.displayName || ""
    ).toLowerCase()}`;

    if (!location?.title || seen.has(key)) {
      return;
    }

    seen.add(key);
    output.push(location);
  });

  return output;
};

const getQuickLocationMatches = (query = "") => {
  const normalizedQuery = String(query || "").trim().toLowerCase();

  return DUBAI_QUICK_LOCATIONS.filter((location) => {
    if (!normalizedQuery) return true;
    return `${location.title} ${location.area}`.toLowerCase().includes(normalizedQuery);
  }).map(buildQuickLocation);
};

const fetchDubaiSearchResults = async (query, signal) => {
  const response = await fetch(
    `https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=1&limit=6&countrycodes=ae&q=${encodeURIComponent(
      `${query}, Dubai, UAE`
    )}`,
    {
      signal,
      headers: {
        Accept: "application/json",
      },
    }
  );

  if (!response.ok) {
    throw new Error("Unable to load location suggestions right now.");
  }

  const data = await response.json();
  return Array.isArray(data)
    ? data.filter(isDubaiLocation).map(normalizeLocationResult)
    : [];
};

const reverseDubaiLocation = async (lat, lng) => {
  const response = await fetch(
    `https://nominatim.openstreetmap.org/reverse?format=jsonv2&addressdetails=1&lat=${encodeURIComponent(
      lat
    )}&lon=${encodeURIComponent(lng)}`,
    {
      headers: {
        Accept: "application/json",
      },
    }
  );

  if (!response.ok) {
    throw new Error("We couldn't read that pin location.");
  }

  const data = await response.json();

  if (!isDubaiLocation(data)) {
    throw new Error(UNSUPPORTED_LOCATION_MESSAGE);
  }

  return normalizeLocationResult(data);
};

const AddAddress = () => {
  const context = useContext(MyContext);
  const [step, setStep] = useState("search");
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState(() => getQuickLocationMatches());
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [pinPosition, setPinPosition] = useState(DUBAI_MAP_CENTER);
  const [formFields, setFormFields] = useState(() =>
    createEmptyForm(
      context?.userData?._id || "",
      sanitizePhoneForPayload(context?.userData?.mobile)
    )
  );
  const [isLoading, setIsLoading] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [isUsingCurrentLocation, setIsUsingCurrentLocation] = useState(false);
  const [isResolvingPin, setIsResolvingPin] = useState(false);
  const [isPrefilling, setIsPrefilling] = useState(false);
  const [searchError, setSearchError] = useState("");
  const [isAddressLineDirty, setIsAddressLineDirty] = useState(false);

  const resetComposer = () => {
    setStep("search");
    setSearchQuery("");
    setSearchResults(getQuickLocationMatches());
    setSelectedLocation(null);
    setPinPosition(DUBAI_MAP_CENTER);
    setSearchError("");
    setIsAddressLineDirty(false);
    setFormFields(
      createEmptyForm(
        context?.userData?._id || "",
        sanitizePhoneForPayload(context?.userData?.mobile)
      )
    );
  };

  const applyResolvedLocation = (location, options = {}) => {
    const preserveAddressLine = Boolean(options.preserveAddressLine && isAddressLineDirty);

    setSelectedLocation(location);
    setPinPosition({
      lat: location?.lat || DUBAI_MAP_CENTER.lat,
      lng: location?.lng || DUBAI_MAP_CENTER.lng,
    });
    setStep("details");
    setSearchError("");
    setFormFields((current) => ({
      ...current,
      address_line1: preserveAddressLine
        ? current.address_line1
        : location?.title || current.address_line1,
      city: DUBAI_CITY,
      state: DUBAI_STATE,
      country: UAE_COUNTRY,
      pincode: location?.postcode || current.pincode || "",
      mobile: current.mobile || sanitizePhoneForPayload(context?.userData?.mobile),
    }));

    if (!preserveAddressLine) {
      setIsAddressLineDirty(false);
    }
  };

  const hydrateExistingAddress = async (address) => {
    const fallbackLocation = {
      title: address?.address_line1 || DUBAI_CITY,
      area: address?.city || DUBAI_CITY,
      displayName: compact([
        address?.address_line1,
        address?.city || DUBAI_CITY,
        address?.state || DUBAI_STATE,
        address?.country || UAE_COUNTRY,
      ]).join(", "),
      lat: Number(address?.lat) || DUBAI_MAP_CENTER.lat,
      lng: Number(address?.lng) || DUBAI_MAP_CENTER.lng,
      postcode: address?.pincode || "",
    };

    setStep("details");
    setSelectedLocation(fallbackLocation);
    setPinPosition({
      lat: fallbackLocation.lat,
      lng: fallbackLocation.lng,
    });
    setIsAddressLineDirty(Boolean(address?.address_line1));
    setFormFields({
      address_line1: address?.address_line1 || "",
      city: DUBAI_CITY,
      state: DUBAI_STATE,
      pincode: address?.pincode || "",
      country: UAE_COUNTRY,
      mobile:
        sanitizePhoneForPayload(address?.mobile) ||
        sanitizePhoneForPayload(context?.userData?.mobile),
      userId: context?.userData?._id || address?.userId || "",
      addressType: normalizeSavedAddressType(address?.addressType),
      landmark: address?.landmark || "",
    });

    if (address?.lat && address?.lng) {
      return;
    }

    try {
      const remoteMatches = await fetchDubaiSearchResults(fallbackLocation.displayName);
      if (remoteMatches.length) {
        setSelectedLocation(remoteMatches[0]);
        setPinPosition({
          lat: remoteMatches[0].lat,
          lng: remoteMatches[0].lng,
        });
      }
    } catch {
      // Keep the stored address if geocoding is unavailable.
    }
  };

  useEffect(() => {
    setFormFields((current) => ({
      ...current,
      userId: context?.userData?._id || current.userId,
      mobile: current.mobile || sanitizePhoneForPayload(context?.userData?.mobile),
    }));
  }, [context?.userData?._id, context?.userData?.mobile]);

  useEffect(() => {
    if (!context?.openAddressPanel) {
      return;
    }

    if (context?.addressMode === "edit" && context?.addressId) {
      setIsPrefilling(true);
      fetchDataFromApi(`/api/address/${context.addressId}`)
        .then((res) => {
          if (res?.error || !res?.address) {
            context?.alertBox("error", res?.message || "Unable to load the saved location.");
            return;
          }

          return hydrateExistingAddress(res.address);
        })
        .finally(() => {
          setIsPrefilling(false);
        });

      return;
    }

    resetComposer();
  }, [context?.openAddressPanel, context?.addressId, context?.addressMode]);

  useEffect(() => {
    if (step !== "search") {
      return undefined;
    }

    const normalizedQuery = String(searchQuery || "").trim();
    const quickMatches = getQuickLocationMatches(normalizedQuery);

    if (normalizedQuery.length < 2) {
      setSearchResults(quickMatches);
      setSearchError("");
      setIsSearching(false);
      return undefined;
    }

    const controller = new AbortController();
    const timeoutId = window.setTimeout(async () => {
      setIsSearching(true);
      setSearchError("");

      try {
        const remoteMatches = await fetchDubaiSearchResults(normalizedQuery, controller.signal);
        const mergedResults = mergeLocations(quickMatches, remoteMatches);

        setSearchResults(mergedResults);

        if (!mergedResults.length) {
          setSearchError("No Dubai location matched that search. Try a nearby area or landmark.");
        }
      } catch (error) {
        if (error?.name === "AbortError") {
          return;
        }

        setSearchResults(quickMatches);
        if (!quickMatches.length) {
          setSearchError("We couldn't load live map suggestions right now. Try one of the Dubai areas below.");
        }
      } finally {
        setIsSearching(false);
      }
    }, 350);

    return () => {
      controller.abort();
      window.clearTimeout(timeoutId);
    };
  }, [searchQuery, step]);

  const handlePinPositionChange = (nextPosition) => {
    setPinPosition(nextPosition);
    setSelectedLocation(null);
    setSearchError("");
  };

  const handleConfirmPinLocation = async () => {
    if (!pinPosition?.lat || !pinPosition?.lng) {
      setSearchError("Move the pin to the exact Dubai location first.");
      return;
    }

    try {
      setIsResolvingPin(true);
      setSearchError("");
      const location = await reverseDubaiLocation(pinPosition.lat, pinPosition.lng);
      applyResolvedLocation(location, { preserveAddressLine: true });
    } catch (error) {
      setSearchError(error?.message || "We couldn't confirm that pin location.");
    } finally {
      setIsResolvingPin(false);
    }
  };

  const handleUseCurrentLocation = () => {
    if (!navigator.geolocation) {
      setSearchError("Your browser does not support live location. Search for a Dubai area instead.");
      return;
    }

    setIsUsingCurrentLocation(true);
    setSearchError("");

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        try {
          const location = await reverseDubaiLocation(
            position.coords.latitude,
            position.coords.longitude
          );

          setPinPosition({
            lat: location.lat,
            lng: location.lng,
          });
          setSelectedLocation(location);
          setSearchQuery(location.title);
        } catch (error) {
          setSearchError(error?.message || "We couldn't read your current location.");
        } finally {
          setIsUsingCurrentLocation(false);
        }
      },
      () => {
        setIsUsingCurrentLocation(false);
        setSearchError("We couldn't read your current location. Search for a Dubai area instead.");
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000,
      }
    );
  };

  const handleQuickSelection = (location) => {
    setPinPosition({
      lat: location.lat,
      lng: location.lng,
    });
    setSelectedLocation(location);
    setSearchError("");
    setSearchQuery(location.title);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    if (!selectedLocation || !pinPosition?.lat || !pinPosition?.lng) {
      context?.alertBox("error", "Please confirm a Dubai pin location first.");
      setStep("search");
      return;
    }

    if (!formFields.address_line1.trim()) {
      context?.alertBox("error", "Please confirm the building or address name.");
      return;
    }

    if (!formFields.addressType) {
      context?.alertBox("error", "Please select a location type.");
      return;
    }

    const payload = {
      ...formFields,
      address_line1: formFields.address_line1.trim(),
      city: DUBAI_CITY,
      state: DUBAI_STATE,
      country: UAE_COUNTRY,
      pincode: String(formFields.pincode || selectedLocation?.postcode || "").trim(),
      mobile: sanitizePhoneForPayload(context?.userData?.mobile || formFields.mobile),
      userId: context?.userData?._id || formFields.userId,
      addressType: formFields.addressType,
      landmark: formFields.landmark.trim(),
      lat: Number(pinPosition.lat),
      lng: Number(pinPosition.lng),
    };

    try {
      setIsLoading(true);

      if (context?.addressMode === "edit") {
        const response = await editData(`/api/address/${context?.addressId}`, payload, {
          withCredentials: true,
        });
        context?.alertBox(
          "success",
          response?.data?.message || "Location updated successfully."
        );
      } else {
        const response = await postData(`/api/address/add`, payload, {
          withCredentials: true,
        });

        if (response?.error) {
          throw new Error(response?.message || "Unable to save the location.");
        }

        context?.alertBox(
          "success",
          response?.message || "Location saved successfully."
        );
      }

      await context?.getUserDetails?.();
      context?.setOpenAddressPanel(false);
      resetComposer();
    } catch (error) {
      context?.alertBox(
        "error",
        error?.response?.data?.message || error?.message || "Unable to save the location."
      );
    } finally {
      setIsLoading(false);
    }
  };

  if (isPrefilling) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <CircularProgress />
      </div>
    );
  }

  return (
    <div className="px-4 py-4 sm:px-5">
      {step === "search" ? (
        <div className="space-y-4">
          <div className="overflow-hidden rounded-[28px] border border-[#dfeaf5] bg-white shadow-[0_20px_50px_rgba(15,23,42,0.08)]">
            <div className="relative">
              <LocationPickerMap
                position={pinPosition}
                center={pinPosition}
                zoom={13}
                interactive
                height={430}
                maxBounds={DUBAI_MAP_BOUNDS}
                onPositionChange={handlePinPositionChange}
              />

              <div className="pointer-events-none absolute inset-x-4 top-4 z-[600]">
                <div className="pointer-events-auto rounded-[18px] border border-[#d7e6f7] bg-white p-3 shadow-[0_18px_36px_rgba(15,23,42,0.12)]">
                  <div className="flex items-center gap-3">
                    <MdSearch className="shrink-0 text-[22px] text-[#0f7adf]" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(event) => setSearchQuery(event.target.value)}
                      placeholder="Search for area, street name, landmark..."
                      className="h-full min-w-0 flex-1 border-none bg-transparent text-[15px] text-[#111827] outline-none placeholder:text-[#94a3b8]"
                    />
                    <button
                      type="button"
                      onClick={handleUseCurrentLocation}
                      disabled={isUsingCurrentLocation}
                      className="inline-flex shrink-0 items-center gap-2 rounded-full bg-[#edf7ff] px-3 py-2 text-[12px] font-[800] text-[#0f7adf] transition hover:bg-[#dff1ff] disabled:cursor-not-allowed disabled:opacity-60"
                    >
                      {isUsingCurrentLocation ? (
                        <CircularProgress color="inherit" size={16} />
                      ) : (
                        <MdMyLocation className="text-[16px]" />
                      )}
                      Set my location
                    </button>
                  </div>

                  <p className="mb-0 mt-3 text-[12px] font-[800] uppercase tracking-[0.16em] text-[#64748b]">
                    Dubai locations only
                  </p>
                </div>
              </div>

              <div className="pointer-events-none absolute inset-x-4 bottom-4 z-[600]">
                <div className="pointer-events-auto rounded-[20px] bg-[rgba(15,23,42,0.84)] p-4 text-white shadow-[0_18px_40px_rgba(15,23,42,0.2)]">
                  <p className="m-0 text-[14px] font-[700]">
                    Drag the pin or tap the map to set the exact Dubai location.
                  </p>
                  <p className="m-0 mt-1 text-[12px] text-[rgba(255,255,255,0.78)]">
                    {selectedLocation?.displayName || "Confirm the pin once it is in the right place."}
                  </p>

                  <Button
                    type="button"
                    onClick={handleConfirmPinLocation}
                    className="!mt-4 !w-full !rounded-full !bg-[#ffcf3a] !py-3 !text-[14px] !font-[800] !text-[#111827] hover:!bg-[#ffd95f]"
                  >
                    {isResolvingPin ? <CircularProgress color="inherit" size={20} /> : "Confirm Pin Location"}
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {searchError ? (
            <div className="rounded-[18px] border border-[#fecaca] bg-[#fff1f2] px-4 py-3 text-[13px] font-[600] text-[#b91c1c]">
              {searchError}
            </div>
          ) : null}

          <div className="rounded-[24px] border border-[#e5edf5] bg-white p-4">
            <div className="mb-3 flex items-center justify-between gap-3">
              <div>
                <p className="m-0 text-[16px] font-[800] text-[#111827]">
                  {searchQuery.trim() ? "Matching Dubai locations" : "Popular Dubai areas"}
                </p>
                <p className="m-0 mt-1 text-[13px] text-[#64748b]">
                  Search or tap one of these Dubai areas to move the pin faster.
                </p>
              </div>
              {isSearching ? <CircularProgress size={22} /> : null}
            </div>

            <div className="space-y-3">
              {searchResults.map((location) => {
                const isActive =
                  Math.abs((pinPosition?.lat || 0) - location.lat) < 0.0005 &&
                  Math.abs((pinPosition?.lng || 0) - location.lng) < 0.0005;

                return (
                  <button
                    key={`${location.title}-${location.displayName}`}
                    type="button"
                    onClick={() => handleQuickSelection(location)}
                    className={`flex w-full items-start gap-3 rounded-[18px] border px-4 py-4 text-left transition ${
                      isActive
                        ? "border-[#0f7adf] bg-[#f4fbff]"
                        : "border-[#e7edf4] hover:border-[#0f7adf] hover:bg-[#f8fbff]"
                    }`}
                  >
                    <span className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#edf7ff] text-[#0f7adf]">
                      <MdLocationOn className="text-[20px]" />
                    </span>
                    <span className="min-w-0">
                      <span className="block text-[15px] font-[800] text-[#111827]">
                        {location.title}
                      </span>
                      <span className="mt-1 block text-[13px] leading-6 text-[#64748b]">
                        {location.displayName}
                      </span>
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      ) : (
        <form className="space-y-4" onSubmit={handleSubmit}>
          <div className="flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={() => setStep("search")}
              className="inline-flex items-center gap-2 rounded-full px-1 py-1 text-[13px] font-[800] text-[#0f7adf] transition hover:text-[#0b65bb]"
            >
              <MdArrowBack className="text-[18px]" />
              Back to pin selection
            </button>

            <button
              type="button"
              onClick={() => setStep("search")}
              className="inline-flex items-center gap-2 rounded-full border border-[#dbe5ef] px-4 py-2 text-[13px] font-[800] text-[#0f7adf] transition hover:border-[#0f7adf] hover:bg-[#f4fbff]"
            >
              <MdEditLocationAlt className="text-[18px]" />
              Edit pin location
            </button>
          </div>

          <div className="overflow-hidden rounded-[24px] border border-[#e5edf5] bg-white">
            <LocationPickerMap
              position={pinPosition}
              center={pinPosition}
              zoom={14}
              interactive={false}
              height={240}
              maxBounds={DUBAI_MAP_BOUNDS}
            />
          </div>

          <div className="rounded-[24px] border border-[#e5edf5] bg-white p-4">
            <p className="m-0 text-[12px] font-[800] uppercase tracking-[0.16em] text-[#94a3b8]">
              Selected area
            </p>
            <p className="m-0 mt-2 text-[18px] font-[800] text-[#111827]">
              {selectedLocation?.area || DUBAI_CITY}
            </p>
            <p className="m-0 mt-2 text-[14px] leading-6 text-[#64748b]">
              {selectedLocation?.displayName || "Dubai, United Arab Emirates"}
            </p>
          </div>

          <div className="rounded-[24px] border border-[#e5edf5] bg-white p-4">
            <p className="m-0 text-[12px] font-[800] uppercase tracking-[0.16em] text-[#94a3b8]">
              Location type
            </p>
            <div className="mt-3 flex flex-wrap gap-3">
              {["Home", "Work", "Other"].map((type) => {
                const isActive = formFields.addressType === type;

                return (
                  <button
                    key={type}
                    type="button"
                    onClick={() =>
                      setFormFields((current) => ({
                        ...current,
                        addressType: type,
                      }))
                    }
                    className={`rounded-full border px-5 py-2.5 text-[14px] font-[800] transition ${
                      isActive
                        ? "border-[#0f7adf] bg-[#0f7adf] text-white"
                        : "border-[#dbe4ee] bg-white text-[#475569] hover:border-[#0f7adf] hover:text-[#0f7adf]"
                    }`}
                  >
                    {type}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="space-y-4 rounded-[24px] border border-[#e5edf5] bg-white p-4">
            <TextField
              className="w-full"
              label="Address / Building Name"
              variant="outlined"
              size="small"
              value={formFields.address_line1}
              onChange={(event) => {
                setIsAddressLineDirty(true);
                setFormFields((current) => ({
                  ...current,
                  address_line1: event.target.value,
                }));
              }}
            />

            <TextField
              className="w-full"
              label="Directions (optional)"
              variant="outlined"
              size="small"
              multiline
              minRows={3}
              value={formFields.landmark}
              onChange={(event) =>
                setFormFields((current) => ({
                  ...current,
                  landmark: event.target.value,
                }))
              }
            />
          </div>

          <Button type="submit" className="btn-org btn-lg !w-full !rounded-full">
            {isLoading ? <CircularProgress color="inherit" /> : "Save Location"}
          </Button>
        </form>
      )}
    </div>
  );
};

export default AddAddress;
