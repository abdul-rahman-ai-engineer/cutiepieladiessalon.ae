import React, { useEffect, useMemo, useState } from "react";
import AccountSidebar from "../../components/AccountSidebar";
import Badge from "../../components/Badge";
import { fetchDataFromApi } from "../../utils/api";
import { formatPrice } from "../../utils/formatPrice";

const getAddressLabel = (address = {}) =>
  [
    address?.addressLine1 || address?.address_line1,
    address?.landmark,
    address?.city,
    address?.state,
    address?.country,
  ]
    .filter(Boolean)
    .join(", ");

const getPaymentMethodLabel = (booking) => {
  if (booking?.paymentMethod === "cash") return "Cash on visit";
  if (booking?.paymentMethod === "tamara") return "Tamara";
  return "Card";
};

const getPaymentStatusLabel = (booking) => {
  const rawStatus = booking?.paymentStatus || booking?.orderId?.payment_status || "pending";
  return String(rawStatus).replace(/_/g, " ");
};

const getScheduleLabel = (booking) => {
  if (booking?.instantRequested) {
    return "Instant booking";
  }

  return (
    booking?.schedule?.slotLabel ||
    booking?.slotLabel ||
    [booking?.schedule?.startTime || booking?.startTime, booking?.schedule?.endTime || booking?.endTime]
      .filter(Boolean)
      .join(" - ") ||
    "Time will be confirmed soon"
  );
};

const Bookings = () => {
  const [bookings, setBookings] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    window.scrollTo(0, 0);

    let isMounted = true;

    fetchDataFromApi("/api/bookings/mine").then((response) => {
      if (!isMounted) {
        return;
      }

      if (response?.error === false) {
        setBookings(Array.isArray(response?.data) ? response.data : []);
      } else {
        setBookings([]);
      }

      setIsLoading(false);
    });

    return () => {
      isMounted = false;
    };
  }, []);

  const bookingCards = useMemo(
    () =>
      bookings.map((booking) => ({
        id: booking?.bookingId || booking?._id,
        bookingReference: booking?.bookingReference || booking?.bookingId || booking?._id,
        serviceName: booking?.serviceName || booking?.serviceSnapshot?.name || booking?.serviceId?.name || "Salon service",
        serviceCategory: booking?.serviceSnapshot?.categoryName || "Salon at home",
        serviceImage:
          booking?.serviceSnapshot?.image ||
          booking?.serviceId?.images?.[0] ||
          "/homeBannerPlaceholder.jpg",
        scheduleDate: booking?.schedule?.date || booking?.bookingDate || booking?.schedule?.dayLabel || booking?.bookingDayLabel || "Date pending",
        scheduleTime: getScheduleLabel(booking),
        professionalName:
          booking?.assignedProfessional?.name ||
          booking?.professionalSnapshot?.name ||
          booking?.professionalId?.name ||
          "Auto assign",
        professionalPreference: booking?.professionalPreference || "auto",
        paymentMethodLabel: getPaymentMethodLabel(booking),
        paymentStatusLabel: getPaymentStatusLabel(booking),
        paymentReference:
          booking?.paymentReferenceId || booking?.orderId?.paymentReferenceId || booking?.paymentId || "Pending",
        receiptId: booking?.orderId?._id || "",
        total: booking?.summary?.total ?? booking?.orderId?.totalAmt ?? 0,
        status: booking?.status || "draft",
        addressLabel: getAddressLabel(booking?.customerInfo?.address || booking?.addressSnapshot || {}),
        addOnCount: Array.isArray(booking?.addOns) ? booking.addOns.length : 0,
      })),
    [bookings]
  );

  return (
    <section className="w-full py-5 lg:py-10">
      <div className="container flex flex-col gap-5 lg:flex-row">
        <div className="hidden w-[20%] lg:block">
          <AccountSidebar />
        </div>

        <div className="w-full lg:w-[80%]">
          <div className="rounded-[28px] bg-white p-5 shadow-md lg:p-6">
            <div className="border-b border-[rgba(0,0,0,0.08)] pb-4">
              <h2 className="text-[24px] font-[700] text-[#111827]">My Bookings</h2>
              <p className="mt-1 text-[14px] text-[rgba(0,0,0,0.62)]">
                Track upcoming appointments, payment references, and completed salon visits.
              </p>
            </div>

            <div className="pt-5">
              {isLoading ? (
                <div className="rounded-[22px] border border-dashed border-[rgba(0,0,0,0.12)] px-5 py-12 text-center text-[14px] text-[rgba(0,0,0,0.58)]">
                  Loading your bookings...
                </div>
              ) : bookingCards.length ? (
                <div className="grid gap-5 xl:grid-cols-2">
                  {bookingCards.map((booking) => (
                    <article
                      key={booking.id}
                      className="rounded-[26px] border border-[rgba(0,0,0,0.08)] bg-white p-4 shadow-[0_14px_34px_rgba(15,23,42,0.05)]"
                    >
                      <div className="flex flex-col gap-4 sm:flex-row">
                        <img
                          src={booking.serviceImage}
                          alt={booking.serviceName}
                          className="h-28 w-full rounded-[20px] object-cover sm:w-28"
                        />

                        <div className="min-w-0 flex-1">
                          <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                            <div>
                              <p className="text-[11px] font-[800] uppercase tracking-[0.18em] text-primary">
                                {booking.serviceCategory}
                              </p>
                              <h3 className="mt-1 text-[20px] font-[700] leading-7 text-[#111827]">
                                {booking.serviceName}
                              </h3>
                              <p className="mt-1 text-[12px] text-[rgba(0,0,0,0.56)]">
                                Booking ID: <span className="font-[700] text-[#111827]">{booking.bookingReference}</span>
                              </p>
                            </div>

                            <div className="text-left sm:text-right">
                              <p className="text-[12px] text-[rgba(0,0,0,0.5)]">Total</p>
                              <p className="text-[20px] font-[700] text-primary">
                                {formatPrice(booking.total)}
                              </p>
                            </div>
                          </div>

                          <div className="mt-3 flex flex-wrap gap-2">
                            <Badge status={booking.status} />
                            <span className="inline-flex items-center rounded-full bg-[#f5f5f5] px-3 py-1 text-[12px] font-[600] text-[rgba(0,0,0,0.72)]">
                              {booking.paymentMethodLabel}
                            </span>
                            {booking.addOnCount > 0 ? (
                              <span className="inline-flex items-center rounded-full bg-[#fff4ec] px-3 py-1 text-[12px] font-[600] text-[#f97316]">
                                {booking.addOnCount} add-on{booking.addOnCount > 1 ? "s" : ""}
                              </span>
                            ) : null}
                          </div>

                          <div className="mt-4 grid gap-3 text-[13px] text-[rgba(0,0,0,0.72)] sm:grid-cols-2">
                            <div>
                              <p className="font-[700] text-[#111827]">Schedule</p>
                              <p className="mt-1">{booking.scheduleDate}</p>
                              <p>{booking.scheduleTime}</p>
                            </div>

                            <div>
                              <p className="font-[700] text-[#111827]">Professional</p>
                              <p className="mt-1">{booking.professionalName}</p>
                              <p className="capitalize">{booking.professionalPreference}</p>
                            </div>

                            <div>
                              <p className="font-[700] text-[#111827]">Payment Reference</p>
                              <p className="mt-1 break-all">{booking.paymentReference}</p>
                              <p className="capitalize">{booking.paymentStatusLabel}</p>
                            </div>

                            <div>
                              <p className="font-[700] text-[#111827]">Receipt</p>
                              <p className="mt-1 break-all">
                                {booking.receiptId || "Receipt will appear once payment is finalized"}
                              </p>
                            </div>

                            <div className="sm:col-span-2">
                              <p className="font-[700] text-[#111827]">Address</p>
                              <p className="mt-1">
                                {booking.addressLabel || "Your selected service address will be shown here."}
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </article>
                  ))}
                </div>
              ) : (
                <div className="rounded-[22px] border border-dashed border-[rgba(0,0,0,0.12)] px-5 py-12 text-center text-[14px] text-[rgba(0,0,0,0.58)]">
                  No bookings yet. Your confirmed appointments will appear here.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Bookings;
