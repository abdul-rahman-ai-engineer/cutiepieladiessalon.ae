import React, { useContext, useEffect, useMemo, useState } from "react";
import CircularProgress from "@mui/material/CircularProgress";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import {
  MdAdd,
  MdAccessTime,
  MdCheck,
  MdClose,
  MdRemove,
  MdOutlineAutoAwesome,
  MdOutlineLocationOn,
  MdOutlinePayment,
  MdOutlineStar,
} from "react-icons/md";
import BookingLayout from "../../components/BookingLayout";
import BookingAddressModal from "../../components/BookingAddressModal";
import SummaryCard from "../../components/SummaryCard";
import TamaraPromoWidget from "../../components/TamaraPromoWidget";
import { MyContext } from "../../App";
import { fetchDataFromApi, postData } from "../../utils/api";
import { formatPrice } from "../../utils/formatPrice";
import {
  formatAddressExtras,
  formatAddressMeta,
  getAddressTitle,
  getLatestAddress,
} from "../../utils/address";
import {
  closeTamaraCheckoutWindow,
  getTamaraInstallmentAmount,
  openTamaraCheckoutWindow,
  redirectTamaraCheckoutWindow,
  TAMARA_CHECKOUT_STORAGE_KEY,
} from "../../utils/tamara";

const steps = [
  {
    key: "service",
    label: "Step 1",
    title: "Services",
  },
  {
    key: "addons",
    label: "Step 2",
    title: "Add-ons",
  },
  {
    key: "schedule",
    label: "Step 3",
    title: "Date & time",
  },
  {
    key: "checkout",
    label: "Step 4",
    title: "Checkout",
  },
];

const stepOrder = steps.map((item) => item.key);

const twoLineClampStyle = {
  display: "-webkit-box",
  WebkitBoxOrient: "vertical",
  WebkitLineClamp: 2,
  overflow: "hidden",
};

const buildBookingExperienceState = (response) => {
  const firstDate = response?.availability?.[0];
  const firstSlot = firstDate?.slots?.[0];

  return {
    bookingData: {
      service: response?.service || null,
      addOns: Array.isArray(response?.addOns) ? response.addOns : [],
      professionals: Array.isArray(response?.professionals) ? response.professionals : [],
      relatedServices: Array.isArray(response?.relatedServices) ? response.relatedServices : [],
      availability: Array.isArray(response?.availability) ? response.availability : [],
    },
    selectedDate: firstDate?.value || "",
    selectedSlot: firstSlot?.label || "",
  };
};

const getServicePreviewItems = (service) => {
  if (!service) return [];

  const candidates = [
    ...(Array.isArray(service.includes) ? service.includes : []),
    ...(Array.isArray(service.highlights) ? service.highlights : []),
    ...(Array.isArray(service.benefits) ? service.benefits : []),
  ];

  return Array.from(new Set(candidates.filter(Boolean))).slice(0, 5);
};

const CATEGORY_COPY = {
  nails: {
    subtitle: "Shape, polish, and treat your nails with quick-to-compare home salon options.",
  },
  hairremoval: {
    subtitle: "Compare waxing and removal services with a cleaner, category-first view.",
  },
  facial: {
    subtitle: "Find the facial that matches your skin goals before moving through the next steps.",
  },
  hair: {
    subtitle: "Review trims, styling, and treatment services in one simple vertical list.",
  },
  massage: {
    subtitle: "Browse restorative treatments and choose the one that fits your schedule best.",
  },
  combos: {
    subtitle: "Bundle more into one visit with curated combinations designed for at-home care.",
  },
};

const normalizeCategoryKey = (name) =>
  String(name || "")
    .toLowerCase()
    .replace(/[^a-z]/g, "");

const getCategoryConfig = (name) =>
  CATEGORY_COPY[normalizeCategoryKey(name)] || {
    subtitle: "Browse this category in a cleaner list view and add the service you want next.",
  };

const getServiceCardBadge = (service) => {
  if (service?.badge) return service.badge;
  if (Number(service?.discount) > 0) return `${Math.round(Number(service.discount))}% OFF`;
  return "Bestseller";
};

const getServiceSupportCopy = (service) => {
  const previewItems = getServicePreviewItems(service);

  if (previewItems.length) {
    return previewItems.slice(0, 2).join(" / ");
  }

  return "Professional at-home service with flexible scheduling and clear pricing.";
};

const getDateButtonParts = (date = {}) => {
  const fallbackDayName = String(date?.dayName || "").slice(0, 3);
  const normalizedLabel = String(date?.label || "").trim();
  const [dayNumber = "", monthLabel = ""] = normalizedLabel.split(/\s+/);

  return {
    dayName: fallbackDayName,
    dayNumber,
    monthLabel,
  };
};

const getPreviewFeatureTiles = (service) => {
  const previewItems = getServicePreviewItems(service);
  const fallbackItems = [
    "Perfectly polished finish",
    "Hygienic pro setup",
    "Long-lasting salon glow",
    `${service?.durationMinutes || 60} minute treatment`,
  ];
  const icons = [MdOutlineAutoAwesome, MdOutlineStar, MdCheck, MdAccessTime];

  return [...new Set([...previewItems, ...fallbackItems])].slice(0, 4).map((label, index) => ({
    label,
    Icon: icons[index % icons.length],
  }));
};

const ProductDetails = () => {
  const { id } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const context = useContext(MyContext);

  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCategoryLoading, setIsCategoryLoading] = useState(false);
  const [bookingData, setBookingData] = useState({
    service: null,
    addOns: [],
    professionals: [],
    relatedServices: [],
    availability: [],
  });
  const [categoryServices, setCategoryServices] = useState([]);
  const [activeCategoryId, setActiveCategoryId] = useState("");
  const [currentStep, setCurrentStep] = useState(0);
  const [quantity, setQuantity] = useState(0);
  const [selectedAddOnIds, setSelectedAddOnIds] = useState([]);
  const [selectedProfessional, setSelectedProfessional] = useState("auto");
  const [instantRequested, setInstantRequested] = useState(false);
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedSlot, setSelectedSlot] = useState("");
  const [instructions, setInstructions] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("tamara");
  const [selectedAddress, setSelectedAddress] = useState("");
  const [isAddressModalOpen, setIsAddressModalOpen] = useState(false);
  const [quote, setQuote] = useState(null);
  const [previewService, setPreviewService] = useState(null);
  const [previewQuantity, setPreviewQuantity] = useState(1);
  const [showAdditionalServices, setShowAdditionalServices] = useState(false);
  const [tamaraConfig, setTamaraConfig] = useState({
    enabled: false,
    widgetEnabled: false,
    publicKey: "",
    installments: 4,
    minAmount: 0,
    maxAmount: null,
    countryCode: "AE",
    currency: "AED",
    description: "Split into 4 payments. No late fees. Sharia compliant.",
  });

  const selectedDateOption = useMemo(
    () => bookingData.availability.find((item) => item.value === selectedDate),
    [bookingData.availability, selectedDate]
  );

  const selectedAddOns = useMemo(
    () => bookingData.addOns.filter((item) => selectedAddOnIds.includes(item._id)),
    [bookingData.addOns, selectedAddOnIds]
  );

  const liveSummary = useMemo(() => {
    const safeQuantity = Math.max(0, Number(quantity) || 0);
    const serviceBase = Number(bookingData.service?.price || 0) * safeQuantity;
    const addOnTotal =
      selectedAddOns.reduce((sum, item) => sum + Number(item.price || 0), 0) * safeQuantity;
    const subtotal = serviceBase + addOnTotal;
    const serviceFee = 0;
    const total = Math.max(0, subtotal + serviceFee);

    return {
      serviceBase,
      addOnTotal,
      subtotal,
      serviceFee,
      total,
    };
  }, [bookingData.service, instantRequested, quantity, selectedAddOns]);

  const tamaraCheckoutAmount = useMemo(
    () => Number(quote?.summary?.total || liveSummary.total || 0),
    [liveSummary.total, quote?.summary?.total]
  );

  const tamaraInstallmentAmount = useMemo(
    () => getTamaraInstallmentAmount(tamaraCheckoutAmount, tamaraConfig?.installments || 4),
    [tamaraCheckoutAmount, tamaraConfig?.installments]
  );

  const tamaraEligibility = useMemo(() => {
    const minAmount = Number(tamaraConfig?.minAmount || 0);
    const hasMaxAmount =
      tamaraConfig?.maxAmount !== null &&
      tamaraConfig?.maxAmount !== undefined &&
      tamaraConfig?.maxAmount !== "";
    const maxAmount = hasMaxAmount ? Number(tamaraConfig.maxAmount) : null;

    if (!tamaraConfig?.enabled) {
      return {
        isEligible: false,
        reason: "Tamara checkout is not configured right now.",
      };
    }

    if (tamaraCheckoutAmount <= 0) {
      return {
        isEligible: false,
        reason: "Add a service first to see Tamara availability.",
      };
    }

    if (tamaraCheckoutAmount < minAmount) {
      return {
        isEligible: false,
        reason: `Tamara is available from ${formatPrice(minAmount)}.`,
      };
    }

    if (hasMaxAmount && tamaraCheckoutAmount > maxAmount) {
      return {
        isEligible: false,
        reason: `Tamara is available up to ${formatPrice(maxAmount)}.`,
      };
    }

    return {
      isEligible: true,
      reason: "",
    };
  }, [tamaraCheckoutAmount, tamaraConfig]);

  const tamaraOptionDescription = useMemo(() => {
    const installments = Number(tamaraConfig?.installments || 4);

    if (tamaraCheckoutAmount > 0) {
      return `Split into ${installments} interest-free payments of ${formatPrice(tamaraInstallmentAmount)}. No late fees. Sharia compliant.`;
    }

    return tamaraConfig?.description || "Split into 4 payments. No late fees. Sharia compliant.";
  }, [tamaraCheckoutAmount, tamaraConfig?.description, tamaraConfig?.installments, tamaraInstallmentAmount]);
  const savedAddresses = Array.isArray(context?.userData?.address_details)
    ? context.userData.address_details.filter(Boolean)
    : [];

  const selectedAddressDetails = useMemo(() => {
    const latestAddress = getLatestAddress(savedAddresses);

    return (
      savedAddresses.find((address) => address._id === selectedAddress) ||
      latestAddress ||
      null
    );
  }, [savedAddresses, selectedAddress]);

  const activeCategory = useMemo(() => {
    if (!context?.catData?.length) return null;

    return (
      context.catData.find((category) => category._id === activeCategoryId) ||
      context.catData.find(
        (category) =>
          category?.name === bookingData.service?.catName ||
          category?.name === bookingData.service?.subCat
      ) ||
      null
    );
  }, [activeCategoryId, bookingData.service?.catName, bookingData.service?.subCat, context?.catData]);

  const displayedServices = useMemo(() => {
    const fallbackServices = categoryServices.length
      ? categoryServices
      : bookingData.relatedServices || [];
    const uniqueServices = new Map();

    [bookingData.service, ...fallbackServices].filter(Boolean).forEach((item) => {
      if (!uniqueServices.has(item._id)) {
        uniqueServices.set(item._id, item);
      }
    });

    return Array.from(uniqueServices.values()).sort((first, second) => {
      if (first._id === bookingData.service?._id) return -1;
      if (second._id === bookingData.service?._id) return 1;
      return 0;
    });
  }, [bookingData.relatedServices, bookingData.service, categoryServices]);
  const hasSelectedService = quantity > 0;
  const isFocusedServiceSelection = currentStep === 0 && hasSelectedService;
  const additionalServices = useMemo(
    () => displayedServices.filter((item) => item._id !== bookingData.service?._id),
    [bookingData.service?._id, displayedServices]
  );
  const recommendedAddOns = useMemo(
    () =>
      [...bookingData.addOns]
        .sort((first, second) => {
          if (Boolean(first?.isFeatured) === Boolean(second?.isFeatured)) return 0;
          return first?.isFeatured ? -1 : 1;
        })
        .slice(0, 3),
    [bookingData.addOns]
  );

  const activeCategoryCopy = getCategoryConfig(
    activeCategory?.name || bookingData.service?.catName || bookingData.service?.subCat
  );

  const bookingSummary = quote?.summary || liveSummary;

  useEffect(() => {
    window.scrollTo(0, 0);
    let isMounted = true;

    const loadBookingData = async () => {
      setIsLoading(true);
      const response = await fetchDataFromApi(`/api/services/${id}/booking`);

      if (!isMounted) return;

      if (response?.error === false) {
        const nextState = buildBookingExperienceState(response);

        setBookingData(nextState.bookingData);
        setSelectedDate(nextState.selectedDate);
        setSelectedSlot(nextState.selectedSlot);
        setSelectedAddOnIds([]);
        setSelectedProfessional("auto");
        setInstantRequested(false);
        setInstructions("");
        setPaymentMethod("tamara");
        setQuote(null);
        setQuantity(
          Number.isFinite(Number(location.state?.autoAdd)) && Number(location.state?.autoAdd) > 0
            ? Number(location.state.autoAdd)
            : location.state?.autoAdd
            ? 1
            : 0
        );
        setCurrentStep(0);
        setPreviewService(null);
      } else {
        context?.alertBox("error", response?.message || "Unable to load this service.");
      }

      setIsLoading(false);
    };

    loadBookingData();

    return () => {
      isMounted = false;
    };
  }, [context, id, location.state]);

  useEffect(() => {
    let isMounted = true;

    const loadTamaraConfig = async () => {
      const response = await fetchDataFromApi("/api/bookings/tamara/config");

      if (!isMounted || response?.error !== false) return;

      setTamaraConfig((prev) => ({
        ...prev,
        ...response,
      }));
    };

    loadTamaraConfig();

    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    if (!selectedAddress && savedAddresses.length) {
      const latestAddress = getLatestAddress(savedAddresses);
      setSelectedAddress(latestAddress?._id || "");
    }
  }, [savedAddresses, selectedAddress]);

  useEffect(() => {
    if (!context?.catData?.length || !bookingData.service) return;

    const matchedCategory = context.catData.find(
      (category) =>
        category?.name === bookingData.service?.catName ||
        category?.name === bookingData.service?.subCat
    );

    if (matchedCategory?._id && matchedCategory._id !== activeCategoryId) {
      setActiveCategoryId(matchedCategory._id);
    }
  }, [activeCategoryId, bookingData.service, context?.catData]);

  useEffect(() => {
    if (!activeCategoryId) {
      setCategoryServices([]);
      return undefined;
    }

    let isMounted = true;

    const loadCategoryServices = async () => {
      setIsCategoryLoading(true);
      const response = await fetchDataFromApi(
        `/api/services?categoryId=${activeCategoryId}&limit=24&sort=latest`
      );

      if (!isMounted) return;

      if (response?.error === false) {
        setCategoryServices(Array.isArray(response?.services) ? response.services : []);
      } else {
        setCategoryServices([]);
      }

      setIsCategoryLoading(false);
    };

    loadCategoryServices();

    return () => {
      isMounted = false;
    };
  }, [activeCategoryId]);

  useEffect(() => {
    if (!previewService) return undefined;

    const originalOverflow = document.body.style.overflow;
    const handleKeyDown = (event) => {
      if (event.key === "Escape") {
        setPreviewService(null);
      }
    };

    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", handleKeyDown);

    return () => {
      document.body.style.overflow = originalOverflow;
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [previewService]);

  useEffect(() => {
    if (!previewService) return;

    setPreviewQuantity(1);
  }, [previewService]);

  useEffect(() => {
    if (instantRequested) return;
    const currentDate = bookingData.availability.find((item) => item.value === selectedDate);
    const slotExists = currentDate?.slots?.some((item) => item.label === selectedSlot);

    if (!slotExists) {
      setSelectedSlot(currentDate?.slots?.[0]?.label || "");
    }
  }, [bookingData.availability, instantRequested, selectedDate, selectedSlot]);

  useEffect(() => {
    if (!bookingData.service?._id || quantity < 1) {
      setQuote(null);
      return;
    }

    let isMounted = true;

    const loadQuote = async () => {
      const response = await postData("/api/bookings/quote", {
        serviceId: bookingData.service._id,
        quantity,
        addOnIds: selectedAddOnIds,
        instantRequested,
      });

      if (!isMounted) return;

      if (response?.error === false) {
        setQuote(response);
      }
    };

    loadQuote();

    return () => {
      isMounted = false;
    };
  }, [bookingData.service?._id, instantRequested, quantity, selectedAddOnIds]);

  useEffect(() => {
    setShowAdditionalServices(false);
  }, [bookingData.service?._id]);

  useEffect(() => {
    if (!hasSelectedService || currentStep !== 0) {
      setShowAdditionalServices(false);
    }
  }, [currentStep, hasSelectedService]);

  const nextStep = () => {
    if (currentStep === 0 && quantity < 1) {
      context?.alertBox("error", "Please add at least one service before continuing.");
      return;
    }

    if (currentStep === 2 && !instantRequested && (!selectedDate || !selectedSlot)) {
      context?.alertBox("error", "Please choose a date and start time first.");
      return;
    }

    setCurrentStep((prev) => Math.min(prev + 1, stepOrder.length - 1));
  };

  const previousStep = () => {
    setCurrentStep((prev) => Math.max(prev - 1, 0));
  };

  const handleToggleAddOn = (addOnId) => {
    setSelectedAddOnIds((prev) =>
      prev.includes(addOnId) ? prev.filter((item) => item !== addOnId) : [...prev, addOnId]
    );
  };

  const decreaseQuantity = () => {
    setQuantity((prev) => Math.max(0, prev - 1));
  };

  const increaseQuantity = () => {
    setQuantity((prev) => prev + 1);
  };

  const handleSelectService = (serviceItem, requestedQuantity = 1) => {
    if (!serviceItem?._id) return;

    const normalizedQuantity = Math.max(1, Number(requestedQuantity) || 1);

    if (serviceItem._id === bookingData.service?._id) {
      setShowAdditionalServices(false);
      setQuantity((prev) => (prev > 0 ? prev + normalizedQuantity : normalizedQuantity));
      setPreviewService(null);
      return;
    }

    setPreviewService(null);
    navigate(`/product/${serviceItem._id}`, { state: { autoAdd: normalizedQuantity } });
  };

  const openAddressSelector = () => {
    setIsAddressModalOpen(true);
  };

  const closeAddressSelector = () => {
    setIsAddressModalOpen(false);
  };

  const handleAddNewAddress = () => {
    if (!context?.isLogin) {
      context?.alertBox("error", "Please login to add and select Dubai locations.");
      navigate("/login", {
        state: {
          from: `${location.pathname}${location.search}${location.hash}`,
        },
      });
      return;
    }

    closeAddressSelector();
    context?.setAddressMode("add");
    context?.setOpenAddressPanel(true);
  };

  const buildBookingPayload = () => {
    const slot = selectedDateOption?.slots?.find((item) => item.label === selectedSlot);

    return {
      serviceId: bookingData.service._id,
      quantity,
      addOnIds: selectedAddOnIds,
      instantRequested,
      professionalId: selectedProfessional !== "auto" ? selectedProfessional : "",
      professionalPreference: selectedProfessional !== "auto" ? "specific" : "auto",
      bookingDate: selectedDate,
      bookingDayLabel: selectedDateOption
        ? `${selectedDateOption.dayName} ${selectedDateOption.label}`
        : "",
      startTime: instantRequested ? "ASAP" : slot?.start || "",
      endTime: instantRequested
        ? `${bookingData.service.instantDurationMinutes || 30} mins`
        : slot?.end || "",
      slotLabel: instantRequested
        ? `Instant (${bookingData.service.instantDurationMinutes || 30} mins)`
        : selectedSlot,
      instructions,
      addressId: selectedAddress,
    };
  };

  const handleTamaraCheckout = async () => {
    if (!tamaraEligibility.isEligible) {
      context?.alertBox("error", tamaraEligibility.reason || "Tamara is not available for this total.");
      return false;
    }

    const tamaraWindow = openTamaraCheckoutWindow();

    try {
      const response = await postData("/api/bookings/tamara/checkout", {
        ...buildBookingPayload(),
        paymentMethod: "tamara",
        successUrl: `${window.location.origin}/booking/success?provider=tamara`,
        failureUrl: `${window.location.origin}/booking/failed?provider=tamara`,
        cancelUrl: `${window.location.origin}/booking/failed?provider=tamara&cancelled=1`,
      });

      if (response?.error === false && response?.checkoutUrl) {
        localStorage.setItem(
          TAMARA_CHECKOUT_STORAGE_KEY,
          JSON.stringify({
            provider: "tamara",
            mode: "booking",
            bookingId: response?.bookingId,
            tamaraOrderId: response?.tamaraOrderId || response?.orderId,
            orderId: response?.orderId || response?.tamaraOrderId,
            orderReferenceId: response?.orderReferenceId,
            totalAmt: tamaraCheckoutAmount,
          })
        );

        redirectTamaraCheckoutWindow(tamaraWindow, response.checkoutUrl);
        return true;
      }

      closeTamaraCheckoutWindow(tamaraWindow);
      context?.alertBox("error", response?.message || "Unable to start Tamara checkout.");
      return false;
    } catch (error) {
      closeTamaraCheckoutWindow(tamaraWindow);
      context?.alertBox("error", error?.message || "Unable to start Tamara checkout.");
      return false;
    }
  };

  const handleBookNow = async () => {
    if (quantity < 1) {
      context?.alertBox("error", "Please add a service before completing your booking.");
      return;
    }

    if (!context?.isLogin) {
      context?.alertBox("error", "Please login before completing your booking.");
      navigate("/login", {
        state: {
          from: `${location.pathname}${location.search}${location.hash}`,
        },
      });
      return;
    }

    if (!selectedAddress) {
      context?.alertBox("error", "Please select or add a Dubai location.");
      return;
    }

    setIsSubmitting(true);

    if (paymentMethod === "tamara") {
      const redirectedToTamara = await handleTamaraCheckout();
      if (!redirectedToTamara) {
        setIsSubmitting(false);
      }
      return;
    }

    const response = await postData("/api/bookings", {
      ...buildBookingPayload(),
      paymentMethod,
    });

    if (response?.error === false) {
      localStorage.removeItem(TAMARA_CHECKOUT_STORAGE_KEY);
      context?.alertBox("success", response?.message || "Booking confirmed successfully");
      navigate(`/booking/success?id=${response?.booking?._id || ""}`);
    } else {
      context?.alertBox("error", response?.message || "Unable to complete booking.");
    }

    setIsSubmitting(false);
  };

  const renderAddOnCard = (item, compact = false) => {
    const isSelected = selectedAddOnIds.includes(item._id);
    const addOnImage =
      item.image ||
      bookingData.service?.primaryImage ||
      bookingData.service?.images?.[0] ||
      "/homeBannerPlaceholder.jpg";
    const hasOldPrice = Number(item.oldPrice) > Number(item.price);

    return (
      <button
        key={item._id}
        type="button"
        onClick={() => handleToggleAddOn(item._id)}
        className={`group overflow-hidden rounded-[20px] border text-left transition ${
          isSelected
            ? "border-[#0f7adf] bg-[#f2fbff] shadow-[0_18px_38px_rgba(15,122,223,0.08)]"
            : "border-[#e7edf4] bg-white hover:-translate-y-[2px] hover:border-[#cdd8e3]"
        }`}
      >
        <div className="relative">
          <img
            src={addOnImage}
            alt={item.name}
            className={`w-full object-cover ${compact ? "h-[180px]" : "h-[170px]"}`}
          />
          <div className="absolute inset-x-4 top-4 flex items-start justify-between gap-3">
            <span className="rounded-full bg-white/95 px-3 py-1.5 text-[11px] font-[800] uppercase tracking-[0.14em] text-[#111827]">
              {item.badge || (item.isFeatured ? "People also added" : "Optional extra")}
            </span>
            <span
              className={`inline-flex h-11 w-11 items-center justify-center rounded-full text-[22px] font-[500] transition ${
                isSelected ? "bg-[#0f7adf] text-white" : "bg-white text-[#0f7adf]"
              }`}
            >
              {isSelected ? <MdCheck className="text-[20px]" /> : <MdAdd />}
            </span>
          </div>
        </div>

        <div className="p-4">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <h3 className="m-0 text-[18px] font-[700] leading-6 text-[#111827]">{item.name}</h3>
              <p className="m-0 mt-2 text-[13px] leading-6 text-[#6b7280]">
                {item.description || "A simple add-on to personalize the appointment."}
              </p>
            </div>
          </div>

          <div className="mt-4 flex flex-wrap items-center gap-3 text-[13px]">
            <span className="font-[700] text-[#111827]">{formatPrice(item.price)}</span>
            {hasOldPrice ? (
              <span className="text-[#94a3b8] line-through">{formatPrice(item.oldPrice)}</span>
            ) : null}
            <span className="rounded-full border border-[#e7edf4] bg-[#f8f9fa] px-3 py-1.5 text-[#6b7280]">
              {item.durationMinutes} mins
            </span>
          </div>
        </div>
      </button>
    );
  };

  const renderServiceChoiceCard = (item) => {
    const isCurrentService = item._id === bookingData.service?._id;
    const isSelectedService = isCurrentService && hasSelectedService;
    const savings =
      Number(item.oldPrice) > Number(item.price) ? Number(item.oldPrice) - Number(item.price) : 0;

    return (
      <article
        key={item._id}
        className={`overflow-hidden rounded-[24px] border p-4 text-left transition sm:p-5 ${
          isSelectedService
            ? "border-[#bfe6fb] bg-[#f6fcff]"
            : "border-[#e7edf4] bg-white hover:border-[#cdd8e3]"
        }`}
      >
        <div className="grid gap-5 xl:grid-cols-[180px_minmax(0,1fr)_220px] xl:items-center">
          <div className="relative overflow-hidden rounded-[18px] border border-[#edf2f7] bg-[#f7f9fa]">
            <img
              src={item.primaryImage || item.images?.[0] || "/homeBannerPlaceholder.jpg"}
              alt={item.name}
              className="h-[180px] w-full object-cover xl:h-[160px]"
            />
            <div className="absolute inset-x-3 top-3 flex items-start justify-between gap-2">
              <span className="rounded-full bg-white/95 px-3 py-1.5 text-[11px] font-[800] uppercase tracking-[0.14em] text-[var(--booking-text)]">
                {getServiceCardBadge(item)}
              </span>
              <span className="rounded-full bg-[#f2fbff] px-3 py-1.5 text-[11px] font-[800] uppercase tracking-[0.14em] text-[var(--booking-accent-strong)]">
                {savings > 0
                  ? `Save ${formatPrice(savings, { omitDecimals: true })}`
                  : "Home service"}
              </span>
            </div>
            <button
              type="button"
              onClick={() => setPreviewService(item)}
              className="absolute bottom-3 left-3 rounded-full border border-[#dbe4ec] bg-white px-3 py-2 text-[12px] font-[800] text-[var(--booking-text)] transition hover:border-[var(--booking-accent-strong)] hover:text-[var(--booking-accent-strong)]"
            >
              Quick look
            </button>
          </div>

          <div className="min-w-0">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
              <div>
                <p className="m-0 text-[12px] font-[700] uppercase tracking-[0.16em] text-[var(--booking-muted)]">
                  {item.brand || "Cutie Pie Beauty Salon"}
                </p>
                <h3
                  className={`mt-2 text-[24px] font-[800] leading-[1.08] ${
                    isSelectedService
                      ? "text-[var(--booking-accent-strong)]"
                      : "text-[var(--booking-text)]"
                  }`}
                >
                  {isSelectedService ? `${quantity}x ${item.name}` : item.name}
                </h3>
              </div>

              {isCurrentService ? (
                <span className="rounded-full bg-[#f2fbff] px-3 py-2 text-[12px] font-[800] text-[var(--booking-accent-strong)]">
                  {isSelectedService ? "In your booking" : "Currently viewing"}
                </span>
              ) : null}
            </div>

            <p
              className="mt-3 max-w-3xl text-[14px] leading-7 text-[var(--booking-muted)]"
              style={twoLineClampStyle}
            >
              {item.shortDescription || item.description || getServiceSupportCopy(item)}
            </p>

            <div className="mt-4 flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-2 rounded-full border border-[#dfe7ef] bg-[#f8f9fa] px-3 py-2 text-[12px] font-[700] text-[var(--booking-text)]">
                <MdAccessTime className="text-[16px] text-[var(--booking-accent-strong)]" />
                {item.durationMinutes} mins
              </span>
              <span className="inline-flex items-center gap-2 rounded-full border border-[#dfe7ef] bg-[#f8f9fa] px-3 py-2 text-[12px] font-[700] capitalize text-[var(--booking-text)]">
                <MdOutlineLocationOn className="text-[16px] text-[var(--booking-accent-strong)]" />
                Home service
              </span>
              {getServicePreviewItems(item)
                .slice(0, 2)
                .map((feature) => (
                  <span
                    key={feature}
                    className="inline-flex items-center rounded-full border border-[#dfe7ef] bg-white px-3 py-2 text-[12px] font-[600] text-[var(--booking-muted)]"
                  >
                    {feature}
                  </span>
                ))}
            </div>
          </div>

          <div className="flex flex-col gap-4 xl:items-end">
            <div className="rounded-[18px] border border-[#edf2f7] bg-[#f8f9fa] p-5 xl:min-w-[210px]">
              {item.oldPrice > item.price ? (
                <p className="m-0 text-[14px] font-[700] text-[#94a3b8] line-through">
                  {formatPrice(item.oldPrice)}
                </p>
              ) : (
                <div className="h-[22px]" />
              )}
              <p className="mt-2 text-[34px] font-[800] leading-none text-[var(--booking-text)]">
                {formatPrice(item.price)}
              </p>
              <p className="mt-3 text-[12px] font-[800] uppercase tracking-[0.18em] text-[var(--booking-muted)]">
                {item.durationMinutes} mins at-home session
              </p>
            </div>

            {isSelectedService ? (
              <div className="inline-flex items-center rounded-full border border-[#cfe5fb] bg-white">
                <button
                  type="button"
                  onClick={decreaseQuantity}
                  className="inline-flex h-12 w-12 items-center justify-center rounded-full text-[var(--booking-accent-strong)] transition hover:bg-[#f5faff]"
                  aria-label={`Decrease quantity for ${item.name}`}
                >
                  <MdRemove className="text-[20px]" />
                </button>
                <span className="min-w-[34px] text-center text-[16px] font-[800] text-[var(--booking-text)]">
                  {quantity}
                </span>
                <button
                  type="button"
                  onClick={increaseQuantity}
                  className="inline-flex h-12 w-12 items-center justify-center rounded-full text-[var(--booking-accent-strong)] transition hover:bg-[#f5faff]"
                  aria-label={`Increase quantity for ${item.name}`}
                >
                  <MdAdd className="text-[20px]" />
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => handleSelectService(item)}
                className="w-full rounded-[14px] bg-[var(--booking-accent-strong)] px-6 py-3.5 text-[14px] font-[800] text-white transition hover:brightness-[0.98] xl:max-w-[210px]"
              >
                Add to booking
              </button>
            )}
          </div>
        </div>
      </article>
    );
  };

  if (isLoading) {
    return (
      <section className="flex min-h-[420px] items-center justify-center bg-white">
        <CircularProgress />
      </section>
    );
  }

  if (!bookingData.service) {
    return (
      <section className="flex min-h-[420px] items-center justify-center bg-white">
        <div className="rounded-[28px] border border-dashed border-[#f0f0f0] bg-white px-8 py-10 text-center">
          <h2 className="text-[24px] font-[700] text-[#111827]">Service not available</h2>
          <p className="mt-2 text-[14px] text-[#6b7280]">
            This booking page could not be loaded.
          </p>
        </div>
      </section>
    );
  }

  const sectionCardClassName =
    "rounded-[22px] border border-[#e7edf4] bg-white p-4 sm:p-5";
  const activeCategoryTitle =
    activeCategory?.name || bookingData.service.catName || "Available services";
  const selectedServiceSavings =
    Number(bookingData.service.oldPrice) > Number(bookingData.service.price)
      ? Number(bookingData.service.oldPrice) - Number(bookingData.service.price)
      : 0;
  const selectedServiceLineTotal = Number(bookingData.service.price || 0) * quantity;

  return (
    <BookingLayout
      headerTitle={null}
      headerDescription={null}
      currentStep={currentStep}
      steps={steps}
      onBack={currentStep === 0 ? () => navigate(-1) : previousStep}
      categoryRail={null}
      sidebar={
        <SummaryCard
          service={bookingData.service}
          summary={bookingSummary}
          quantity={quantity}
          selectedAddOns={selectedAddOns}
          selectedDateLabel={
            selectedDateOption ? `${selectedDateOption.dayName} ${selectedDateOption.label}` : ""
          }
          selectedSlotLabel={selectedSlot}
          instantRequested={instantRequested}
          paymentMethod={paymentMethod}
          selectedAddress={selectedAddressDetails}
          onEditAddress={openAddressSelector}
          currentStep={currentStep}
          steps={steps}
          onNext={nextStep}
          onBack={previousStep}
          onConfirm={handleBookNow}
          isSubmitting={isSubmitting}
          isPrimaryActionDisabled={
            (currentStep === 0 && quantity < 1) ||
            (currentStep === 2 && !instantRequested && (!selectedDate || !selectedSlot)) ||
            (currentStep === 3 && paymentMethod === "tamara" && !tamaraEligibility.isEligible)
          }
        />
      }
    >
      <div className="space-y-5">
        {currentStep === 0 && (
          <div className={isFocusedServiceSelection ? "space-y-6" : "space-y-5"}>
            <div className={sectionCardClassName}>
              <div className="flex flex-col gap-5 xl:flex-row xl:items-center xl:justify-between">
                <div className="max-w-3xl">
                  <p className="m-0 text-[12px] font-[800] uppercase tracking-[0.18em] text-[var(--booking-accent-strong)]">
                    Step 1
                  </p>
                  <h2
                    className={`mt-2 font-[800] leading-[1.06] text-[var(--booking-text)] ${
                      isFocusedServiceSelection ? "text-[24px] lg:text-[26px]" : "text-[30px]"
                    }`}
                  >
                    {activeCategoryTitle}
                  </h2>
                  <p className="mt-3 max-w-3xl text-[14px] leading-7 text-[var(--booking-muted)]">
                    {isFocusedServiceSelection
                      ? "Your selected service is locked in below. Add a few extras or continue straight to scheduling without the clutter of every other listing."
                      : activeCategoryCopy.subtitle}
                  </p>
                </div>

                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="rounded-[18px] border border-[#edf2f7] bg-[#f8f9fa] px-4 py-4">
                    <p className="m-0 text-[11px] font-[800] uppercase tracking-[0.16em] text-[var(--booking-muted)]">
                      Available
                    </p>
                    <p className="m-0 mt-2 text-[18px] font-[800] text-[var(--booking-text)]">
                      {displayedServices.length} service{displayedServices.length === 1 ? "" : "s"}
                    </p>
                  </div>
                  <div className="rounded-[18px] border border-[#edf2f7] bg-[#f8f9fa] px-4 py-4">
                    <p className="m-0 text-[11px] font-[800] uppercase tracking-[0.16em] text-[var(--booking-muted)]">
                      Selected
                    </p>
                    <p className="m-0 mt-2 text-[18px] font-[800] text-[var(--booking-text)]">
                      {hasSelectedService ? `${quantity} item${quantity > 1 ? "s" : ""}` : "None yet"}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {isCategoryLoading ? (
              <div className="flex min-h-[240px] items-center justify-center rounded-[24px] border border-[#e7edf4] bg-white px-6 py-16">
                <CircularProgress size={28} />
              </div>
            ) : isFocusedServiceSelection ? (
              <>
                <article className="rounded-[24px] border border-[#cfe7f7] bg-white px-5 py-5 sm:px-6">
                  <div className="grid gap-5 xl:grid-cols-[148px_minmax(0,1fr)_228px] xl:items-center">
                    <div className="relative overflow-hidden rounded-[18px] border border-[#edf2f7] bg-[#f8f9fa]">
                      <img
                        src={
                          bookingData.service.primaryImage ||
                          bookingData.service.images?.[0] ||
                          "/homeBannerPlaceholder.jpg"
                        }
                        alt={bookingData.service.name}
                        className="h-[148px] w-full object-cover xl:h-[132px]"
                      />
                    </div>

                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="rounded-full bg-[#f2fbff] px-3 py-1.5 text-[11px] font-[800] uppercase tracking-[0.14em] text-[var(--booking-accent-strong)]">
                          Selected
                        </span>
                        <span className="rounded-full border border-[#dfe7ef] bg-white px-3 py-1.5 text-[11px] font-[800] uppercase tracking-[0.14em] text-[var(--booking-text)]">
                          {selectedServiceSavings > 0
                            ? `Save ${formatPrice(selectedServiceSavings, { omitDecimals: true })}`
                            : "Home service"}
                        </span>
                        <button
                          type="button"
                          onClick={() => setPreviewService(bookingData.service)}
                          className="rounded-full border border-[#dbe4ec] bg-white px-3 py-1.5 text-[11px] font-[800] uppercase tracking-[0.14em] text-[var(--booking-text)] transition hover:border-[var(--booking-accent-strong)] hover:text-[var(--booking-accent-strong)]"
                        >
                          Quick look
                        </button>
                      </div>

                      <h3 className="mt-3 text-[28px] font-[800] leading-[1.08] text-[var(--booking-text)]">
                        {bookingData.service.name}
                      </h3>
                      <p
                        className="mt-3 max-w-3xl text-[14px] leading-7 text-[var(--booking-muted)]"
                        style={twoLineClampStyle}
                      >
                        {bookingData.service.shortDescription ||
                          bookingData.service.description ||
                          getServiceSupportCopy(bookingData.service)}
                      </p>

                      <div className="mt-4 flex flex-wrap items-center gap-2">
                        <span className="inline-flex items-center gap-2 rounded-full border border-[#dfe7ef] bg-[#f8f9fa] px-3 py-2 text-[12px] font-[700] text-[var(--booking-text)]">
                          <MdAccessTime className="text-[16px] text-[var(--booking-accent-strong)]" />
                          {bookingData.service.durationMinutes} mins
                        </span>
                        <span className="inline-flex items-center gap-2 rounded-full border border-[#dfe7ef] bg-[#f8f9fa] px-3 py-2 text-[12px] font-[700] capitalize text-[var(--booking-text)]">
                          <MdOutlineLocationOn className="text-[16px] text-[var(--booking-accent-strong)]" />
                          Home service
                        </span>
                        {getServicePreviewItems(bookingData.service)
                          .slice(0, 2)
                          .map((feature) => (
                            <span
                              key={feature}
                              className="inline-flex items-center rounded-full border border-[#dfe7ef] bg-white px-3 py-2 text-[12px] font-[600] text-[var(--booking-muted)]"
                            >
                              {feature}
                            </span>
                          ))}
                      </div>
                    </div>

                    <div className="rounded-[20px] border border-[#edf2f7] bg-[#f8f9fa] p-5">
                      {bookingData.service.oldPrice > bookingData.service.price ? (
                        <p className="m-0 text-[14px] font-[700] text-[#94a3b8] line-through">
                          {formatPrice(bookingData.service.oldPrice)}
                        </p>
                      ) : (
                        <div className="h-[22px]" />
                      )}
                      <p className="mt-2 text-[34px] font-[800] leading-none text-[var(--booking-text)]">
                        {formatPrice(bookingData.service.price)}
                      </p>
                      <p className="mt-3 text-[12px] font-[800] uppercase tracking-[0.18em] text-[var(--booking-muted)]">
                        {bookingData.service.durationMinutes} mins at-home session
                      </p>
                      <p className="mt-2 text-[13px] text-[var(--booking-muted)]">
                        Line total {formatPrice(selectedServiceLineTotal)}
                      </p>

                      <div className="mt-5 inline-flex items-center rounded-full border border-[#cfe5fb] bg-white">
                        <button
                          type="button"
                          onClick={decreaseQuantity}
                          className="inline-flex h-12 w-12 items-center justify-center rounded-full text-[var(--booking-accent-strong)] transition hover:bg-[#f5faff]"
                          aria-label={`Decrease quantity for ${bookingData.service.name}`}
                        >
                          <MdRemove className="text-[20px]" />
                        </button>
                        <span className="min-w-[42px] text-center text-[16px] font-[800] text-[var(--booking-text)]">
                          {quantity}
                        </span>
                        <button
                          type="button"
                          onClick={increaseQuantity}
                          className="inline-flex h-12 w-12 items-center justify-center rounded-full text-[var(--booking-accent-strong)] transition hover:bg-[#f5faff]"
                          aria-label={`Increase quantity for ${bookingData.service.name}`}
                        >
                          <MdAdd className="text-[20px]" />
                        </button>
                      </div>
                    </div>
                  </div>
                </article>

                <div className={sectionCardClassName}>
                  <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
                    <div>
                      <p className="m-0 text-[12px] font-[800] uppercase tracking-[0.18em] text-[var(--booking-accent-strong)]">
                        People also added
                      </p>
                      <h3 className="mt-2 text-[24px] font-[800] text-[var(--booking-text)]">
                        Add a few quick extras
                      </h3>
                      <p className="mt-2 max-w-3xl text-[14px] leading-7 text-[var(--booking-muted)]">
                        Pick from the most popular add-ons now, or open the full add-on step for the
                        complete list.
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-3">
                      {selectedAddOns.length ? (
                        <span className="rounded-full bg-[#f2fbff] px-4 py-2 text-[13px] font-[700] text-[var(--booking-accent-strong)]">
                          {selectedAddOns.length} selected
                        </span>
                      ) : null}
                      <button
                        type="button"
                        onClick={nextStep}
                        className="rounded-full border border-[#dbe4ec] bg-white px-5 py-3 text-[13px] font-[800] text-[var(--booking-text)] transition hover:border-[var(--booking-accent-strong)] hover:text-[var(--booking-accent-strong)]"
                      >
                        Browse full add-ons
                      </button>
                    </div>
                  </div>

                  {recommendedAddOns.length ? (
                    <div className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                      {recommendedAddOns.map((item) => renderAddOnCard(item))}
                    </div>
                  ) : (
                    <div className="mt-6 rounded-[20px] border border-dashed border-[#dbe3ea] bg-[#f8f9fa] px-5 py-10 text-center text-[14px] text-[#6b7280]">
                      No add-ons are attached to this service yet.
                    </div>
                  )}
                </div>

                <div className="rounded-[24px] border border-[#e7edf4] bg-white px-5 py-5 sm:px-6">
                  <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                    <div className="max-w-2xl">
                      <p className="m-0 text-[12px] font-[800] uppercase tracking-[0.18em] text-[var(--booking-muted)]">
                        Next
                      </p>
                      <p className="m-0 mt-2 text-[14px] leading-7 text-[var(--booking-muted)]">
                        Your booking summary updates live on the right. Continue when you&apos;re ready, or reopen other services to compare again.
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-3">
                      {additionalServices.length ? (
                        <button
                          type="button"
                          onClick={() => setShowAdditionalServices((prev) => !prev)}
                          className="rounded-full border border-[#dbe4ec] bg-white px-5 py-3 text-[13px] font-[800] text-[var(--booking-text)] transition hover:border-[var(--booking-accent-strong)] hover:text-[var(--booking-accent-strong)]"
                        >
                          {showAdditionalServices ? "Hide more services" : "Add more services"}
                        </button>
                      ) : null}

                      <button
                        type="button"
                        onClick={nextStep}
                        className="rounded-full bg-[var(--booking-accent-strong)] px-6 py-3 text-[14px] font-[800] text-white transition hover:brightness-[0.98]"
                      >
                        Next
                      </button>
                    </div>
                  </div>
                </div>

                {showAdditionalServices && additionalServices.length ? (
                  <div className="space-y-4">
                    <div className={sectionCardClassName}>
                      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
                        <div>
                          <p className="m-0 text-[12px] font-[800] uppercase tracking-[0.18em] text-[var(--booking-accent-strong)]">
                            Add more services
                          </p>
                          <h3 className="mt-2 text-[24px] font-[800] text-[var(--booking-text)]">
                            Compare other options
                          </h3>
                          <p className="mt-2 text-[14px] leading-7 text-[var(--booking-muted)]">
                            These were hidden to keep the booking focused. You can swap services at any time.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">{additionalServices.map((item) => renderServiceChoiceCard(item))}</div>
                  </div>
                ) : null}
              </>
            ) : (
              <div className="space-y-4">{displayedServices.map((item) => renderServiceChoiceCard(item))}</div>
            )}
          </div>
        )}

        {currentStep === 1 && (
          <div className="space-y-5">
            <div className={sectionCardClassName}>
              <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
                <div>
                  <p className="m-0 text-[12px] font-[800] uppercase tracking-[0.18em] text-[var(--booking-accent-strong)]">
                    Step 2
                  </p>
                  <h2 className="mt-2 text-[28px] font-[800] text-[#111827]">Popular add-ons</h2>
                  <p className="mt-2 text-[14px] leading-7 text-[#6b7280]">
                    People also add these upgrades to the same appointment.
                  </p>
                </div>
                <div className="rounded-full bg-[#f2fbff] px-4 py-2 text-[13px] font-[700] text-[#0f7adf]">
                  {selectedAddOns.length} selected
                </div>
              </div>

              {bookingData.addOns.length ? (
                <>
                  <div className="mt-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
                    {bookingData.addOns.map((item) => renderAddOnCard(item, true))}
                  </div>

                  <div className="mt-5 rounded-[18px] border border-[#e7edf4] bg-[#f7f9fa] px-5 py-4 text-[13px] text-[#6b7280]">
                    The duration of the session may change based on your selection.
                  </div>
                </>
              ) : (
                <div className="mt-5 rounded-[18px] border border-dashed border-[#dbe3ea] bg-[#f8fafc] px-5 py-8 text-center text-[14px] text-[#6b7280]">
                  No add-ons are attached to this service yet.
                </div>
              )}
            </div>
          </div>
        )}

        {currentStep === 2 && (
          <div className="space-y-5">
            <div className={sectionCardClassName}>
              <p className="m-0 text-[12px] font-[800] uppercase tracking-[0.18em] text-[var(--booking-accent-strong)]">
                Step 3
              </p>
              <h2 className="mt-2 text-[28px] font-[800] text-[#111827]">Date & time</h2>
              <p className="mt-2 text-[14px] leading-7 text-[#6b7280]">
                Select auto-assign for the fastest match, or request a preferred specialist.
              </p>

              <div className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                <button
                  type="button"
                  onClick={() => setSelectedProfessional("auto")}
                  className={`rounded-[18px] border p-5 text-left transition ${
                    selectedProfessional === "auto"
                      ? "border-[#0f7adf] bg-[#f2fbff]"
                      : "border-[#e7edf4] bg-white hover:border-[#cdd8e3]"
                  }`}
                >
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-[linear-gradient(135deg,#00bfff_0%,#0891d1_100%)] text-[18px] font-[800] text-white">
                    CP
                  </div>
                  <h3 className="mt-4 text-[18px] font-[700] text-[#111827]">Auto assign</h3>
                  <div className="mt-2 flex items-center gap-1 text-[13px] font-[700] text-[#111827]">
                    <MdOutlineStar className="text-[18px] text-[#f59e0b]" />
                    Best available match
                  </div>
                  <p className="mt-2 text-[13px] leading-6 text-[#6b7280]">
                    We&apos;ll assign the best available professional for the chosen slot.
                  </p>
                </button>

                {bookingData.professionals.map((item) => (
                  <button
                    key={item._id}
                    type="button"
                    onClick={() => setSelectedProfessional(item._id)}
                    className={`rounded-[18px] border p-5 text-left transition ${
                      selectedProfessional === item._id
                        ? "border-[#0f7adf] bg-[#f2fbff]"
                        : "border-[#e7edf4] bg-white hover:border-[#cdd8e3]"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <img
                        src={item.avatar || bookingData.service.primaryImage || "/user.jpg"}
                        alt={item.name}
                        className="h-16 w-16 rounded-full border border-[#dbe4ec] object-cover"
                      />
                      <span className="rounded-full bg-white px-3 py-1.5 text-[12px] font-[800] text-[#0f7adf]">
                        {selectedProfessional === item._id ? "Selected" : "Preferred"}
                      </span>
                    </div>
                    <h3 className="mt-4 text-[18px] font-[700] text-[#111827]">{item.name}</h3>
                    <div className="mt-2 flex items-center gap-1 text-[14px] font-[700] text-[#111827]">
                      <MdOutlineStar className="text-[18px] text-[#f59e0b]" />
                      {Number(item.rating || 4.9).toFixed(1)}
                    </div>
                    <p className="mt-2 text-[13px] leading-6 text-[#6b7280]">
                      {item.title || "Beauty specialist"}{item.yearsExperience ? ` - ${item.yearsExperience} years experience` : ""}
                    </p>
                    <p className="mt-1 text-[13px] leading-6 text-[#6b7280]">
                      Recommended in your area
                    </p>
                  </button>
                ))}
              </div>
            </div>

            <div className={sectionCardClassName}>
              <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                <div>
                  <h3 className="text-[22px] font-[700] text-[#111827]">When would you like your service?</h3>
                  <p className="mt-2 text-[14px] leading-7 text-[#6b7280]">
                    Choose instant service for the soonest slot, or reserve a time that fits your day.
                  </p>
                </div>
                <div className="inline-flex rounded-full bg-[#f7f9fa] p-1">
                  <button
                    type="button"
                    onClick={() => setInstantRequested(false)}
                    className={`rounded-full px-4 py-2.5 text-[13px] font-[700] transition ${
                      !instantRequested ? "bg-white text-[#111827] shadow-sm" : "text-[#6b7280]"
                    }`}
                  >
                    Pick a slot
                  </button>
                  <button
                    type="button"
                    onClick={() => setInstantRequested(true)}
                    className={`rounded-full px-4 py-2.5 text-[13px] font-[700] transition ${
                      instantRequested ? "bg-white text-[#111827] shadow-sm" : "text-[#6b7280]"
                    }`}
                  >
                    Instant
                  </button>
                </div>
              </div>

              {!instantRequested ? (
                <>
                  <div className="-mx-1 mt-6 overflow-x-auto px-1 pb-2">
                    <div className="flex min-w-max gap-4">
                      {bookingData.availability.map((date) => {
                        const isSelected = selectedDate === date.value;
                        const { dayName, dayNumber, monthLabel } = getDateButtonParts(date);

                        return (
                          <button
                            key={date.value}
                            type="button"
                            onClick={() => setSelectedDate(date.value)}
                            className="flex flex-col items-center gap-2 text-center transition"
                          >
                            <span
                              className={`text-[13px] font-[700] ${
                                isSelected ? "text-[#0f7adf]" : "text-[#6b7280]"
                              }`}
                            >
                              {dayName}
                            </span>
                            <span
                              className={`inline-flex h-16 w-16 flex-col items-center justify-center rounded-full border text-center transition ${
                                isSelected
                                  ? "border-[#0f7adf] bg-[#f2fbff] text-[#0f7adf]"
                                  : "border-[#dbe4ec] bg-white text-[#111827] hover:border-[#0f7adf]"
                              }`}
                            >
                              <span className="text-[22px] font-[800] leading-none">{dayNumber}</span>
                              {monthLabel ? (
                                <span className="mt-1 text-[10px] font-[800] uppercase tracking-[0.14em]">
                                  {monthLabel}
                                </span>
                              ) : null}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="mt-6">
                    <div className="flex items-center justify-between gap-3">
                      <p className="m-0 text-[12px] font-[800] uppercase tracking-[0.18em] text-[#94a3b8]">
                        What time would you like us to start?
                      </p>
                    </div>
                    <div className="mt-4 flex flex-wrap gap-3">
                      {selectedDateOption?.slots?.length ? (
                        selectedDateOption.slots.map((slot) => (
                          <button
                            key={slot.label}
                            type="button"
                            onClick={() => setSelectedSlot(slot.label)}
                            className={`rounded-full border px-4 py-3 text-[13px] font-[700] transition ${
                              selectedSlot === slot.label
                                ? "border-[#0f7adf] bg-[#f2fbff] text-[#0f7adf]"
                                : "border-[#dbe4ec] bg-white text-[#111827] hover:border-[#0f7adf]"
                            }`}
                          >
                            {slot.label}
                          </button>
                        ))
                      ) : (
                        <div className="rounded-[16px] border border-dashed border-[#dbe3ea] px-4 py-6 text-[14px] text-[#6b7280]">
                          No time slots are available for this day right now.
                        </div>
                      )}
                    </div>
                  </div>
                </>
              ) : (
                <div className="mt-6 rounded-[16px] border border-[#dcebf5] bg-[#f7fbfe] px-4 py-4 text-[14px] leading-7 text-[#6b7280]">
                  Instant booking will request the earliest available professional for an estimated{" "}
                  {bookingData.service.instantDurationMinutes || 30}-minute visit.
                </div>
              )}
            </div>

            <div className="grid gap-5 xl:grid-cols-[minmax(0,1.1fr)_minmax(260px,0.9fr)]">
              <div className={sectionCardClassName}>
                <p className="m-0 text-[12px] font-[800] uppercase tracking-[0.18em] text-[var(--booking-accent-strong)]">
                  Special requirements
                </p>
                <h3 className="mt-2 text-[22px] font-[700] text-[#111827]">
                  Any instructions or preferences?
                </h3>
                <textarea
                  value={instructions}
                  onChange={(event) => setInstructions(event.target.value.slice(0, 150))}
                  placeholder="Example: Sensitive skin, nail color preference, shorter nails, or access notes."
                  className="mt-4 h-32 w-full rounded-[16px] border border-[#dbe4ec] bg-[#f7f9fa] px-4 py-3 text-[14px] leading-7 outline-none transition placeholder:text-[#9aa6b2] focus:border-[#0f7adf]"
                />
                <p className="mt-2 text-right text-[12px] text-[#94a3b8]">{instructions.length}/150</p>
              </div>

              <div className={sectionCardClassName}>
                <p className="m-0 text-[12px] font-[800] uppercase tracking-[0.18em] text-[var(--booking-accent-strong)]">
                  Booking policy
                </p>
                <p className="mt-3 text-[14px] leading-7 text-[#6b7280]">
                  Enjoy free cancellation up to 6 hours before your booking start time.
                </p>
                <p className="mt-2 text-[14px] leading-7 text-[#6b7280]">
                  We&apos;ll carry these notes through to checkout so your professional sees them
                  before arrival.
                </p>
              </div>
            </div>
          </div>
        )}

        {currentStep === 3 && (
          <div className="space-y-5">
            <div className={sectionCardClassName}>
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="m-0 text-[12px] font-[800] uppercase tracking-[0.18em] text-[var(--booking-accent-strong)]">
                    Step 4
                  </p>
                  <h2 className="mt-2 text-[28px] font-[800] text-[#111827]">Checkout</h2>
                  <p className="mt-2 text-[14px] leading-7 text-[#6b7280]">
                    Your salon professional will visit this location.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={openAddressSelector}
                  className="rounded-full border border-[#dbe3ea] px-4 py-2 text-[13px] font-[700] text-[#111827]"
                >
                  {selectedAddressDetails ? "Edit location" : "Add location"}
                </button>
              </div>

              <div className="mt-5 grid gap-4 md:grid-cols-2">
                  {savedAddresses.length ? (
                    savedAddresses.map((address) => {
                    const isSelected = selectedAddress === address._id;
                    return (
                      <button
                        key={address._id}
                        type="button"
                        onClick={() => setSelectedAddress(address._id)}
                        className={`rounded-[16px] border p-4 text-left transition ${
                          isSelected
                            ? "border-[#0f7adf] bg-[#f2fbff]"
                            : "border-[#e7edf4] bg-white hover:border-[#cdd8e3]"
                        }`}
                        >
                          <p className="m-0 text-[11px] font-[700] uppercase tracking-[0.18em] text-[#94a3b8]">
                          {address.addressType || "Location"}
                          </p>
                          <p className="m-0 mt-2 text-[15px] font-[700] text-[#111827]">
                          {getAddressTitle(address)}
                          </p>
                          <p className="m-0 mt-1 text-[13px] leading-6 text-[#6b7280]">
                          {formatAddressMeta(address)}
                          </p>
                          {formatAddressExtras(address) ? (
                            <p className="m-0 mt-1 text-[13px] text-[#6b7280]">
                              {formatAddressExtras(address)}
                            </p>
                          ) : null}
                        </button>
                      );
                  })
                ) : (
                  <div className="rounded-[16px] border border-dashed border-[#dbe3ea] px-4 py-10 text-center text-[14px] text-[#6b7280]">
                    Add an address in your account to continue.
                  </div>
                )}
              </div>
            </div>

            <div className="grid gap-5 xl:grid-cols-[minmax(0,1.14fr)_minmax(280px,0.86fr)]">
              <div className={sectionCardClassName}>
                <div className="flex items-center gap-2 text-[20px] font-[700] text-[#111827]">
                  <MdOutlinePayment className="text-[22px] text-[#0f7adf]" />
                  Payment method
                </div>

                <div
                  className={`mt-5 rounded-[18px] border p-5 ${
                    tamaraEligibility.isEligible
                      ? "border-[#0f7adf] bg-[#f2fbff]"
                      : "border-[#e7edf4] bg-white opacity-70"
                  }`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-4">
                    <div>
                      <img
                        src="https://cdn.tamara.co/assets/png/tamara-logo-badge-en.png"
                        alt="Tamara"
                        className="h-9 w-auto object-contain"
                      />
                      <h3 className="mt-4 text-[18px] font-[700] text-[#111827]">Tamara</h3>
                      <p className="mt-2 max-w-[560px] text-[14px] leading-7 text-[#6b7280]">
                        {tamaraOptionDescription}
                      </p>
                    </div>

                    <span className="rounded-full bg-white px-4 py-2 text-[12px] font-[800] uppercase tracking-[0.14em] text-[#0f7adf]">
                      Selected
                    </span>
                  </div>

                  <div className="mt-4 rounded-[16px] bg-white/80 px-4 py-4 text-[13px] leading-6 text-[#4b5563]">
                    You&apos;ll continue to Tamara to complete the payment securely after reviewing
                    your booking.
                  </div>

                  {!tamaraEligibility.isEligible ? (
                    <p className="mt-4 text-[13px] font-[700] text-[#ef4444]">
                      {tamaraEligibility.reason}
                    </p>
                  ) : null}
                </div>

                {tamaraCheckoutAmount > 0 ? (
                  <TamaraPromoWidget
                    amount={tamaraCheckoutAmount}
                    publicKey={tamaraConfig.publicKey}
                    countryCode={tamaraConfig.countryCode}
                    installments={tamaraConfig.installments}
                    inlineType="3"
                    className={`mt-5 ${tamaraEligibility.isEligible ? "" : "opacity-70"}`}
                    title="Pay later with Tamara"
                  />
                ) : null}
              </div>

              <div className="space-y-5">
                <div className={sectionCardClassName}>
                  <label className="text-[15px] font-[700] text-[#111827]">Booking notes</label>
                  <div className="mt-3 rounded-[16px] border border-[#dbe4ec] bg-[#f7f9fa] px-4 py-4">
                    <p className="m-0 text-[14px] leading-7 text-[#6b7280]">
                      {instructions
                        ? instructions
                        : "No special requirements added. You can go back to Step 3 to include preferences or arrival notes."}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      <BookingAddressModal
        open={isAddressModalOpen}
        addresses={savedAddresses}
        selectedAddressId={selectedAddress}
        onSelect={setSelectedAddress}
        onClose={closeAddressSelector}
        onAddNew={handleAddNewAddress}
        onConfirm={closeAddressSelector}
      />

      {previewService ? (
        <div
          className="fixed inset-0 z-40 flex items-center justify-center bg-[rgba(15,23,42,0.48)] p-4"
          onClick={() => setPreviewService(null)}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="service-preview-title"
            onClick={(event) => event.stopPropagation()}
            className="max-h-[92vh] w-full max-w-[920px] overflow-hidden rounded-[24px] bg-white shadow-[0_28px_80px_rgba(15,23,42,0.24)]"
          >
            <div className="flex items-center justify-between border-b border-[#f0f0f0] px-6 py-5">
              <div>
                <p className="m-0 text-[12px] font-[700] uppercase tracking-[0.18em] text-[#94a3b8]">
                  Quick view
                </p>
                <h2
                  id="service-preview-title"
                  className="mt-2 text-[28px] font-[800] leading-[1.1] text-[#111827]"
                >
                  {previewService.name}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setPreviewService(null)}
                className="inline-flex h-11 w-11 items-center justify-center rounded-[14px] border border-[#f0f0f0] text-[#111827] transition hover:border-[#0f7adf] hover:text-[#0f7adf]"
                aria-label="Close service details"
              >
                <MdClose className="text-[24px]" />
              </button>
            </div>

            <div className="grid lg:grid-cols-[1.08fr_0.92fr]">
              <div className="border-b border-[#eef2f7] p-5 lg:border-b-0 lg:border-r">
                <div className="relative overflow-hidden rounded-[20px] bg-[linear-gradient(135deg,#fff7fb_0%,#f2fbff_100%)]">
                  <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(255,255,255,0.96)_0%,rgba(255,255,255,0.72)_38%,rgba(255,255,255,0)_70%)]" />
                  <img
                    src={previewService.primaryImage || "/homeBannerPlaceholder.jpg"}
                    alt={previewService.name}
                    className="h-[340px] w-full object-cover object-center"
                  />

                  <div className="absolute left-5 top-5 z-10 grid max-w-[250px] gap-3 sm:grid-cols-2">
                    {getPreviewFeatureTiles(previewService).map(({ label, Icon }) => (
                      <div
                        key={label}
                        className="rounded-[14px] border border-white/70 bg-white/88 p-3 shadow-[0_12px_24px_rgba(15,23,42,0.08)] backdrop-blur"
                      >
                        <span className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-[var(--booking-accent-soft)] text-[var(--booking-accent-strong)]">
                          <Icon className="text-[18px]" />
                        </span>
                        <p className="m-0 mt-2 text-[12px] font-[800] leading-5 text-[#111827]">
                          {label}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-4 flex flex-wrap gap-2">
                  <span className="inline-flex items-center gap-2 rounded-full border border-[#d8e9fb] bg-white px-3 py-2 text-[12px] font-[700] text-[#0f7adf]">
                    <MdAccessTime className="text-[16px]" />
                    {previewService.durationMinutes} mins
                  </span>
                  <span className="inline-flex items-center gap-2 rounded-full border border-[#d8e9fb] bg-white px-3 py-2 text-[12px] font-[700] capitalize text-[#0f7adf]">
                    <MdOutlineLocationOn className="text-[16px]" />
                    {previewService.locationType} service
                  </span>
                </div>
              </div>

              <div className="flex max-h-[70vh] flex-col">
                <div className="overflow-y-auto px-6 py-5">
                  <div className="flex items-end justify-between gap-4">
                    <div>
                      {previewService.oldPrice > previewService.price ? (
                        <p className="m-0 text-[15px] font-[600] text-[#94a3b8] line-through">
                          {formatPrice(previewService.oldPrice)}
                        </p>
                      ) : null}
                      <p className="m-0 mt-1 text-[30px] font-[800] leading-none text-[#111827]">
                        {formatPrice(previewService.price)}
                      </p>
                    </div>
                  </div>

                  {tamaraConfig?.publicKey ? (
                    <TamaraPromoWidget
                      amount={previewService.price}
                      publicKey={tamaraConfig.publicKey}
                      countryCode={tamaraConfig.countryCode}
                      installments={tamaraConfig.installments}
                      inlineType="2"
                      className="mt-5"
                      title="Pay later with Tamara"
                    />
                  ) : null}

                  <p className="mt-5 text-[15px] leading-8 text-[#4b5563]">
                    {previewService.description || previewService.shortDescription}
                  </p>

                  <div className="mt-6">
                    <h3 className="text-[18px] font-[700] text-[#111827]">What's included</h3>
                    <div className="mt-4 space-y-3">
                      {getServicePreviewItems(previewService).length ? (
                        getServicePreviewItems(previewService).map((item) => (
                          <div key={item} className="flex items-start gap-3">
                            <span className="mt-0.5 inline-flex h-6 w-6 items-center justify-center rounded-full bg-[#e7f3ff] text-[#0f7adf]">
                              <MdCheck className="text-[15px]" />
                            </span>
                            <p className="m-0 text-[14px] leading-7 text-[#4b5563]">{item}</p>
                          </div>
                        ))
                      ) : (
                        <p className="m-0 text-[14px] leading-7 text-[#6b7280]">
                          Full service details will be confirmed during the next step.
                        </p>
                      )}
                    </div>
                  </div>
                </div>

                <div className="sticky bottom-0 border-t border-[#f0f0f0] bg-white/96 p-5 backdrop-blur">
                  <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                    <div className="inline-flex items-center rounded-[14px] border border-[#cfe5fb] bg-white shadow-[0_12px_24px_rgba(0,191,255,0.08)]">
                      <button
                        type="button"
                        onClick={() => setPreviewQuantity((prev) => Math.max(1, prev - 1))}
                        className="inline-flex h-12 w-12 items-center justify-center rounded-[14px] text-[var(--booking-accent-strong)] transition hover:bg-[#f5faff]"
                        aria-label={`Decrease quantity for ${previewService.name}`}
                      >
                        <MdRemove className="text-[20px]" />
                      </button>
                      <span className="min-w-[42px] text-center text-[16px] font-[800] text-[var(--booking-text)]">
                        {previewQuantity}
                      </span>
                      <button
                        type="button"
                        onClick={() => setPreviewQuantity((prev) => prev + 1)}
                        className="inline-flex h-12 w-12 items-center justify-center rounded-[14px] text-[var(--booking-accent-strong)] transition hover:bg-[#f5faff]"
                        aria-label={`Increase quantity for ${previewService.name}`}
                      >
                        <MdAdd className="text-[20px]" />
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleSelectService(previewService, previewQuantity)}
                      className="w-full rounded-[14px] bg-[var(--booking-accent-strong)] px-5 py-4 text-[15px] font-[800] text-white shadow-[0_14px_30px_rgba(0,191,255,0.24)] transition hover:brightness-[0.98] sm:max-w-[280px]"
                    >
                      Add for {formatPrice(Number(previewService.price || 0) * previewQuantity)}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </BookingLayout>
  );
};

export { ProductDetails };
