import React, { useContext, useEffect, useState } from "react";
import { Sidebar } from "../../components/Sidebar";
import Breadcrumbs from "@mui/material/Breadcrumbs";
import ProductItem from "../../components/ProductItem";
import ProductItemListView from "../../components/ProductItemListView";
import Button from "@mui/material/Button";
import { IoGridSharp } from "react-icons/io5";
import { LuMenu } from "react-icons/lu";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import Pagination from "@mui/material/Pagination";
import ProductLoadingGrid from "../../components/ProductLoading/productLoadingGrid";
import { postData } from "../../utils/api";
import { MyContext } from "../../App";

const ProductListing = () => {
  const [itemView, setItemView] = useState("grid");
  const [anchorEl, setAnchorEl] = React.useState(null);

  const [productsData, setProductsData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  const [selectedSortVal, setSelectedSortVal] = useState("Name, A to Z");

  const context = useContext(MyContext);
  const listViewClassName = "grid grid-cols-1 gap-6";

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [])


  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };



  const handleSortBy = (name, order, products, value) => {
    setSelectedSortVal(value);
    postData(`/api/product/sortBy`, {
      products: products,
      sortBy: name,
      order: order
    }).then((res) => {
      setProductsData(res);
      setAnchorEl(null);
    })
  }

  return (
    <section className="pb-12">

      <div className="bg-[linear-gradient(180deg,var(--brand-shell)_0%,#ffffff_32%)] px-0 py-6">
        <div className="container flex flex-col gap-8 lg:flex-row">
          <div className={`sidebarWrapper fixed -bottom-[100%] left-0 z-[102] w-full bg-white p-3 opacity-0 transition-all lg:static lg:z-[100] lg:h-full lg:w-[280px] lg:bg-transparent lg:p-0 lg:opacity-100 ${context?.openFilter === true ? 'open' : ''}`}>
            <Sidebar
              productsData={productsData}
              setProductsData={setProductsData}
              isLoading={isLoading}
              setIsLoading={setIsLoading}
              page={page}
              setTotalPages={setTotalPages}
            />
          </div>

          {
            context?.windowWidth < 992 &&
            <div className={`filter_overlay w-full h-full bg-[rgba(0,0,0,0.5)] fixed top-0 left-0 z-[101]  ${context?.openFilter === true ? 'block' : 'hidden'}`}
              onClick={()=>context?.setOpenFilter(false)}
            ></div>
          }


          <div className="rightContent w-full min-w-0 flex-1 py-1">
            

            <div className="sticky top-[164px] z-[99] mb-6 mt-6 flex items-center justify-between rounded-[24px] border border-[var(--brand-border)] bg-white px-4 py-3 shadow-[0_18px_38px_rgba(15,23,42,0.05)] sm:px-5">
              <div className="col1 flex items-center itemViewActions">
                <Button
                  className={`!h-[42px] !min-w-[42px] !w-[42px] !rounded-full 
                    !text-[var(--brand-ink)] ${itemView === "list" && "active !bg-[var(--brand-shell)]"}`}
                  onClick={() => setItemView("list")}
                >
                  <LuMenu className="text-[16px] text-[rgba(22,32,50,0.7)]" />
                </Button>
                <Button
                  className={`!h-[42px] !min-w-[42px] !w-[42px] !rounded-full 
                    !text-[var(--brand-ink)] ${itemView === "grid" && "active !bg-[var(--brand-shell)]"}`}
                  onClick={() => setItemView("grid")}
                >
                  <IoGridSharp className="text-[14px] text-[rgba(22,32,50,0.7)]" />
                </Button>

                <span className="hidden pl-3 text-[14px] font-[600] text-[var(--brand-muted)] sm:block md:block lg:block">
                  There are {productsData?.products?.length !== 0 ? productsData?.products?.length : 0} services available.
                </span>
              </div>

              <div className="col2 ml-auto flex items-center justify-end gap-3">
                <span className="pl-3 text-[14px] font-[600] text-[var(--brand-muted)]">
                  Sort By
                </span>

                <Button
                  id="basic-button"
                  aria-controls={open ? "basic-menu" : undefined}
                  aria-haspopup="true"
                  aria-expanded={open ? "true" : undefined}
                  onClick={handleClick}
                  className="!rounded-full !border !border-[var(--brand-border)] !bg-[var(--brand-shell)] !px-4 !py-2 !text-[12px] !font-[700] !capitalize !text-[var(--brand-ink)]"
                >
                  {selectedSortVal}
                </Button>

                <Menu
                  id="basic-menu"
                  anchorEl={anchorEl}
                  open={open}
                  onClose={handleClose}
                  MenuListProps={{
                    "aria-labelledby": "basic-button",
                  }}
                >
                  <MenuItem
                    onClick={() => handleSortBy('name', 'asc', productsData, 'Name, A to Z')}
                    className="!text-[13px] !text-[#000] !capitalize"
                  >
                    Name, A to Z
                  </MenuItem>


                  <MenuItem
                    onClick={() => handleSortBy('name', 'desc', productsData, 'Name, Z to A')}
                    className="!text-[13px] !text-[#000] !capitalize"
                  >
                    Name, Z to A
                  </MenuItem>


                  <MenuItem
                    onClick={() => handleSortBy('price', 'asc', productsData, 'Price, low to high')}
                    className="!text-[13px] !text-[#000] !capitalize"
                  >
                    Price, low to high
                  </MenuItem>


                  <MenuItem
                    onClick={() => handleSortBy('price', 'desc', productsData, ' Price, high to low')}
                    className="!text-[13px] !text-[#000] !capitalize"
                  >
                    Price, high to low
                  </MenuItem>

                </Menu>
              </div>
            </div>

            <div className={itemView === "grid" ? "" : listViewClassName}>
              {itemView === "grid" ? (
                <>

                  {
                    isLoading === true ? <ProductLoadingGrid view={itemView} />
                      :

                      productsData?.products?.length !== 0 && (
                        <div className="overflow-hidden rounded-[30px] border border-[var(--brand-border)] bg-white shadow-[0_18px_42px_rgba(15,23,42,0.05)]">
                          {productsData?.products?.map((item, index) => {
                            return (
                              <ProductItem
                                key={index}
                                item={item}
                                compact
                                separated
                                isLast={index === productsData?.products?.length - 1}
                              />
                            )
                          })}
                        </div>
                      )

                  }


                </>
              ) : (
                <>
                  {
                    isLoading === true ? <ProductLoadingGrid view={itemView} />
                      :

                      productsData?.products?.length !== 0 && productsData?.products?.map((item, index) => {
                        return (
                          <ProductItemListView key={index} item={item} />
                        )
                      })

                  }

                </>
              )}
            </div>

            {
              totalPages > 1 &&
              <div className="flex items-center justify-center mt-10">
                <Pagination
                  showFirstButton showLastButton
                  count={totalPages}
                  page={page}
                  onChange={(e, value) => setPage(value)}
                />
              </div>
            }


          </div>
        </div>
      </div>

      
    </section>
  );
};

export default ProductListing;
