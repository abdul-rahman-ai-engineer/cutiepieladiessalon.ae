import React, { useContext, useEffect, useState } from "react";
import HomeSlider from "../../components/HomeSlider";
import HomeCatSlider from "../../components/HomeCatSlider";
import AdsBannerSlider from "../../components/AdsBannerSlider";
import AdsBannerSliderV2 from "../../components/AdsBannerSliderV2";

import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";

import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/navigation";
import 'swiper/css/free-mode';

import { Navigation, FreeMode } from "swiper/modules";
import BlogItem from "../../components/BlogItem";
import HomeBannerV2 from "../../components/HomeSliderV2";
import BannerBoxV2 from "../../components/bannerBoxV2";
import { fetchDataFromApi } from "../../utils/api";
import { MyContext } from "../../App";
import ProductLoading from "../../components/ProductLoading";
import BannerLoading from "../../components/LoadingSkeleton/bannerLoading";
import { Button } from "@mui/material";
import ProductItem from "../../components/ProductItem";
import {
  MdArrowRightAlt,
  MdLocationOn,
  MdOutlineSpa,
  MdPhoneInTalk,
} from "react-icons/md";
import { Link } from "react-router-dom";

const Home = () => {
  const PRODUCT_SECTION_LIMIT = 12;
  const RANDOM_SECTION_COUNT = 2;
  const [value, setValue] = useState(0);
  const [homeSlidesData, setHomeSlidesData] = useState([]);
  const [popularProductsData, setPopularProductsData] = useState([]);
  const [productsData, setAllProductsData] = useState([]);
  const [productsBanners, setProductsBanners] = useState([]);
  const [bannerV1Data, setBannerV1Data] = useState([]);
  const [bannerList2Data, setBannerList2Data] = useState([]);
  const [blogData, setBlogData] = useState([]);
  const [randomCatProducts, setRandomCatProducts] = useState([]);
  const [isHomeSlidesLoading, setIsHomeSlidesLoading] = useState(true);
  const [isPopularProductsLoading, setIsPopularProductsLoading] = useState(true);
  const [isLatestProductsLoading, setIsLatestProductsLoading] = useState(true);


  const context = useContext(MyContext);
  const productGridClassName = "grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4";


  useEffect(() => {
    window.scrollTo(0, 0);
    let isMounted = true;

    Promise.allSettled([
      fetchDataFromApi("/api/homeSlides"),
      fetchDataFromApi(`/api/product/getAllProducts?page=1&limit=${PRODUCT_SECTION_LIMIT}&includeTotal=false`),
      fetchDataFromApi("/api/product/getAllProductsBanners?limit=6"),
      fetchDataFromApi("/api/bannerV1"),
      fetchDataFromApi("/api/bannerList2"),
      fetchDataFromApi("/api/blog"),
    ]).then((results) => {
      if (!isMounted) return;

      const [slidesRes, latestRes, bannerProductsRes, bannerV1Res, bannerList2Res, blogRes] = results.map((result) =>
        result.status === "fulfilled" ? result.value : null
      );

      setHomeSlidesData(Array.isArray(slidesRes?.data) ? slidesRes.data : []);
      setAllProductsData(Array.isArray(latestRes?.products) ? latestRes.products : []);
      setProductsBanners(Array.isArray(bannerProductsRes?.products) ? bannerProductsRes.products : []);
      setBannerV1Data(Array.isArray(bannerV1Res?.data) ? bannerV1Res.data : []);
      setBannerList2Data(Array.isArray(bannerList2Res?.data) ? bannerList2Res.data : []);
      setBlogData(Array.isArray(blogRes?.blogs) ? blogRes.blogs : []);
    }).finally(() => {
      if (!isMounted) return;
      setIsHomeSlidesLoading(false);
      setIsLatestProductsLoading(false);
    });

    return () => {
      isMounted = false;
    };
  }, [])



  useEffect(() => {
    let isMounted = true;

    if (context?.catData?.length !== 0) {
      setIsPopularProductsLoading(true);

      fetchDataFromApi(`/api/product/getAllProductsByCatId/${context?.catData[0]?._id}?page=1&perPage=${PRODUCT_SECTION_LIMIT}&includeTotal=false`)
        .then((res) => {
          if (!isMounted) return;
          if (res?.error === false) {
            setPopularProductsData(Array.isArray(res?.products) ? res.products : [])
            return;
          }

          setPopularProductsData([]);
        })
        .finally(() => {
          if (!isMounted) return;
          setIsPopularProductsLoading(false);
        })
    } else {
      setPopularProductsData([]);
      setIsPopularProductsLoading(false);
    }

    const randomIndexes = context?.catData
      ?.map((_, index) => index)
      ?.filter((index) => index !== 0)
      ?.slice(0, RANDOM_SECTION_COUNT);

    const idleLoad = window.setTimeout(() => {
      getRendomProducts(randomIndexes, context?.catData, isMounted)
    }, 150);

    return () => {
      isMounted = false;
      window.clearTimeout(idleLoad);
    };

  }, [context?.catData])



  const getRendomProducts = async (arr, catArr, isMounted = true) => {
    if (!Array.isArray(arr) || !arr.length) {
      setRandomCatProducts([]);
      return;
    }

    const sections = await Promise.all(
      arr.map(async (index) => {
        const category = catArr[index];
        if (!category?._id) return null;

        const res = await fetchDataFromApi(
          `/api/product/getAllProductsByCatId/${category._id}?page=1&perPage=${PRODUCT_SECTION_LIMIT}&includeTotal=false`
        );

        return {
          catName: category?.name,
          data: Array.isArray(res?.products) ? res.products : []
        };
      })
    );

    if (!isMounted) return;
    setRandomCatProducts(sections.filter((section) => section?.data?.length));
  }

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const filterByCatId = (id) => {
    setPopularProductsData([])
    setIsPopularProductsLoading(true);
    fetchDataFromApi(`/api/product/getAllProductsByCatId/${id}?page=1&perPage=${PRODUCT_SECTION_LIMIT}&includeTotal=false`).then((res) => {
      if (res?.error === false) {
        setPopularProductsData(Array.isArray(res?.products) ? res.products : [])
      } else {
        setPopularProductsData([]);
      }

    }).finally(() => {
      setIsPopularProductsLoading(false);
    })
  }

  const renderProductSection = (data, isLoading, emptyMessage) => {
    if (isLoading) return <ProductLoading />;
    if (!data?.length) {
      return (
        <div className="rounded-md border border-dashed border-gray-300 px-4 py-10 text-center text-sm text-gray-500">
          {emptyMessage}
        </div>
      );
    }

    return (
      <div className={productGridClassName}>
        {data.map((item, index) => (
          <ProductItem key={item?._id || index} item={item} />
        ))}
      </div>
    );
  }


  return (
    <>

      {isHomeSlidesLoading && <BannerLoading />}

      {!isHomeSlidesLoading && homeSlidesData?.length !== 0 && <HomeSlider data={homeSlidesData} />}

      {
        context?.catData?.length !== 0 && <HomeCatSlider data={context?.catData} />
      }


      <section className="py-0 lg:py-4 pt-0 lg:pt-8 pb-0 bg-white">
        <div className="container">
          <div className="mb-7 overflow-hidden rounded-[28px] border border-[rgba(255,82,82,0.18)] bg-[radial-gradient(circle_at_top_right,_rgba(255,212,222,0.85),_rgba(255,212,222,0)_32%),linear-gradient(135deg,_#fff8f6_0%,_#ffffff_55%,_#fff3f6_100%)] px-5 py-5 shadow-[0_18px_42px_rgba(151,99,99,0.12)] sm:px-6 lg:px-8">
            <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
              <div className="flex items-start gap-4">
                <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-[20px] bg-white text-[#ff6b81] shadow-[0_10px_24px_rgba(255,107,129,0.18)] lg:h-16 lg:w-16">
                  <MdOutlineSpa className="text-[30px] lg:text-[34px]" />
                </div>

                <div className="min-w-0">
                  <span className="inline-flex rounded-full border border-[rgba(255,82,82,0.16)] bg-white/90 px-3 py-1 text-[11px] font-[700] uppercase tracking-[0.2em] text-[#b46a74]">
                    Salon At Home
                  </span>
                  <h2 className="mt-3 text-[22px] font-[700] leading-[1.1] text-[#2b2323] lg:text-[30px]">
                    Beauty Salon in Dubai
                  </h2>
                  <p className="mt-2 max-w-[620px] text-[13px] leading-[1.8] text-[rgba(43,35,35,0.75)] lg:text-[15px]">
                    Home services at your doorstep with convenient booking,
                    trusted professionals, and support across Dubai, UAE.
                  </p>
                </div>
              </div>

              <div className="flex flex-col gap-3 sm:flex-row lg:shrink-0">
                <a
                  href="tel:+971529775859"
                  className="inline-flex items-center justify-center gap-2 rounded-full bg-[#ff5f74] px-4 py-3 text-[13px] font-[700] text-white shadow-[0_12px_24px_rgba(255,95,116,0.28)] transition hover:bg-[#f04f67] lg:text-[14px]"
                >
                  <MdPhoneInTalk className="text-[18px]" />
                  +971 52 977 5859
                </a>

                <div className="inline-flex items-center justify-center gap-2 rounded-full border border-[rgba(43,35,35,0.1)] bg-white/90 px-4 py-3 text-[13px] font-[600] text-[rgba(43,35,35,0.82)] lg:text-[14px]">
                  <MdLocationOn className="text-[18px] text-[#ff6b81]" />
                  Dubai, UAE
                </div>
              </div>
            </div>
          </div>

          {
            bannerV1Data?.length !== 0 && <AdsBannerSliderV2 items={4} data={bannerV1Data} />
          }


        </div>
      </section>


      {
        bannerList2Data?.length !== 0 &&
        <section className="py-2 lg:py-0 pt-0 bg-white">
          <div className="container">
            <AdsBannerSlider items={4} data={bannerList2Data} />
          </div>
        </section>
      }


      


      {
        blogData?.length !== 0 &&
        <section className="py-5 pb-8 pt-0 bg-white blogSection">
          <div className="container">
            <h2 className="text-[20px] font-[600] mb-4">From The Blog</h2>
            <Swiper
              slidesPerView={4}
              spaceBetween={30}
              navigation={context?.windowWidth < 992 ? false : true}
              modules={[Navigation, FreeMode]}
              freeMode={true}
              breakpoints={{
                250: {
                  slidesPerView: 1,
                  spaceBetween: 10,
                },
                330: {
                  slidesPerView: 1,
                  spaceBetween: 10,
                },
                500: {
                  slidesPerView: 2,
                  spaceBetween: 20,
                },
                700: {
                  slidesPerView: 3,
                  spaceBetween: 20,
                },
                1100: {
                  slidesPerView: 4,
                  spaceBetween: 30,
                },
              }}
              className="blogSlider"
            >
              {
                blogData?.slice()?.reverse()?.map((item, index) => {
                  return (
                    <SwiperSlide key={index}>
                      <BlogItem item={item} />
                    </SwiperSlide>
                  )
                })
              }



            </Swiper>
          </div>
        </section>
      }


    </>
  );
};

export default Home;
