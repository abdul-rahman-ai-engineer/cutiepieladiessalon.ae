import React, { useContext, useEffect, useState } from 'react';
import Button from "@mui/material/Button";
import { Link, useLocation, useSearchParams } from "react-router-dom";
import { MyContext } from '../../App';
import CircularProgress from '@mui/material/CircularProgress';
import { deleteData, postData } from '../../utils/api';
import { TAMARA_CHECKOUT_STORAGE_KEY } from "../../utils/tamara";

export const OrderSuccess = () => {
    const context = useContext(MyContext);
    const [isFinalizingTamara, setIsFinalizingTamara] = useState(false);
    const location = useLocation();
    const [searchParams] = useSearchParams();
    const mode = searchParams.get("mode");
    const isBookingSuccess = location.pathname.startsWith("/booking/") || mode === "booking";

    useEffect(() => {
        const finalizeTamaraCheckout = async () => {
            const savedSession = localStorage.getItem(TAMARA_CHECKOUT_STORAGE_KEY);

            if (!savedSession) return;

            try {
                const tamaraSession = JSON.parse(savedSession);

                const tamaraOrderId = tamaraSession?.tamaraOrderId || tamaraSession?.orderId;

                if (!tamaraOrderId) {
                    localStorage.removeItem(TAMARA_CHECKOUT_STORAGE_KEY);
                    return;
                }

                if (tamaraSession?.mode === "booking" && !tamaraSession?.bookingId) {
                    localStorage.removeItem(TAMARA_CHECKOUT_STORAGE_KEY);
                    return;
                }

                setIsFinalizingTamara(true);

                const isBookingTamaraSession = tamaraSession?.mode === "booking";
                const response = await postData(
                    isBookingTamaraSession ? "/api/bookings/tamara/finalize" : "/api/order/finalize-tamara",
                    isBookingTamaraSession
                        ? {
                            bookingId: tamaraSession.bookingId,
                            tamaraOrderId,
                        }
                        : {
                            tamaraOrderId,
                            delivery_address: tamaraSession.delivery_address,
                            products: tamaraSession.products,
                            totalAmt: tamaraSession.totalAmt,
                        }
                );

                if (response?.error === false) {
                    if (!isBookingTamaraSession) {
                        await deleteData(`/api/cart/emptyCart/${context?.userData?._id}`);
                        context?.getCartItems();
                    }
                    localStorage.removeItem(TAMARA_CHECKOUT_STORAGE_KEY);
                } else {
                    context?.alertBox(
                        "error",
                        response?.message ||
                            (isBookingTamaraSession
                                ? "Tamara payment was approved, but the booking could not be finalized yet."
                                : "Tamara payment was approved, but the order could not be finalized yet.")
                    );
                }
            } catch (error) {
                context?.alertBox("error", "Unable to finalize Tamara checkout.");
            } finally {
                setIsFinalizingTamara(false);
            }
        };

        finalizeTamaraCheckout();
    }, [context]);

    return (
        <section className='w-full p-10 py-8 lg:py-20 flex items-center justify-center flex-col gap-2'>
            <img src="/checked.png" className="w-[80px] sm:w-[120px]" />
            <h3 className='mb-0 text-[20px] sm:text-[25px]'>
                {isBookingSuccess ? "Your booking is confirmed" : "Your order is placed"}
            </h3>
            <p className='mt-0 mb-0'>
                {isBookingSuccess ? "Your salon professional has been reserved." : "Thank you for your payment."}
            </p>
            {
                isFinalizingTamara &&
                <div className='flex items-center gap-2 text-[14px] text-[rgba(0,0,0,0.7)]'>
                    <CircularProgress size={18} />
                    {isBookingSuccess ? "Finalizing your Tamara booking..." : "Finalizing your Tamara order..."}
                </div>
            }
            <p className='mt-0 text-center'>
                {isBookingSuccess ? "Booking confirmation sent to" : "Order invoice sent to"}{" "}
                <b>{context?.userData?.email}</b>
            </p>
            <Link to="/">
                <Button className="btn-org btn-border">Back to home</Button>
            </Link>
        </section>
    )
}
