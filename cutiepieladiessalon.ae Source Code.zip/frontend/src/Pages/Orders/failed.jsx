import React, { useEffect } from 'react';
import Button from "@mui/material/Button";
import { Link, useLocation, useSearchParams } from "react-router-dom";
import { TAMARA_CHECKOUT_STORAGE_KEY } from "../../utils/tamara";

export const OrderFailed = () => {
    const location = useLocation();
    const [searchParams] = useSearchParams();
    const isBookingFailure = location.pathname.startsWith("/booking/") || searchParams.get("mode") === "booking";

    useEffect(() => {
        localStorage.removeItem(TAMARA_CHECKOUT_STORAGE_KEY);
    }, []);

    return (
        <section className='w-full p-10 py-8 lg:py-20 flex items-center justify-center flex-col gap-2'>
            <img src="/delete.png"  className="w-[70px] sm:w-[120px]"  />
            <h3 className='mb-0 text-[20px] sm:text-[25px]'>
                {isBookingFailure ? "Your booking was not completed" : "Your order could not be completed"}
            </h3>
            <p className='mt-0 text-center'>
                {isBookingFailure
                    ? "The payment was cancelled or failed. You can return to the service page and try again."
                    : "The payment was cancelled or failed. Please try again."}
            </p>
            <Link to="/">
                <Button className="btn-org btn-border">Back to home</Button>
            </Link>
        </section>
    )
}
