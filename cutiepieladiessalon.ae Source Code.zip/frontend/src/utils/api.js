import axios from "axios";
import { getStoredAccessToken } from "./authSession";
const LIVE_API_URL = 'https://backend.cutiepieladiessalon.ae/api';
const rawApiUrl = (import.meta.env.VITE_API_BASE_URL || import.meta.env.VITE_API_URL)?.trim();
const localHosts = new Set(['localhost', '127.0.0.1']);

const isLocalhostApiUrl = (value) => {
    if (!value) return false;
    try {
        const parsed = new URL(value);
        return localHosts.has(parsed.hostname);
    } catch {
        return /localhost|127\.0\.0\.1/i.test(value);
    }
};

export const getApiBaseUrl = () => {
    if (rawApiUrl) {
        if (
            typeof window !== 'undefined' &&
            !localHosts.has(window.location.hostname) &&
            isLocalhostApiUrl(rawApiUrl)
        ) {
            return LIVE_API_URL;
        }
        return rawApiUrl.replace(/\/+$/, '');
    }

    if (typeof window !== 'undefined' && import.meta.env.DEV) {
        const isLocalHost = ['localhost', '127.0.0.1'].includes(window.location.hostname);
        if (isLocalHost) {
            return 'http://localhost:3000/api';
        }
    }

    return LIVE_API_URL;
};

export const buildApiUrl = (url) => {
    const baseUrl = getApiBaseUrl();
    const normalizedPath = url.startsWith('/') ? url : `/${url}`;

    if (!baseUrl) return normalizedPath;

    const baseHasApiSuffix = /\/api$/i.test(baseUrl);
    const pathHasApiPrefix = /^\/api(\/|$)/i.test(normalizedPath);

    if (baseHasApiSuffix && pathHasApiPrefix) {
        return `${baseUrl}${normalizedPath.replace(/^\/api/i, '')}`;
    }

    if (!baseHasApiSuffix && !pathHasApiPrefix) {
        return `${baseUrl}/api${normalizedPath}`;
    }

    return `${baseUrl}${normalizedPath}`;
};

const createAuthHeaders = (contentType = "application/json", extraHeaders = {}, includeAuth = true) => {
    const token = getStoredAccessToken();
    const headers = {
        ...(contentType ? { "Content-Type": contentType } : {}),
        ...extraHeaders,
    };

    if (includeAuth && token) {
        headers.Authorization = `Bearer ${token}`;
    }

    return headers;
};

const createAxiosConfig = (contentType = "application/json", options = {}) => ({
    timeout: 15000,
    withCredentials: true,
    ...options,
    headers: createAuthHeaders(
        contentType,
        options?.headers || {},
        options?.includeAuth !== false
    ),
});

const parseJsonResponse = async (response) => {
    const text = await response.text();

    if (!text) {
        return {};
    }

    try {
        return JSON.parse(text);
    } catch {
        return {
            success: false,
            error: true,
            message: `Invalid JSON response received from ${response.url || "the API"}.`,
        };
    }
};

export const postData = async (url, formData, options = {}) => {
    try {
        const response = await fetch(buildApiUrl(url), {
            method: "POST",
            credentials: "include",
            headers: createAuthHeaders(
                options?.contentType || "application/json",
                options?.headers || {},
                options?.includeAuth !== false
            ),
            body:
                options?.contentType && options.contentType !== "application/json"
                    ? formData
                    : JSON.stringify(formData),
        });

        return parseJsonResponse(response);
    } catch (error) {
        console.error("Error:", error);
        return {
            success: false,
            error: true,
            message: error?.message || "Network or server error",
        };
    }
};

export const fetchDataFromApi = async (url, options = {}) => {
    try {
        const { data } = await axios.get(
            buildApiUrl(url),
            createAxiosConfig("application/json", options)
        );
        return data;
    } catch (error) {
        console.log(error);
        return error?.response?.data || {
            success: false,
            error: true,
            message: error?.message || "Network or server error",
        };
    }
};


export const uploadImage = async (url, updatedData, options = {}) => {
    var response;
    await axios.put(
        buildApiUrl(url),
        updatedData,
        createAxiosConfig("multipart/form-data", options)
    ).then((res) => {
        response = res;
    });
    return response;
};




export const editData = async (url, updatedData, options = {}) => {
    var response;
    await axios.put(
        buildApiUrl(url),
        updatedData,
        createAxiosConfig("application/json", options)
    ).then((res) => {
        response = res;
    });
    return response;
};


export const deleteData = async (url, options = {}) => {
    const { data } = await axios.delete(
        buildApiUrl(url),
        createAxiosConfig("application/json", options)
    );
    return data;
};
