export const TAMARA_CHECKOUT_STORAGE_KEY = "tamaraCheckoutSession";

export const getTamaraInstallmentAmount = (amount, installments = 4) => {
  const safeAmount = Number(amount || 0);
  const safeInstallments = Math.max(1, Number(installments) || 1);

  return safeAmount / safeInstallments;
};

export const openTamaraCheckoutWindow = () => {
  if (typeof window === "undefined") return null;

  const tamaraWindow = window.open("", "_blank");

  if (tamaraWindow) {
    tamaraWindow.document.open();
    tamaraWindow.document.write(`
      <!doctype html>
      <html lang="en">
        <head>
          <meta charset="utf-8" />
          <title>Opening Tamara...</title>
        </head>
        <body style="margin:0;display:flex;min-height:100vh;align-items:center;justify-content:center;font-family:Arial,sans-serif;background:#f8fafc;color:#0f172a;">
          <div style="text-align:center;padding:24px;">
            <div style="font-size:20px;font-weight:700;">Opening Tamara...</div>
            <div style="margin-top:10px;font-size:14px;color:#64748b;">Please wait while we connect you to checkout.</div>
          </div>
        </body>
      </html>
    `);
    tamaraWindow.document.close();
  }

  return tamaraWindow;
};

export const redirectTamaraCheckoutWindow = (tamaraWindow, checkoutUrl) => {
  if (!checkoutUrl || typeof window === "undefined") return false;

  if (tamaraWindow && !tamaraWindow.closed) {
    tamaraWindow.location.href = checkoutUrl;
    tamaraWindow.focus?.();
    return true;
  }

  const fallbackWindow = window.open(checkoutUrl, "_blank");

  if (fallbackWindow) {
    fallbackWindow.focus?.();
    return true;
  }

  window.location.href = checkoutUrl;
  return false;
};

export const closeTamaraCheckoutWindow = (tamaraWindow) => {
  if (tamaraWindow && !tamaraWindow.closed) {
    tamaraWindow.close();
  }
};
