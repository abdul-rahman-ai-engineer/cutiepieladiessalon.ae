const SERVICE_CATEGORY_TOKENS = new Set([
  "nails",
  "facial",
  "hair",
  "hairremoval",
  "massage",
  "combos",
  "combo",
]);

const normalizeCategoryToken = (value = "") =>
  String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z]/g, "");

export const isServiceCatalogItem = (item = {}) => {
  const normalizedType = String(item?.serviceType || "").trim().toLowerCase();

  if (normalizedType === "service") return true;
  if (normalizedType === "product") return false;

  return [item?.catName, item?.subCat, item?.thirdsubCat]
    .filter(Boolean)
    .some((value) => SERVICE_CATEGORY_TOKENS.has(normalizeCategoryToken(value)));
};

export const isServiceCartItem = (item = {}) => {
  return String(item?.serviceType || "").trim().toLowerCase() === "service";
};
