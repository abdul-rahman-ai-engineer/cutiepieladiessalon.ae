const compact = (values = []) =>
  values
    .map((value) => String(value ?? "").trim())
    .filter(Boolean);

export const normalizePhoneDisplay = (value) =>
  String(value ?? "")
    .replace(/[^\d]/g, "")
    .trim();

export const getLatestAddress = (addresses = []) => {
  const normalizedAddresses = Array.isArray(addresses) ? addresses.filter(Boolean) : [];
  return normalizedAddresses.length ? normalizedAddresses[normalizedAddresses.length - 1] : null;
};

export const getAddressTitle = (address = {}) =>
  compact([address?.address_line1])[0] || "Dubai";

export const formatAddressMeta = (address = {}) => {
  const city = compact([address?.city])[0] || "Dubai";
  const state = compact([address?.state])[0];
  const country = compact([address?.country])[0] || "United Arab Emirates";
  const parts = compact([
    city,
    state && state.toLowerCase() !== city.toLowerCase() ? state : "",
    country,
  ]);

  return Array.from(new Set(parts)).join(", ");
};

export const formatAddressExtras = (address = {}) => {
  const phone = normalizePhoneDisplay(address?.mobile);
  return compact([address?.landmark, phone ? `+${phone}` : ""]).join(" • ");
};

export const getAddressLocationLabel = (address = {}) => {
  const title = compact([address?.address_line1])[0];

  if (title) {
    return title;
  }

  return formatAddressMeta(address) || "Dubai, United Arab Emirates";
};
