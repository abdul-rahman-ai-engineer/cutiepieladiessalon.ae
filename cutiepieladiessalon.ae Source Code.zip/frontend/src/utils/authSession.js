const ACCESS_TOKEN_KEY = "accessToken";
const REFRESH_TOKEN_KEY = "refreshToken";
const USER_ROLE_KEY = "userRole";
const USER_IS_ADMIN_KEY = "userIsAdmin";

const localHosts = new Set(["localhost", "127.0.0.1"]);

const getStorage = () => {
    if (typeof window === "undefined") {
        return null;
    }

    return window.localStorage;
};

export const normalizeUserRole = (role = "") => {
    const normalizedRole = String(role || "").trim().toUpperCase();

    return normalizedRole === "ADMIN" ? "ADMIN" : "USER";
};

export const isAdminUser = (user = {}) => {
    if (user?.isAdmin === true) {
        return true;
    }

    return normalizeUserRole(user?.role) === "ADMIN";
};

export const getStoredAccessToken = () => {
    return getStorage()?.getItem(ACCESS_TOKEN_KEY) || "";
};

export const getStoredRefreshToken = () => {
    return getStorage()?.getItem(REFRESH_TOKEN_KEY) || "";
};

export const setUserSession = (tokens = {}) => {
    const storage = getStorage();

    if (!storage) {
        return;
    }

    const accessToken = tokens?.accesstoken || tokens?.accessToken || "";
    const refreshToken = tokens?.refreshToken || "";
    const role = normalizeUserRole(tokens?.role);
    const isAdmin = isAdminUser(tokens);

    if (accessToken) {
        storage.setItem(ACCESS_TOKEN_KEY, accessToken);
    } else {
        storage.removeItem(ACCESS_TOKEN_KEY);
    }

    if (refreshToken) {
        storage.setItem(REFRESH_TOKEN_KEY, refreshToken);
    } else {
        storage.removeItem(REFRESH_TOKEN_KEY);
    }

    storage.setItem(USER_ROLE_KEY, role);
    storage.setItem(USER_IS_ADMIN_KEY, String(isAdmin));
};

export const clearUserSession = () => {
    const storage = getStorage();

    if (!storage) {
        return;
    }

    storage.removeItem(ACCESS_TOKEN_KEY);
    storage.removeItem(REFRESH_TOKEN_KEY);
    storage.removeItem(USER_ROLE_KEY);
    storage.removeItem(USER_IS_ADMIN_KEY);
};

export const getAdminAppUrl = () => {
    const configuredUrl = (import.meta.env.VITE_ADMIN_APP_URL || "").trim();

    if (configuredUrl) {
        return configuredUrl.replace(/\/+$/, "");
    }

    if (typeof window === "undefined") {
        return "/admin";
    }

    if (localHosts.has(window.location.hostname)) {
        return "http://localhost:5174";
    }

    return "https://server.cutiepieladiessalon.ae";
};
