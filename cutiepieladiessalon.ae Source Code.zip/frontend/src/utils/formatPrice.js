import { CURRENCY } from "./currency";

/**
 * Formats a numeric value as currency using the central configuration.
 * @param {number|string} value - The numeric value to format
 * @param {Object} options - Optional overrides
 * @param {boolean} options.omitDecimals - If true, omits decimal places for whole numbers
 * @returns {string} Formatted price string (e.g., "AED 1,108.00")
 */
export const formatPrice = (value, options = {}) => {
  if (value === undefined || value === null || value === "") return "";
  const num = Number(value);
  if (isNaN(num)) return "";

  const { omitDecimals = false } = options;

  const fractionDigits = omitDecimals && Number.isInteger(num)
    ? { minimumFractionDigits: 0, maximumFractionDigits: 0 }
    : {
        minimumFractionDigits: CURRENCY.minFractionDigits,
        maximumFractionDigits: CURRENCY.maxFractionDigits,
      };

  const formatted = num.toLocaleString(CURRENCY.locale, fractionDigits);
  return `${CURRENCY.symbol} ${formatted}`;
};
