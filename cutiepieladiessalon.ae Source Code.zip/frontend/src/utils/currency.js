/**
 * Central currency configuration for the application.
 * Change the values here to update currency display across the entire website.
 */
export const CURRENCY = {
  /** Currency code (e.g., 'AED', 'USD') */
  code: "AED",
  /** Display symbol/label used in UI (e.g., 'AED', '$') */
  symbol: "AED",
  /** Locale for number formatting (e.g., 'en-AE', 'en-US') */
  locale: "en-AE",
  /** Minimum fraction digits (e.g., 0 for whole numbers, 2 for decimals) */
  minFractionDigits: 2,
  /** Maximum fraction digits */
  maxFractionDigits: 2,
};
