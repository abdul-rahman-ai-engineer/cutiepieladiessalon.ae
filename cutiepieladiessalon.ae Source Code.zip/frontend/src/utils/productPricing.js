export const isTilesProduct = (product) => {
  const haystacks = [
    product?.catName,
    product?.subCat,
    product?.thirdsubCat,
    product?.name,
  ]
    .filter(Boolean)
    .map((item) => String(item).toLowerCase());

  return haystacks.some((text) => text.includes("tile"));
};

export const getPriceSuffix = (product) => (isTilesProduct(product) ? "/sqm" : "");

export const getDiscountPercent = (product) => {
  const explicit = Number(product?.discount);
  if (!Number.isNaN(explicit) && explicit > 0) return Math.round(explicit);

  const oldPrice = Number(product?.oldPrice);
  const price = Number(product?.price);
  if (!oldPrice || oldPrice <= 0 || Number.isNaN(oldPrice) || Number.isNaN(price)) return 0;

  const discount = ((oldPrice - price) / oldPrice) * 100;
  return Math.max(0, Math.round(discount));
};

export const getSavingsAmount = (product) => {
  const oldPrice = Number(product?.oldPrice);
  const price = Number(product?.price);

  if (!oldPrice || oldPrice <= 0 || Number.isNaN(oldPrice) || Number.isNaN(price)) return 0;

  return Math.max(0, oldPrice - price);
};
