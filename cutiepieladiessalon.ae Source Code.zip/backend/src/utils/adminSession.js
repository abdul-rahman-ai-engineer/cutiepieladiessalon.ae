const ADMIN_ACCESS_TOKEN_KEY = "adminAccessToken";
const ADMIN_REFRESH_TOKEN_KEY = "adminRefreshToken";
const ADMIN_ROLE_KEY = "adminRole";
const ADMIN_IS_ADMIN_KEY = "adminIsAdmin";

const getStorage = () => {
    if (typeof window === "undefined") {
        return null;
    }

    return window.localStorage;
};

export const getAdminAccessToken = () => {
    return getStorage()?.getItem(ADMIN_ACCESS_TOKEN_KEY) || "";
};

export const getAdminRefreshToken = () => {
    return getStorage()?.getItem(ADMIN_REFRESH_TOKEN_KEY) || "";
};

export const getStoredAdminRole = () => {
    return getStorage()?.getItem(ADMIN_ROLE_KEY) || "";
};

export const getStoredAdminFlag = () => {
    return getStorage()?.getItem(ADMIN_IS_ADMIN_KEY) === "true";
};

export const setAdminSession = (tokens = {}) => {
    const storage = getStorage();

    if (!storage) {
        return;
    }

    const accessToken = tokens?.accesstoken || tokens?.accessToken || "";
    const refreshToken = tokens?.refreshToken || "";
    const isAdmin = tokens?.isAdmin === true || String(tokens?.role || "").trim().toUpperCase() === "ADMIN";
    const normalizedRole = isAdmin ? "ADMIN" : String(tokens?.role || "").trim().toUpperCase();

    if (accessToken) {
        storage.setItem(ADMIN_ACCESS_TOKEN_KEY, accessToken);
    } else {
        storage.removeItem(ADMIN_ACCESS_TOKEN_KEY);
    }

    if (refreshToken) {
        storage.setItem(ADMIN_REFRESH_TOKEN_KEY, refreshToken);
    } else {
        storage.removeItem(ADMIN_REFRESH_TOKEN_KEY);
    }

    if (normalizedRole) {
        storage.setItem(ADMIN_ROLE_KEY, normalizedRole);
        storage.setItem(ADMIN_IS_ADMIN_KEY, String(isAdmin));
    } else if (tokens?.isAdmin !== undefined) {
        storage.setItem(ADMIN_ROLE_KEY, isAdmin ? "ADMIN" : "USER");
        storage.setItem(ADMIN_IS_ADMIN_KEY, String(isAdmin));
    }
};

export const clearAdminSession = () => {
    const storage = getStorage();

    if (!storage) {
        return;
    }

    storage.removeItem(ADMIN_ACCESS_TOKEN_KEY);
    storage.removeItem(ADMIN_REFRESH_TOKEN_KEY);
    storage.removeItem(ADMIN_ROLE_KEY);
    storage.removeItem(ADMIN_IS_ADMIN_KEY);
};
