import axios from "axios";
import { getAdminAccessToken } from "./adminSession";
const LIVE_API_URL = 'https://backend.cutiepieladiessalon.ae/api';
const rawApiUrl = (import.meta.env.VITE_API_BASE_URL || import.meta.env.VITE_API_URL)?.trim();
const localHosts = new Set(['localhost', '127.0.0.1']);

const isLocalhostApiUrl = (value) => {
    if (!value) return false;
    try {
        const parsed = new URL(value);
        return localHosts.has(parsed.hostname);
    } catch {
        return /localhost|127\.0\.0\.1/i.test(value);
    }
};

export const getApiBaseUrl = () => {
    if (rawApiUrl) {
        if (
            typeof window !== 'undefined' &&
            !localHosts.has(window.location.hostname) &&
            isLocalhostApiUrl(rawApiUrl)
        ) {
            return LIVE_API_URL;
        }
        return rawApiUrl.replace(/\/+$/, '');
    }

    if (typeof window !== 'undefined' && import.meta.env.DEV) {
        const isLocalHost = ['localhost', '127.0.0.1'].includes(window.location.hostname);
        if (isLocalHost) {
            return 'http://localhost:3000/api';
        }
    }

    return LIVE_API_URL;
};

export const buildApiUrl = (url) => {
    const baseUrl = getApiBaseUrl();
    const normalizedPath = url.startsWith('/') ? url : `/${url}`;

    if (!baseUrl) return normalizedPath;

    const baseHasApiSuffix = /\/api$/i.test(baseUrl);
    const pathHasApiPrefix = /^\/api(\/|$)/i.test(normalizedPath);

    if (baseHasApiSuffix && pathHasApiPrefix) {
        return `${baseUrl}${normalizedPath.replace(/^\/api/i, '')}`;
    }

    if (!baseHasApiSuffix && !pathHasApiPrefix) {
        return `${baseUrl}/api${normalizedPath}`;
    }

    return `${baseUrl}${normalizedPath}`;
};

const createAuthHeaders = (contentType = 'application/json') => ({
    ...(getAdminAccessToken() ? { 'Authorization': `Bearer ${getAdminAccessToken()}` } : {}),
    ...(contentType ? { 'Content-Type': contentType } : {}),
});

// postData

export const postData = async (url, formData) => {
    try {
        const response = await fetch(buildApiUrl(url), {
            method: 'POST',
            credentials: 'include',
            headers: createAuthHeaders(),
            body: JSON.stringify(formData)
        });

        const text = await response.text();
        let data;
        try {
            data = text ? JSON.parse(text) : {};
        } catch {
            const isHtml = /^\s*<\s*!?doctype|^\s*<\s*html/i.test(text);
            return {
                success: false,
                message: isHtml
                    ? `Server returned an HTML page instead of JSON (status ${response.status}). This usually means: (1) the request hit the wrong URL, or (2) the API rejected the request (e.g. payload too large). Ensure the API is running at ${String(getApiBaseUrl() || 'VITE_API_BASE_URL')}, restart it after changing server code, and that VITE_API_BASE_URL in .env points to it.`
                    : `Invalid JSON in response (status ${response.status}).`,
                error: true
            };
        }
        if (response.ok) return data;
        return data;
    } catch (error) {
        console.error('Error:', error);
        let msg = error?.message || 'Network or server error';
        if (/Unexpected token.*<!|is not valid JSON/i.test(msg)) {
            msg = `Server returned HTML instead of JSON. Ensure the API is running and that VITE_API_BASE_URL points to the correct domain or API base.`;
        }
        return { success: false, message: msg, error: true };
    }
}

// fetchDataFromApi

export const fetchDataFromApi = async (url) => {
    try {
        const params={
            timeout: 15000,
            withCredentials: true,
            headers: createAuthHeaders(),
        
        } 

        const { data } = await axios.get(buildApiUrl(url),params)
        return data;
    } catch (error) {
        console.log(error);
        return error?.response?.data || {
            success: false,
            error: true,
            message: error?.message || 'Network or server error',
        };
    }
}

// uploadImage

export const uploadImage = async (url, updatedData ) => {
    const params={
        withCredentials: true,
        headers: createAuthHeaders('multipart/form-data'),
    
    } 

    var response;
    await axios.put(buildApiUrl(url),updatedData, params).then((res)=>{
        response=res;
        
    })
    return response;
   
}

// uploadImages

export const uploadImages = async (url, formData ) => {
    const params={
        withCredentials: true,
        headers: createAuthHeaders('multipart/form-data'),
    
    } 

    var response;
    await axios.post(buildApiUrl(url),formData, params).then((res)=>{
        response=res;
        
    })
    return response;
   
}

export const postMultipartData = async (url, formData) => {
    try {
        const { data } = await axios.post(buildApiUrl(url), formData, {
            withCredentials: true,
            headers: createAuthHeaders('multipart/form-data'),
        });

        return data;
    } catch (error) {
        return error?.response?.data || {
            success: false,
            error: true,
            message: error?.message || 'Network or server error',
        };
    }
}

// editData

export const editData = async (url, updatedData ) => {
    const params={
        withCredentials: true,
        headers: createAuthHeaders(),
    
    } 

    try {
        const response = await axios.put(buildApiUrl(url),updatedData, params)
        return response;
    } catch (error) {
        return error?.response || {
            data: {
                success: false,
                error: true,
                message: error?.message || 'Network or server error',
            },
        };
    }
   
}

// deleteImages

export const deleteImages = async (url ) => {
    const params={
        withCredentials: true,
        headers: createAuthHeaders(),
    
    } 
    const { data } = await axios.delete(buildApiUrl(url), params);
    return data;
}

// deleteData

export const deleteData = async (url ) => {
    const params={
        withCredentials: true,
        headers: createAuthHeaders(),
    
    } 
    const { data } = await axios.delete(buildApiUrl(url),params)
    return data;
}

// deleteMultipleData

export const deleteMultipleData = async (url, payload) => {
    const config = {
        withCredentials: true,
        headers: createAuthHeaders(),
        ...(payload && { data: payload.data || payload }),
    };
    const { data } = await axios.delete(buildApiUrl(url), config);
    return data;
}
