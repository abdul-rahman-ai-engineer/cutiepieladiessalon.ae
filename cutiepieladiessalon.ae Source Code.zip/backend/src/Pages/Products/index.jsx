import React, { useContext, useEffect, useState, useRef } from 'react';
import axios from 'axios';
import {
    Button,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Tooltip,
    FormControl,
    InputLabel,
    ListItemText,
    Chip,
    Box,
    Typography,
    FormControlLabel
} from "@mui/material";
import Menu from "@mui/material/Menu";
import Rating from '@mui/material/Rating';
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import Checkbox from "@mui/material/Checkbox";
import { Link } from "react-router-dom";
import Progress from "../../Components/ProgressBar";
import { AiOutlineEdit } from "react-icons/ai";
import { FaRegEye } from "react-icons/fa6";
import { GoTrash } from "react-icons/go";
import { FiDownload, FiUpload, FiFile } from "react-icons/fi";
import SearchBox from '../../Components/SearchBox';
import { MyContext } from '../../App';
import { buildApiUrl, fetchDataFromApi, deleteData, deleteMultipleData, postData } from '../../utils/api';
import { getAdminAccessToken } from '../../utils/adminSession';
import { LazyLoadImage } from "react-lazy-load-image-component";
import "react-lazy-load-image-component/src/effects/blur.css";
import CircularProgress from '@mui/material/CircularProgress';

import Lightbox from "yet-another-react-lightbox";
import "yet-another-react-lightbox/styles.css";


const label = { inputProps: { "aria-label": "Checkbox demo" } };

const columns = [
    { id: "product", label: "SERVICE", minWidth: 150 },
    { id: "category", label: "CATEGORY", minWidth: 100 },
    { id: "subcategory", label: "SUB CATEGORY", minWidth: 150 },
    { id: "thirdcategory", label: "THIRD LEVEL", minWidth: 120 },
    {
        id: "price",
        label: "PRICE",
        minWidth: 130,
    },
    {
        id: "sales",
        label: "SALES",
        minWidth: 100,
    },
    {
        id: "stock",
        label: "STOCK",
        minWidth: 100,
    },
    {
        id: "rating",
        label: "RATING",
        minWidth: 100,
    },
    {
        id: "action",
        label: "ACTION",
        minWidth: 120,
    },
];

export const Products = () => {
    const [productCat, setProductCat] = React.useState('');
    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(50);

    const [productData, setProductData] = useState([]);

    const [productSubCat, setProductSubCat] = React.useState('');
    const [productThirdLavelCat, setProductThirdLavelCat] = useState('');
    const [sortedIds, setSortedIds] = useState([]);
    const [isLoading, setIsloading] = useState(false);

    const [searchQuery, setSearchQuery] = useState("");
    const [debouncedSearchQuery, setDebouncedSearchQuery] = useState("");

    const [photos, setPhotos] = useState([]);
    const [open, setOpen] = useState(false);

    const [bulkAnchorEl, setBulkAnchorEl] = useState(null);
    const [importFile, setImportFile] = useState(null);
    const [importFileName, setImportFileName] = useState('');
    const [importLoading, setImportLoading] = useState(false);
    const [syncLoading, setSyncLoading] = useState(false);
    const fileInputRef = useRef(null);
    const [exportDialogOpen, setExportDialogOpen] = useState(false);
    const [importDialogOpen, setImportDialogOpen] = useState(false);
    const [updateExisting, setUpdateExisting] = useState(false);
    const [importError, setImportError] = useState(null);
    const previousQueryStateRef = useRef('');

    const exportColumnOptions = [
        { value: 'name', label: 'Name' },
        { value: 'description', label: 'Description' },
        { value: 'brand', label: 'Brand' },
        { value: 'price', label: 'Price' },
        { value: 'oldPrice', label: 'Old Price' },
        { value: 'catName', label: 'Category' },
        { value: 'subCat', label: 'Sub Category' },
        { value: 'thirdsubCat', label: 'Third Sub Category' },
        { value: 'countInStock', label: 'Stock' },
        { value: 'rating', label: 'Rating' },
        { value: 'discount', label: 'Discount' },
        { value: 'sale', label: 'Sale' },
        { value: 'images', label: 'Images' },
        { value: 'sku', label: 'SKU' },
        { value: 'product_id', label: 'Service ID' },
    ];
    const productTypeOptions = [
        { value: 'simple', label: 'Simple service' },
        { value: 'grouped', label: 'Grouped service' },
        { value: 'external', label: 'External/Affiliate service' },
        { value: 'variable', label: 'Variable service' },
        { value: 'variation', label: 'Service variations' },
    ];
    const [exportColumns, setExportColumns] = useState(exportColumnOptions.map((opt) => opt.value));
    const [exportTypes, setExportTypes] = useState(productTypeOptions.map((opt) => opt.value));

    const context = useContext(MyContext);

    useEffect(() => {
        const timeoutId = setTimeout(() => {
            setDebouncedSearchQuery(searchQuery.trim());
        }, 300);

        return () => clearTimeout(timeoutId);
    }, [searchQuery]);

    useEffect(() => {
        const queryState = JSON.stringify({
            productCat,
            productSubCat,
            productThirdLavelCat,
            debouncedSearchQuery,
            rowsPerPage,
        });

        if (previousQueryStateRef.current && previousQueryStateRef.current !== queryState && page !== 0) {
            previousQueryStateRef.current = queryState;
            setPage(0);
            return;
        }

        previousQueryStateRef.current = queryState;
        loadProducts();
    }, [context?.isOpenFullScreenPanel, page, rowsPerPage, productCat, productSubCat, productThirdLavelCat, debouncedSearchQuery])


    // Handler to toggle all checkboxes
    const handleSelectAll = (e) => {
        const isChecked = e.target.checked;

        // Update all items' checked status
        const updatedItems = productData?.products?.map((item) => ({
            ...item,
            checked: isChecked,
        }));
        setProductData({
            error: false,
            success: true,
            products: updatedItems,
            total: updatedItems?.length,
            page: parseInt(page),
            totalPages: Math.ceil(updatedItems?.length / rowsPerPage),
            totalCount: productData?.totalCount
        });

        // Update the sorted IDs state
        if (isChecked) {
            const ids = updatedItems.map((item) => item._id).sort((a, b) => a - b);
            setSortedIds(ids);
        } else {
            setSortedIds([]);
        }
    };


    // Handler to toggle individual checkboxes
    const handleCheckboxChange = (e, id, index) => {

        const updatedItems = productData?.products?.map((item) =>
            item._id === id ? { ...item, checked: !item.checked } : item
        );
        setProductData({
            error: false,
            success: true,
            products: updatedItems,
            total: updatedItems?.length,
            page: parseInt(page),
            totalPages: Math.ceil(updatedItems?.length / rowsPerPage),
            totalCount: productData?.totalCount
        });



        // Update the sorted IDs state
        const selectedIds = updatedItems
            .filter((item) => item.checked)
            .map((item) => item._id)
            .sort((a, b) => a - b);
        setSortedIds(selectedIds);
    };


    const applyProductResponse = (res, fallbackPage, limit) => {
        const products = Array.isArray(res?.products) ? res.products : [];
        const total = Number(res?.total ?? products.length);
        const currentPage = Number(res?.page ?? fallbackPage);
        const totalPages = Number((res?.totalPages ?? Math.ceil(total / limit)) || 1);
        const totalCount = Number(res?.totalCount ?? total);

        setProductData({
            error: res?.error === true,
            success: res?.error !== true,
            products,
            total,
            page: currentPage,
            totalPages,
            totalCount
        });
        setPhotos(products.map((product) => ({
            src: product?.images?.[0] || "/icon.svg"
        })));
    };

    const loadProducts = async () => {
        setIsloading(true);
        const currentPage = page + 1;
        const currentLimit = rowsPerPage;

        try {
            let res;

            if (debouncedSearchQuery) {
                res = await postData('/api/product/search/get', {
                    query: debouncedSearchQuery,
                    page: currentPage,
                    limit: currentLimit,
                    includeTotal: true
                });
            } else if (productThirdLavelCat) {
                res = await fetchDataFromApi(`/api/product/getAllProductsByThirdLavelCat/${productThirdLavelCat}?page=${currentPage}&perPage=${currentLimit}&includeTotal=true`);
            } else if (productSubCat) {
                res = await fetchDataFromApi(`/api/product/getAllProductsBySubCatId/${productSubCat}?page=${currentPage}&perPage=${currentLimit}&includeTotal=true`);
            } else if (productCat) {
                res = await fetchDataFromApi(`/api/product/getAllProductsByCatId/${productCat}?page=${currentPage}&perPage=${currentLimit}&includeTotal=true`);
            } else {
                res = await fetchDataFromApi(`/api/product/getAllProducts?page=${currentPage}&limit=${currentLimit}&includeTotal=true`);
            }

            applyProductResponse(res, currentPage, currentLimit);
        } catch {
            setProductData({
                error: true,
                success: false,
                products: [],
                total: 0,
                page: currentPage,
                totalPages: 0,
                totalCount: 0
            });
            setPhotos([]);
        } finally {
            setIsloading(false);
        }
    }

    const handleChangeProductCat = (event) => {
        const value = event.target.value;
        setProductCat(value);
        setProductSubCat('');
        setProductThirdLavelCat('');
    };


    const handleChangeProductSubCat = (event) => {
        const value = event.target.value;
        setProductSubCat(value);
        setProductThirdLavelCat('');
    };

    const handleChangeProductThirdLavelCat = (event) => {
        const value = event.target.value;
        setProductThirdLavelCat(value);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(+event.target.value);
        setPage(0);
    };


    const deleteProduct = (id) => {
        if (context?.userData?.role === "ADMIN") {
            deleteData(`/api/product/${id}`).then((res) => {
                loadProducts();
                context.alertBox("success", "Service deleted");

            })
        } else {
            context.alertBox("error", "Only admin can delete data");
        }
    }


    const deleteMultipleProduct = () => {

        if (sortedIds.length === 0) {
            context.alertBox('error', 'Please select items to delete.');
            return;
        }


        try {
            deleteMultipleData(`/api/product/deleteMultiple`, {
                data: { ids: sortedIds },
            }).then((res) => {
                loadProducts();
                context.alertBox("success", "Service deleted");
                setSortedIds([]);

            })

        } catch (error) {
            context.alertBox('error', 'Error deleting items.');
        }


    }

    const getProductsToExport = () => {
        const list = productData?.products || [];
        const filteredBySelection = sortedIds?.length > 0
            ? list.filter((p) => sortedIds.includes(p._id))
            : list;
        if (!exportTypes.length) {
            return [];
        }
        return filteredBySelection.filter((product) => {
            const typeRaw = String(product?.type || product?.productType || product?.product_type || '').toLowerCase();
            if (!typeRaw) {
                return true;
            }
            return exportTypes.some((type) => typeRaw.includes(type));
        });
    };

    const escapeCsv = (v) => {
        const s = String(v == null ? '' : v);
        return '"' + s.replace(/"/g, '""') + '"';
    };

    const exportToCSV = () => {
        const products = getProductsToExport();
        if (!products.length) {
            context.alertBox('error', 'No products to export.');
            return;
        }
        const headers = exportColumns;
        if (!headers.length) {
            context.alertBox('error', 'Please select at least one column to export.');
            return;
        }
        const rows = products.map((p) =>
            headers.map((h) => escapeCsv(Array.isArray(p[h]) ? (p[h] || []).join(',') : p[h])).join(',')
        );
        const csv = [headers.join(','), ...rows].join('\r\n');
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'cutiepieladiessalon-products.csv';
        a.click();
        URL.revokeObjectURL(a.href);
        context.alertBox('success', `Exported ${products.length} product(s) to CSV.`);
        setExportDialogOpen(false);
        setBulkAnchorEl(null);
    };

    const exportToJSON = () => {
        const products = getProductsToExport();
        if (!products.length) {
            context.alertBox('error', 'No products to export.');
            return;
        }
        const json = JSON.stringify(products, null, 2);
        const blob = new Blob([json], { type: 'application/json' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `products_${new Date().toISOString().slice(0, 10)}.json`;
        a.click();
        URL.revokeObjectURL(a.href);
        context.alertBox('success', `Exported ${products.length} product(s) to JSON.`);
        setBulkAnchorEl(null);
    };

    const handleFileChange = (e) => {
        const f = e.target.files?.[0];
        if (!f) {
            return;
        }
        const isCsv = f.name.toLowerCase().endsWith('.csv');
        if (!isCsv) {
            context.alertBox('error', 'Invalid file format. Please use CSV.');
            e.target.value = '';
            setImportFile(null);
            setImportFileName('');
            return;
        }
        setImportFile(f);
        setImportFileName(f.name);
        setImportError(null);
        e.target.value = '';
    };

    const resetImportState = () => {
        setImportFile(null);
        setImportFileName('');
        setUpdateExisting(false);
        setImportError(null);
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    };

    const handleImport = async () => {
        if (!importFile) {
            context.alertBox('error', 'Please select a CSV file first.');
            return;
        }

        const formData = new FormData();
        formData.append('file', importFile);
        formData.append('updateExisting', JSON.stringify(updateExisting));

        setImportLoading(true);
        setImportError(null);

        try {
            const requestConfig = {
                headers: {
                    Authorization: `Bearer ${getAdminAccessToken()}`,
                    'Content-Type': 'multipart/form-data',
                },
            };
            let res;

            try {
                const response = await axios.post(buildApiUrl('/api/products/import'), formData, requestConfig);
                res = response.data;
            } catch (err) {
                if (err?.response?.status !== 404) {
                    throw err;
                }

                const fallbackResponse = await axios.post(buildApiUrl('/api/product/import'), formData, requestConfig);
                res = fallbackResponse.data;
            }

            if (res?.success) {
                const created = res?.created ?? 0;
                const updated = res?.updated ?? 0;
                const failed = res?.failed ?? 0;
                const total = (res?.imported ?? 0) || (created + updated);
                let msg = `Import complete: ${total} processed (${created} created, ${updated} updated).`;
                if (failed > 0) msg += ` ${failed} error(s).`;
                context.alertBox('success', msg);
                if (res?.errors?.length) {
                    const errPreview = res.errors.slice(0, 5).map((e) => e.row && e.message ? `Row ${e.row}: ${e.message}` : e.message).join('; ');
                    context.alertBox('info', errPreview);
                }
                setImportDialogOpen(false);
                resetImportState();
                loadProducts();
            } else {
                const errMsg = res?.message || 'Import failed.';
                setImportError({
                    title: 'Import failed.',
                    message: errMsg,
                    details: res?.errors,
                });
            }
        } catch (err) {
            const message = err?.response?.data?.message || err?.message || 'Import failed.';
            setImportError({
                title: 'Import failed.',
                message,
            });
        }
        setImportLoading(false);
    };

    const handleBulkDelete = () => {
        setBulkAnchorEl(null);
        deleteMultipleProduct();
    };

    const handleSyncCategories = async () => {
        setSyncLoading(true);
        try {
            const res = await postData('/api/product/syncCategories', {});
            if (res?.error === false && res?.success) {
                context.alertBox('success', res.message || `Synced ${res.updated} product(s).`);
                loadProducts();
            } else {
                context.alertBox('error', res?.message || 'Sync failed.');
            }
        } catch (e) {
            context.alertBox('error', e?.message || 'Sync failed.');
        }
        setSyncLoading(false);
    };

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    return (
        <>

            <div className="flex items-center justify-between px-2 py-0 mt-3">
                <h2 className="text-[18px] font-[600]">
                    Services{" "}
                    <span className="font-[400] text-[14px]"></span>
                </h2>

                <div className="col w-[75%] ml-auto flex items-center justify-end gap-2 flex-wrap">
                    <Tooltip title="Update categories from the server.">
                        <span>
                            <Button
                                className="btn-sm"
                                size="small"
                                variant="outlined"
                                onClick={handleSyncCategories}
                                disabled={syncLoading}
                            >
                                {syncLoading ? 'Syncing...' : 'Sync Categories'}
                            </Button>
                        </span>
                    </Tooltip>
                    <Tooltip title="Download current view as CSV.">
                        <span>
                            <Button
                                className="btn-sm"
                                size="small"
                                variant="outlined"
                                startIcon={<FiDownload />}
                                onClick={() => setExportDialogOpen(true)}
                            >
                                Export
                            </Button>
                        </span>
                    </Tooltip>

                    <Tooltip title="Upload new product data.">
                        <span>
                            <Button
                                className="btn-sm"
                                size="small"
                                variant="outlined"
                                startIcon={<FiUpload />}
                                onClick={() => setImportDialogOpen(true)}
                            >
                                Import
                            </Button>
                        </span>
                    </Tooltip>

                    <Tooltip title="Apply changes to selected items.">
                        <span>
                            <Button
                                className="btn-sm !bg-[#ed6c02] !text-white hover:!bg-[#e65100]"
                                size="small"
                                variant="contained"
                                onClick={(e) => setBulkAnchorEl(e.currentTarget)}
                            >
                                Bulk Action
                            </Button>
                        </span>
                    </Tooltip>
                    <Menu anchorEl={bulkAnchorEl} open={Boolean(bulkAnchorEl)} onClose={() => setBulkAnchorEl(null)}>
                        <MenuItem
                            onClick={handleBulkDelete}
                            disabled={!sortedIds?.length}
                        >
                            Delete
                        </MenuItem>
                        <MenuItem
                            onClick={() => { exportToCSV(); }}
                            disabled={!getProductsToExport().length}
                        >
                            Export to CSV
                        </MenuItem>
                        <MenuItem
                            onClick={() => { exportToJSON(); }}
                            disabled={!getProductsToExport().length}
                        >
                            Export to JSON
                        </MenuItem>
                    </Menu>

                    {
                        sortedIds?.length !== 0 && <Button variant="contained" className="btn-sm" size="small" color="error"
                            onClick={deleteMultipleProduct}>Delete</Button>
                    }

                    <Button className="btn-blue !text-white btn-sm"
                        onClick={() => context.setIsOpenFullScreenPanel({
                            open: true,
                            model: 'Add Service'
                        })}>Add Service</Button>
                </div>


            </div>


            <div className="card my-4 pt-5 shadow-md sm:rounded-lg bg-white">

                <div className="grid grid-cols-1 sm:grid-cols-2  md:grid-cols-2 lg:grid-cols-4 w-full px-5 justify-beetween gap-4">
                    <div className="col">
                        <h4 className="font-[600] text-[13px] mb-2">Category By</h4>
                        {
                            context?.catData?.length !== 0 &&
                            <Select
                                style={{ zoom: '80%' }}
                                labelId="filter-cat-label"
                                id="productCatDrop"
                                size="small"
                                className='w-full'
                                value={productCat || ''}
                                label="Category"
                                onChange={handleChangeProductCat}
                                displayEmpty
                            >
                                <MenuItem value="">All categories</MenuItem>
                                {
                                    context?.catData?.map((cat, index) => (
                                        <MenuItem value={cat?._id} key={index}>{cat?.name}</MenuItem>
                                    ))
                                }
                            </Select>
                        }
                    </div>


                    <div className="col">
                        <h4 className="font-[600] text-[13px] mb-2">Sub Category By</h4>
                        {
                            context?.catData?.length !== 0 &&
                            <Select
                                style={{ zoom: '80%' }}
                                labelId="filter-subcat-label"
                                id="productSubCatDrop"
                                size="small"
                                className='w-full'
                                value={productSubCat || ''}
                                label="Sub Category"
                                onChange={handleChangeProductSubCat}
                                disabled={!productCat}
                                displayEmpty
                            >
                                <MenuItem value="">All sub categories</MenuItem>
                                {
                                    productCat && context?.catData?.find((c) => String(c?._id) === String(productCat))?.children?.map((subCat, index_) => (
                                        <MenuItem value={subCat?._id} key={index_}>{subCat?.name}</MenuItem>
                                    ))
                                }
                            </Select>
                        }
                    </div>


                    <div className="col">
                        <h4 className="font-[600] text-[13px] mb-2">Third Level Sub Category By</h4>
                        {
                            context?.catData?.length !== 0 &&
                            <Select
                                style={{ zoom: '80%' }}
                                labelId="filter-thirdcat-label"
                                id="productThirdCatDrop"
                                size="small"
                                className='w-full'
                                value={productThirdLavelCat || ''}
                                label="Third Level"
                                onChange={handleChangeProductThirdLavelCat}
                                disabled={!productSubCat}
                                displayEmpty
                            >
                                <MenuItem value="">All third level</MenuItem>
                                {
                                    productCat && productSubCat && (() => {
                                        const cat = context?.catData?.find((c) => String(c?._id) === String(productCat));
                                        const sub = cat?.children?.find((s) => String(s?._id) === String(productSubCat));
                                        return sub?.children?.map((thirdLavelCat, index) => (
                                            <MenuItem value={thirdLavelCat?._id} key={index}>{thirdLavelCat?.name}</MenuItem>
                                        ));
                                    })()
                                }
                            </Select>
                        }
                    </div>


                    <div className="col w-full ml-auto flex items-center">
                        <div style={{ alignSelf: 'end' }} className="w-full">
                            <SearchBox
                                searchQuery={searchQuery}
                                setSearchQuery={setSearchQuery}
                            />
                        </div>
                    </div>

                </div>

                <br />
                <TableContainer sx={{ maxHeight: 440 }}>
                    <Table stickyHeader aria-label="sticky table">
                        <TableHead>
                            <TableRow>
                                <TableCell>
                                    <Checkbox {...label} size="small"
                                        onChange={handleSelectAll}
                                        checked={productData?.products?.length > 0 ? productData?.products?.every((item) => item.checked) : false}
                                    />
                                </TableCell>
                                {columns.map((column) => (
                                    <TableCell
                                        key={column.id}
                                        align={column.align}
                                        style={{ minWidth: column.minWidth }}
                                    >
                                        {column.label}
                                    </TableCell>
                                ))}
                            </TableRow>
                        </TableHead>
                        <TableBody>

                            {isLoading === false ? (
                                productData?.products?.length !== 0 ? productData?.products?.map((product, index) => {
                                    return (
                                        <TableRow key={index} className={product.checked === true ? '!bg-[#1976d21f]' : ''}>
                                            <TableCell style={{ minWidth: columns.minWidth }}>
                                                <Checkbox {...label} size="small" checked={product.checked === true ? true : false}
                                                    onChange={(e) => handleCheckboxChange(e, product._id, index)}
                                                />
                                            </TableCell>
                                            <TableCell style={{ minWidth: columns.minWidth }}>
                                                <div className="flex items-center gap-4 w-[300px]" title={product?.name}>
                                                    <div className="img w-[65px] h-[65px] rounded-md overflow-hidden group cursor-pointer" onClick={() => setOpen(true)}>
                                                        <LazyLoadImage
                                                            alt={product?.name || 'product'}
                                                            effect="blur"
                                                            src={product?.images?.[0] || '/icon.svg'}
                                                            className="w-full group-hover:scale-105 transition-all"
                                                        />
                                                    </div>
                                                    <div className="info w-[75%]">
                                                        <h3 className="font-[600] text-[12px] leading-4 hover:text-primary">
                                                            <Link to={`/product/${product?._id}`}>
                                                                {product?.name?.substr(0, 50) + '...'}
                                                            </Link>
                                                        </h3>
                                                        <span className="text-[12px]">{product?.brand}</span>
                                                    </div>
                                                </div>
                                            </TableCell>

                                            <TableCell style={{ minWidth: columns.minWidth }}>
                                                {product?.catName}
                                            </TableCell>

                                            <TableCell style={{ minWidth: columns.minWidth }}>
                                                {product?.subCat || '—'}
                                            </TableCell>

                                            <TableCell style={{ minWidth: columns.minWidth }}>
                                                {product?.thirdsubCat || '—'}
                                            </TableCell>

                                            <TableCell style={{ minWidth: columns.minWidth }}>
                                                <div className="flex gap-1 flex-col">
                                                    <span className="oldPrice line-through leading-3 text-gray-500 text-[14px] font-[500]">
                                                        {product?.price?.toLocaleString('ar-AE', { style: 'currency', currency: 'AED' })}
                                                    </span>
                                                    <span className="price text-primary text-[14px]  font-[600]">
                                                        {product?.oldPrice?.toLocaleString('ar-AE', { style: 'currency', currency: 'AED' })}
                                                    </span>
                                                </div>
                                            </TableCell>

                                            <TableCell style={{ minWidth: columns.minWidth }}>
                                                <p className="text-[14px] w-[70px]">
                                                    <span className="font-[600]">{product?.sale}</span> sale
                                                </p>


                                            </TableCell>


                                            <TableCell style={{ minWidth: columns.minWidth }}>
                                                <p className="text-[14px] w-[70px]">
                                                    <span className="font-[600] text-primary">{product?.countInStock}</span>
                                                </p>


                                            </TableCell>


                                            <TableCell style={{ minWidth: columns.minWidth }}>
                                                <p className="text-[14px] w-[100px]">
                                                    <Rating name="half-rating" size="small" defaultValue={product?.rating} readOnly />
                                                </p>


                                            </TableCell>

                                            <TableCell style={{ minWidth: columns.minWidth }}>
                                                <div className="flex items-center gap-1">
                                                    <Button className="!w-[35px] !h-[35px] bg-[#f1f1f1] !border !border-[rgba(0,0,0,0.4)] !rounded-full hover:!bg-[#f1f1f1] !min-w-[35px]"
                                                        onClick={() => context.setIsOpenFullScreenPanel({
                                                            open: true,
                                                            model: 'Edit Service',
                                                            id: product?._id
                                                        })}
                                                    >
                                                        <AiOutlineEdit className="text-[rgba(0,0,0,0.7)] text-[20px] " />
                                                    </Button>

                                                    <Link to={`/product/${product?._id}`}>
                                                        <Button className="!w-[35px] !h-[35px] bg-[#f1f1f1] !border !border-[rgba(0,0,0,0.4)] !rounded-full hover:!bg-[#f1f1f1] !min-w-[35px]">
                                                            <FaRegEye className="text-[rgba(0,0,0,0.7)] text-[18px] " />
                                                        </Button>
                                                    </Link>

                                                    <Button className="!w-[35px] !h-[35px] bg-[#f1f1f1] !border !border-[rgba(0,0,0,0.4)] !rounded-full hover:!bg-[#f1f1f1] !min-w-[35px]" onClick={() => deleteProduct(product?._id)}>
                                                        <GoTrash className="text-[rgba(0,0,0,0.7)] text-[18px] " />
                                                    </Button>
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    )
                                }) : (
                                    <TableRow>
                                        <TableCell colSpan={10}>
                                            <div className="flex flex-col items-center justify-center w-full min-h-[320px] gap-2 text-center">
                                                <p className="text-[14px] font-[600]">No services found.</p>
                                                <p className="text-[13px] text-gray-500">
                                                    Click &quot;Add Service&quot; or &quot;Import&quot; to get started.
                                                </p>
                                                <div className="flex items-center gap-2">
                                                    <Button
                                                        className="btn-sm"
                                                        variant="outlined"
                                                        onClick={() => setImportDialogOpen(true)}
                                                    >
                                                        Import
                                                    </Button>
                                                    <Button
                                                        className="btn-blue !text-white btn-sm"
                                                        onClick={() => context.setIsOpenFullScreenPanel({
                                                            open: true,
                                                            model: 'Add Service'
                                                        })}
                                                    >
                                                        Add Service
                                                    </Button>
                                                </div>
                                            </div>
                                        </TableCell>
                                    </TableRow>
                                )
                            ) : (
                                <TableRow>
                                    <TableCell colSpan={10}>
                                        <div className="flex items-center justify-center w-full min-h-[400px]">
                                            <CircularProgress color="inherit" />
                                        </div>
                                    </TableCell>
                                </TableRow>
                            )}



                        </TableBody>
                    </Table>
                </TableContainer>
                <TablePagination
                    rowsPerPageOptions={[50, 100, 150, 200]}
                    component="div"
                    count={Number(productData?.totalCount ?? 0)}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    onPageChange={handleChangePage}
                    onRowsPerPageChange={handleChangeRowsPerPage}
                />
            </div>


            <Lightbox
                open={open}
                close={() => setOpen(false)}
                slides={photos}
            />

            <Dialog open={exportDialogOpen} onClose={() => setExportDialogOpen(false)} maxWidth="sm" fullWidth>
                <DialogTitle>Export Services</DialogTitle>
                <DialogContent>
                    <Typography variant="body2" className="text-gray-500 mb-4">
                        Download your service list to a CSV file.
                    </Typography>
                    <FormControl fullWidth className="mb-4">
                        <InputLabel id="export-columns-label">Select columns to export.</InputLabel>
                        <Select
                            labelId="export-columns-label"
                            multiple
                            value={exportColumns}
                            onChange={(e) => setExportColumns(e.target.value)}
                            label="Select columns to export."
                            renderValue={(selected) => (
                                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                                    {selected.map((value) => {
                                        const label = exportColumnOptions.find((opt) => opt.value === value)?.label || value;
                                        return <Chip key={value} label={label} size="small" />;
                                    })}
                                </Box>
                            )}
                        >
                            {exportColumnOptions.map((option) => (
                                <MenuItem key={option.value} value={option.value}>
                                    <Checkbox checked={exportColumns.indexOf(option.value) > -1} />
                                    <ListItemText primary={option.label} />
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                    <FormControl fullWidth>
                        <InputLabel id="export-types-label">Select product types.</InputLabel>
                        <Select
                            labelId="export-types-label"
                            multiple
                            value={exportTypes}
                            onChange={(e) => setExportTypes(e.target.value)}
                            label="Select product types."
                            renderValue={(selected) => (
                                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                                    {selected.map((value) => {
                                        const label = productTypeOptions.find((opt) => opt.value === value)?.label || value;
                                        return <Chip key={value} label={label} size="small" />;
                                    })}
                                </Box>
                            )}
                        >
                            {productTypeOptions.map((option) => (
                                <MenuItem key={option.value} value={option.value}>
                                    <Checkbox checked={exportTypes.indexOf(option.value) > -1} />
                                    <ListItemText primary={option.label} />
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => setExportDialogOpen(false)}>Cancel</Button>
                    <Button variant="contained" onClick={exportToCSV}>
                        Generate CSV
                    </Button>
                </DialogActions>
            </Dialog>

            <Dialog
                open={importDialogOpen}
                onClose={() => {
                    setImportDialogOpen(false);
                    resetImportState();
                }}
                maxWidth="sm"
                fullWidth
            >
                <DialogTitle>Import Services</DialogTitle>
                <DialogContent>
                    <Typography variant="body2" className="text-gray-500 mb-4">
                        Upload a CSV to add or update salon service data.
                    </Typography>
                    {importError && (
                        <div className="mb-3 border border-red-200 bg-red-50 rounded-md px-3 py-2 text-[12px] text-red-700">
                            <div className="font-[600]">{importError.title}</div>
                            <div>{importError.message}</div>
                        </div>
                    )}
                    <div className="flex items-center gap-3 mb-4">
                        <Button
                            className="btn-sm"
                            size="small"
                            variant="outlined"
                            startIcon={<FiFile />}
                            onClick={() => fileInputRef.current?.click()}
                        >
                            Choose CSV file
                        </Button>
                        <span className="text-[13px] text-gray-500">
                            {importFileName || 'No file chosen'}
                        </span>
                    </div>
                    <input
                        ref={fileInputRef}
                        type="file"
                        accept=".csv,text/csv"
                        className="hidden"
                        onChange={handleFileChange}
                    />
                    <div className="mb-3 text-[12px] text-gray-500">
                        Required headers: `name` and `price`. Optional headers include `description`, `brand`,
                        `oldPrice`, `catName`, `subCat`, `thirdsubCat`, `countInStock`, `rating`, `discount`, `sale`,
                        `images`, `sku`, `product_id`, and the 12 attribute name/value column pairs.
                    </div>
                    <FormControlLabel
                        control={
                            <Checkbox
                                checked={updateExisting}
                                onChange={(e) => setUpdateExisting(e.target.checked)}
                            />
                        }
                        label="Update existing products (match by ID/SKU)."
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => { setImportDialogOpen(false); resetImportState(); }}>Cancel</Button>
                    <Button
                        variant="contained"
                        onClick={handleImport}
                        disabled={!importFile || importLoading}
                    >
                        {importLoading ? 'Importing...' : 'Continue'}
                    </Button>
                </DialogActions>
            </Dialog>


        </>
    )
}

export default Products;
