import React, { useContext, useEffect, useState } from 'react'
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import Rating from '@mui/material/Rating';
import UploadBox from '../../Components/UploadBox';
import { LazyLoadImage } from 'react-lazy-load-image-component';
import 'react-lazy-load-image-component/src/effects/blur.css';
import { IoMdClose } from "react-icons/io";
import { Button } from '@mui/material';
import { FaCloudUploadAlt } from "react-icons/fa";
import { MyContext } from '../../App';
import { deleteImages, fetchDataFromApi, postData } from '../../utils/api';
import { useNavigate } from 'react-router-dom';
import CircularProgress from '@mui/material/CircularProgress';
import Switch from '@mui/material/Switch';

const label = { inputProps: { 'aria-label': 'Switch demo' } };
const ATTRIBUTE_LIBRARY = [
    "Dimensions",
    "Material",
    "Brand",
    "Installation",
    "Service",
    "SKU",
];

const createEmptySpecification = () => ({
    name: "",
    value: "",
    visible: true,
    scope: "custom",
});


const AddProduct = () => {

    const [formFields, setFormFields] = useState({
        name: "",
        description: "",
        images: [],
        brand: "",
        price: "",
        oldPrice: "",
        category: "",
        catName: "",
        catId: "",
        subCatId: "",
        subCat: "",
        thirdsubCat: "",
        thirdsubCatId: "",
        countInStock: "",
        rating: "",
        isFeatured: false,
        discount: "",
        productRam: [],
        size: [],
        productWeight: [],
        specifications: [],
        bannerTitleName: '',
        bannerimages: [],
        isDisplayOnHomeBanner:false

    })


    const [productCat, setProductCat] = React.useState('');
    const [productSubCat, setProductSubCat] = React.useState('');
    const [productFeatured, setProductFeatured] = React.useState('');
    const [productRams, setProductRams] = React.useState([]);
    const [productRamsData, setProductRamsData] = React.useState([]);
    const [productWeight, setProductWeight] = React.useState([]);
    const [productWeightData, setProductWeightData] = React.useState([]);
    const [productSize, setProductSize] = React.useState([]);
    const [productSizeData, setProductSizeData] = React.useState([]);
    const [isLoading, setIsLoading] = useState(false);

    const [productThirdLavelCat, setProductThirdLavelCat] = useState('');

    const [previews, setPreviews] = useState([]);
    const [bannerPreviews, setBannerPreviews] = useState([]);

    const [checkedSwitch, setCheckedSwitch] = useState(false);
    const [specifications, setSpecifications] = useState([]);
    const [draggedSpecIndex, setDraggedSpecIndex] = useState(null);


    const history = useNavigate();

    const context = useContext(MyContext);


    useEffect(() => {
        fetchDataFromApi("/api/product/productRAMS/get").then((res) => {
            if (res?.error === false) {
                setProductRamsData(res?.data);
            }
        })

        fetchDataFromApi("/api/product/productWeight/get").then((res) => {
            if (res?.error === false) {
                setProductWeightData(res?.data);
            }
        })

        fetchDataFromApi("/api/product/productSize/get").then((res) => {
            if (res?.error === false) {
                setProductSizeData(res?.data);
            }
        })
    }, [])


    const handleChangeProductCat = (event) => {
        const value = event.target.value;
        setProductCat(value);
        setProductSubCat('');
        setProductThirdLavelCat('');
        const cat = context?.catData?.find((c) => c._id === value);
        setFormFields((prev) => ({
            ...prev,
            catId: value,
            category: value,
            catName: cat?.name || '',
            subCatId: '',
            subCat: '',
            thirdsubCatId: '',
            thirdsubCat: '',
        }));
    };

    const handleChangeProductSubCat = (event) => {
        const value = event.target.value;
        setProductSubCat(value);
        setProductThirdLavelCat('');
        let parent, sub;
        for (const c of context?.catData || []) {
            sub = c?.children?.find((ch) => ch._id === value);
            if (sub) {
                parent = c;
                break;
            }
        }
        setProductCat(parent?._id || '');
        setFormFields((prev) => ({
            ...prev,
            catId: parent?._id || '',
            catName: parent?.name || '',
            subCatId: value,
            subCat: sub?.name || '',
            category: value,
            thirdsubCatId: '',
            thirdsubCat: '',
        }));
    };

    const handleChangeProductThirdLavelCat = (event) => {
        const value = event.target.value;
        setProductThirdLavelCat(value);
        let cat, sub, third;
        for (const c of context?.catData || []) {
            for (const s of c?.children || []) {
                third = s?.children?.find((t) => t._id === value);
                if (third) {
                    sub = s;
                    cat = c;
                    break;
                }
            }
            if (third) break;
        }
        setProductCat(cat?._id || '');
        setProductSubCat(sub?._id || '');
        setFormFields((prev) => ({
            ...prev,
            catId: cat?._id || '',
            catName: cat?.name || '',
            subCatId: sub?._id || '',
            subCat: sub?.name || '',
            thirdsubCatId: value,
            thirdsubCat: third?.name || '',
            category: value,
        }));
    };


    const handleChangeProductFeatured = (event) => {
        setProductFeatured(event.target.value);
        formFields.isFeatured = event.target.value
    };

    const handleChangeProductRams = (event) => {
        const {
            target: { value },
        } = event;
        setProductRams(
            // On autofill we get a stringified value.
            typeof value === "string" ? value.split(",") : value
        );

        formFields.productRam = value;

    };

    const handleChangeProductWeight = (event) => {

        const {
            target: { value },
        } = event;
        setProductWeight(
            // On autofill we get a stringified value.
            typeof value === "string" ? value.split(",") : value
        );

        formFields.productWeight = value;
    };

    const handleChangeProductSize = (event) => {

        const {
            target: { value },
        } = event;
        setProductSize(
            // On autofill we get a stringified value.
            typeof value === "string" ? value.split(",") : value
        );

        formFields.size = value;
    };


    const onChangeInput = (e) => {
        const { name, value } = e.target;
        setFormFields(() => {
            return {
                ...formFields,
                [name]: value
            }
        })
    }

    const onChangeRating = (e) => {
        setFormFields((formFields) => (
            {
                ...formFields,
                rating: e.target.value
            }
        ))
    }


    const setPreviewsFun = (previewsArr) => {
        const imgArr = previews;
        for (let i = 0; i < previewsArr.length; i++) {
            imgArr.push(previewsArr[i])
        }

        setPreviews([])
        setTimeout(() => {
            setPreviews(imgArr)
            formFields.images = imgArr
        }, 10);
    }


    const setBannerImagesFun = (previewsArr) => {
        const imgArr = bannerPreviews;
        for (let i = 0; i < previewsArr.length; i++) {
            imgArr.push(previewsArr[i])
        }

        setBannerPreviews([])
        setTimeout(() => {
            setBannerPreviews(imgArr)
            formFields.bannerimages = imgArr
        }, 10);
    }



   const removeImg = (image, index) => {
        var imageArr = [];
        imageArr = previews;
        deleteImages(`/api/category/deteleImage?img=${image}`).then((res) => {
            imageArr.splice(index, 1);

            setPreviews([]);
            setTimeout(() => {
                setPreviews(imageArr);
                formFields.images = imageArr
            }, 100);

        })
    }


    const removeBannerImg = (image, index) => {
        var imageArr = [];
        imageArr = bannerPreviews;
        deleteImages(`/api/category/deteleImage?img=${image}`).then((res) => {
            imageArr.splice(index, 1);

            setBannerPreviews([]);
            setTimeout(() => {
                setBannerPreviews(imageArr);
                formFields.bannerimages = imageArr
            }, 100);

        })
    }


    const handleChangeSwitch=(event)=>{
        setCheckedSwitch(event.target.checked);
        formFields.isDisplayOnHomeBanner = event.target.checked;
    }

    const addSpecificationRow = () => {
        setSpecifications((prev) => [...prev, createEmptySpecification()]);
    };

    const removeSpecificationRow = (index) => {
        setSpecifications((prev) => prev.filter((_, i) => i !== index));
    };

    const updateSpecification = (index, field, value) => {
        setSpecifications((prev) =>
            prev.map((item, i) => {
                if (i !== index) return item;
                return { ...item, [field]: value };
            })
        );
    };

    const onDragStartSpec = (index) => {
        setDraggedSpecIndex(index);
    };

    const onDropSpec = (index) => {
        if (draggedSpecIndex === null || draggedSpecIndex === index) return;

        setSpecifications((prev) => {
            const items = [...prev];
            const [moved] = items.splice(draggedSpecIndex, 1);
            items.splice(index, 0, moved);
            return items;
        });
        setDraggedSpecIndex(null);
    };

    const buildSpecificationsPayload = () => {
        return specifications
            .map((spec) => {
                const name = String(spec?.name || "").trim();
                const values = String(spec?.value || "")
                    .split(",")
                    .map((item) => item.trim())
                    .filter(Boolean);

                return {
                    name,
                    values,
                    visible: spec?.visible !== false,
                    scope: spec?.scope === "global" ? "global" : "custom",
                };
            })
            .filter((spec) => spec.name || spec.values.length);
    };


    const handleSubmitg = (e) => {
        e.preventDefault(0);

        console.log(formFields)
        if (formFields.name === "") {
            context.alertBox("error", "Please enter service name");
            return false;
        }

        if (formFields.description === "") {
            context.alertBox("error", "Please enter service description");
            return false;
        }



        if (!formFields?.catId && !formFields?.subCatId && !formFields?.thirdsubCatId) {
            context.alertBox("error", "Please select at least one category level");
            return false;
        }



        if (formFields?.price === "") {
            context.alertBox("error", "Please enter service price");
            return false;
        }


        if (formFields?.oldPrice === "") {
            context.alertBox("error", "Please enter service old price");
            return false;
        }


        if (formFields?.countInStock === "") {
            context.alertBox("error", "Please enter service stock");
            return false;
        }


        if (formFields?.brand === "") {
            context.alertBox("error", "Please enter service brand");
            return false;
        }


        if (formFields?.discount === "") {
            context.alertBox("error", "Please enter service discount");
            return false;
        }




        if (formFields?.rating === "") {
            context.alertBox("error", "Please enter service rating");
            return false;
        }


        if (previews?.length === 0) {
            context.alertBox("error", "Please select service images");
            return false;
        }


        setIsLoading(true);

        const payload = {
            ...formFields,
            specifications: buildSpecificationsPayload(),
        };

        postData("/api/product/create", payload).then((res) => {

            if (res?.error === false) {
                context.alertBox("success", res?.message);
                setTimeout(() => {
                    setIsLoading(false);
                    context.setIsOpenFullScreenPanel({
                        open: false,
                    })
                    history("/products");
                }, 1000);
            } else {
                setIsLoading(false);
                context.alertBox("error", res?.message);
            }
        })
    }

    return (
        <section className='p-5 bg-gray-50'>
            <form className='form py-1 p-1 md:p-8 md:py-1' onSubmit={handleSubmitg}>
                <div className='scroll max-h-[72vh] overflow-y-scroll pr-4'>

                    <div className='grid grid-cols-1 mb-3'>
                        <div className='col'>
                            <h3 className='text-[14px] font-[500] mb-1 text-black'>Service Name</h3>
                            <input type="text" className='w-full h-[40px] border border-[rgba(0,0,0,0.2)] focus:outline-none focus:border-[rgba(0,0,0,0.4)] rounded-sm p-3 text-sm' name="name" value={formFields.name} onChange={onChangeInput} />
                        </div>
                    </div>

                    <div className='grid grid-cols-1 mb-3'>
                        <div className='col'>
                            <h3 className='text-[14px] font-[500] mb-1 text-black'>Service Description</h3>
                            <textarea type="text" className='w-full h-[140px] border border-[rgba(0,0,0,0.2)] focus:outline-none focus:border-[rgba(0,0,0,0.4)] rounded-sm p-3 text-sm' name="description" value={formFields.description} onChange={onChangeInput} />
                        </div>
                    </div>



                    <div className='grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 mb-3 gap-4'>
                        <div className='col'>
                            <h3 className='text-[14px] font-[500] mb-1 text-black'>Service Category</h3>

                            {
                                context?.catData?.length !== 0 &&
                                <Select
                                    labelId="product-cat-label"
                                    id="productCatDrop"
                                    size="small"
                                    className='w-full'
                                    value={productCat || ''}
                                    label="Category"
                                    onChange={handleChangeProductCat}
                                    displayEmpty
                                >
                                    <MenuItem value="">Select category</MenuItem>
                                    {
                                        context?.catData?.map((cat, index) => (
                                            <MenuItem value={cat?._id} key={index}>{cat?.name}</MenuItem>
                                        ))
                                    }
                                </Select>
                            }
                        </div>

                        <div className='col'>
                            <h3 className='text-[14px] font-[500] mb-1 text-black'>Service Sub Category</h3>

                            {
                                context?.catData?.length !== 0 &&
                                <Select
                                    labelId="product-subcat-label"
                                    id="productSubCatDrop"
                                    size="small"
                                    className='w-full'
                                    value={productSubCat || ''}
                                    label="Sub Category"
                                    onChange={handleChangeProductSubCat}
                                    disabled={!productCat}
                                    displayEmpty
                                >
                                    <MenuItem value="">Select sub category</MenuItem>
                                    {
                                        productCat && context?.catData?.find((c) => String(c?._id) === String(productCat))?.children?.map((subCat, index_) => (
                                            <MenuItem value={subCat?._id} key={index_}>
                                                {subCat?.name}
                                            </MenuItem>
                                        ))
                                    }
                                </Select>
                            }
                        </div>


                        <div className='col'>
                            <h3 className='text-[14px] font-[500] mb-1 text-black'>Service Third Level Category</h3>

                            {
                                context?.catData?.length !== 0 &&
                                <Select
                                    labelId="product-thirdcat-label"
                                    id="productThirdCatDrop"
                                    size="small"
                                    className='w-full'
                                    value={productThirdLavelCat || ''}
                                    label="Third Level Category"
                                    onChange={handleChangeProductThirdLavelCat}
                                    disabled={!productSubCat}
                                    displayEmpty
                                >
                                    <MenuItem value="">Select third level (optional)</MenuItem>
                                    {
                                        productSubCat && (() => {
                                            const cat = context?.catData?.find((c) => String(c?._id) === String(productCat));
                                            const sub = cat?.children?.find((s) => String(s?._id) === String(productSubCat));
                                            return sub?.children?.map((thirdLavelCat, index) => (
                                                <MenuItem value={thirdLavelCat?._id} key={index}>
                                                    {thirdLavelCat?.name}
                                                </MenuItem>
                                            ));
                                        })()
                                    }
                                </Select>
                            }
                        </div>


                        <div className='col'>
                            <h3 className='text-[14px] font-[500] mb-1 text-black'>Service Price</h3>
                            <input type="number" className='w-full h-[40px] border border-[rgba(0,0,0,0.2)] focus:outline-none focus:border-[rgba(0,0,0,0.4)] rounded-sm p-3 text-sm ' name="price" value={formFields.price} onChange={onChangeInput} />
                        </div>


                        <div className='col'>
                            <h3 className='text-[14px] font-[500] mb-1  text-black'>Service Old Price</h3>
                            <input type="number" className='w-full h-[40px] border border-[rgba(0,0,0,0.2)] focus:outline-none focus:border-[rgba(0,0,0,0.4)] rounded-sm p-3 text-sm ' name="oldPrice" value={formFields.oldPrice} onChange={onChangeInput} />
                        </div>

                        <div className='col'>
                            <h3 className='text-[14px] font-[500] mb-1 text-black'>Is Featured?</h3>
                            <Select
                                labelId="demo-simple-select-label"
                                id="productCatDrop"
                                size="small"
                                className='w-full'
                                value={productFeatured}
                                label="Category"
                                onChange={handleChangeProductFeatured}
                            >
                                <MenuItem value={true}>True</MenuItem>
                                <MenuItem value={false}>False</MenuItem>
                            </Select>
                        </div>


                        <div className='col'>
                            <h3 className='text-[14px] font-[500] mb-1 text-black'>Service Stock</h3>
                            <input type="number" className='w-full h-[40px] border border-[rgba(0,0,0,0.2)] focus:outline-none focus:border-[rgba(0,0,0,0.4)] rounded-sm p-3 text-sm ' name="countInStock" value={formFields.countInStock} onChange={onChangeInput} />
                        </div>


                        <div className='col'>
                            <h3 className='text-[14px] font-[500] mb-1 text-black'>Service Brand</h3>
                            <input type="text" className='w-full h-[40px] border border-[rgba(0,0,0,0.2)] focus:outline-none focus:border-[rgba(0,0,0,0.4)] rounded-sm p-3 text-sm ' name="brand" value={formFields.brand} onChange={onChangeInput} />
                        </div>


                        <div className='col'>
                            <h3 className='text-[14px] font-[500] mb-1 text-black'>Service Discount</h3>
                            <input type="number" className='w-full h-[40px] border border-[rgba(0,0,0,0.2)] focus:outline-none focus:border-[rgba(0,0,0,0.4)] rounded-sm p-3 text-sm ' name="discount" value={formFields.discount} onChange={onChangeInput} />
                        </div>


                        <div className='col'>
                            <h3 className='text-[14px] font-[500] mb-1 text-black'>Service RAMS</h3>
                            {
                                productRamsData?.length !== 0 &&
                                <Select
                                    multiple
                                    labelId="demo-simple-select-label"
                                    id="productCatDrop"
                                    size="small"
                                    className='w-full'
                                    value={productRams}
                                    label="Category"
                                    onChange={handleChangeProductRams}
                                >
                                    {
                                        productRamsData?.map((item, index) => {
                                            return <MenuItem key={index} value={item?.name}>{item.name}</MenuItem>
                                        })
                                    }


                                </Select>
                            }

                        </div>

                        <div className='col'>
                            <h3 className='text-[14px] font-[500] mb-1 text-black'>Service Weight</h3>
                            {
                                productWeightData?.length !== 0 &&
                                <Select
                                    multiple
                                    labelId="demo-simple-select-label"
                                    id="productCatDrop"
                                    size="small"
                                    className='w-full'
                                    value={productWeight}
                                    label="Category"
                                    onChange={handleChangeProductWeight}
                                >

                                    {
                                        productWeightData?.map((item, index) => {
                                            return <MenuItem key={index} value={item?.name}>{item?.name}</MenuItem>
                                        })
                                    }

                                </Select>
                            }
                        </div>


                        <div className='col'>
                            <h3 className='text-[14px] font-[500] mb-1 text-black'>Service Size</h3>
                            {
                                productSizeData?.length !== 0 &&
                                <Select
                                    multiple
                                    labelId="demo-simple-select-label"
                                    id="productCatDrop"
                                    size="small"
                                    className='w-full'
                                    value={productSize}
                                    label="Category"
                                    onChange={handleChangeProductSize}
                                >

                                    {
                                        productSizeData?.map((item, index) => {
                                            return <MenuItem key={index} value={item?.name}>{item?.name}</MenuItem>
                                        })
                                    }
                                </Select>
                            }
                        </div>




                    </div>




                    <div className='grid grid-cols-1 sm:grid-cols-1 md:grid-cols-3 lg:grid-cols-4 mb-3 gap-4'>


                        <div className='col'>
                            <h3 className='text-[14px] font-[500] mb-1  text-black'>Service Rating </h3>
                            <Rating name="half-rating" defaultValue={1} onChange={onChangeRating} />
                        </div>


                    </div>


                    <div className='col w-full p-5 px-0'>
                        <div className='flex items-center justify-between mb-3'>
                            <h3 className="font-[700] text-[18px]">Service Attributes</h3>
                            <Button type="button" className='btn-blue !min-w-[120px]' onClick={addSpecificationRow}>
                                Add New
                            </Button>
                        </div>

                        <div className='space-y-3'>
                            {specifications?.map((spec, index) => (
                                <div
                                    key={index}
                                    className='grid grid-cols-1 md:grid-cols-12 gap-2 items-center p-3 border border-[rgba(0,0,0,0.12)] rounded-sm bg-white'
                                    draggable
                                    onDragStart={() => onDragStartSpec(index)}
                                    onDragOver={(e) => e.preventDefault()}
                                    onDrop={() => onDropSpec(index)}
                                >
                                    <div className='md:col-span-1 text-center text-[12px] text-gray-500 cursor-move' title="Drag to reorder">
                                        Drag
                                    </div>

                                    <div className='md:col-span-2'>
                                        <Select
                                            size="small"
                                            className='w-full'
                                            value={spec?.scope || "custom"}
                                            onChange={(e) => updateSpecification(index, "scope", e.target.value)}
                                        >
                                            <MenuItem value="global">Global</MenuItem>
                                            <MenuItem value="custom">Custom</MenuItem>
                                        </Select>
                                    </div>

                                    <div className='md:col-span-3'>
                                        {spec?.scope === "global" ? (
                                            <Select
                                                size="small"
                                                className='w-full'
                                                value={spec?.name || ""}
                                                displayEmpty
                                                onChange={(e) => updateSpecification(index, "name", e.target.value)}
                                            >
                                                <MenuItem value="">Select Attribute</MenuItem>
                                                {ATTRIBUTE_LIBRARY.map((attributeName) => (
                                                    <MenuItem key={attributeName} value={attributeName}>{attributeName}</MenuItem>
                                                ))}
                                            </Select>
                                        ) : (
                                            <input
                                                type="text"
                                                className='w-full h-[40px] border border-[rgba(0,0,0,0.2)] rounded-sm p-3 text-sm'
                                                placeholder='Key (e.g., Material)'
                                                value={spec?.name || ""}
                                                onChange={(e) => updateSpecification(index, "name", e.target.value)}
                                            />
                                        )}
                                    </div>

                                    <div className='md:col-span-4'>
                                        <input
                                            type="text"
                                            className='w-full h-[40px] border border-[rgba(0,0,0,0.2)] rounded-sm p-3 text-sm'
                                            placeholder='Value (comma separated)'
                                            value={spec?.value || ""}
                                            onChange={(e) => updateSpecification(index, "value", e.target.value)}
                                        />
                                    </div>

                                    <div className='md:col-span-1 flex items-center justify-center'>
                                        <Switch
                                            {...label}
                                            checked={spec?.visible !== false}
                                            onChange={(e) => updateSpecification(index, "visible", e.target.checked)}
                                        />
                                    </div>

                                    <div className='md:col-span-1 flex justify-end'>
                                        <Button type="button" className='!bg-red-50 !text-red-600 !min-w-[40px]' onClick={() => removeSpecificationRow(index)}>
                                            Remove
                                        </Button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>




                    <div className='col w-full p-5 px-0'>
                        <h3 className="font-[700] text-[18px] mb-3">Media & Images</h3>

                        <div className="grid grid-cols-2 md:grid-cols-7 gap-4">
                            {
                                previews?.length !== 0 && previews?.map((image, index) => {
                                    return (
                                        <div className="uploadBoxWrapper relative" key={index}>

                                            <span className='absolute w-[20px] h-[20px] rounded-full  overflow-hidden bg-red-700 -top-[5px] -right-[5px] flex items-center justify-center z-50 cursor-pointer' onClick={() => removeImg(image, index)}><IoMdClose className='text-white text-[17px]' /></span>


                                            <div className='uploadBox p-0 rounded-md overflow-hidden border border-dashed border-[rgba(0,0,0,0.3)] h-[150px] w-[100%] bg-gray-100 cursor-pointer hover:bg-gray-200 flex items-center justify-center flex-col relative'>

                                                <img src={image} className='w-100' />
                                            </div>
                                        </div>
                                    )
                                })
                            }


                            <UploadBox multiple={true} name="images" url="/api/product/uploadImages" setPreviewsFun={setPreviewsFun} />
                        </div>

                    </div>






                    <div className='col w-full p-5 px-0'>

                        <div className='bg-gray-100 p-4 w-full'>
                            <div className="flex items-center gap-8">
                                <h3 className="font-[700] text-[18px] mb-3">Banner Images</h3>
                                <Switch {...label} onChange={handleChangeSwitch} checked={checkedSwitch}/>
                            </div>
                            <div className="grid grid-cols-2 md:grid-cols-7 gap-4">

                                {
                                    bannerPreviews?.length !== 0 && bannerPreviews?.map((image, index) => {
                                        return (
                                            <div className="uploadBoxWrapper relative" key={index}>

                                                <span className='absolute w-[20px] h-[20px] rounded-full  overflow-hidden bg-red-700 -top-[5px] -right-[5px] flex items-center justify-center z-50 cursor-pointer' onClick={() => removeBannerImg(image, index)}><IoMdClose className='text-white text-[17px]' /></span>


                                                <div className='uploadBox p-0 rounded-md overflow-hidden border border-dashed border-[rgba(0,0,0,0.3)] h-[150px] w-[100%] bg-gray-100 cursor-pointer hover:bg-gray-200 flex items-center justify-center flex-col relative'>

                                                    <img src={image} className='w-100' />
                                                </div>
                                            </div>
                                        )
                                    })
                                }


                                <UploadBox multiple={true} name="bannerimages" url="/api/product/uploadBannerImages" setPreviewsFun={setBannerImagesFun} />
                            </div>


                            <br />

                            <h3 className="font-[700] text-[18px] mb-3">Banner Title</h3>
                            <input type="text" className='w-full h-[40px] border border-[rgba(0,0,0,0.2)] focus:outline-none focus:border-[rgba(0,0,0,0.4)] rounded-sm p-3 text-sm' name="bannerTitleName" value={formFields.bannerTitleName} onChange={onChangeInput} />
                        </div>



                    </div>

                </div>



                <hr />
                <br />
                <Button type="submit" className="btn-blue btn-lg w-full flex gap-2">

                    {
                        isLoading === true ? <CircularProgress color="inherit" />
                            :
                            <>
                                <FaCloudUploadAlt className='text-[25px] text-white' />
                                Publish and View
                            </>
                    }
                </Button>

            </form>
        </section>
    )
}

export default AddProduct;
