import React, { useContext, useEffect, useMemo, useState } from "react";
import {
  MenuItem,
  Select,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
} from "@mui/material";
import { MyContext } from "../../App";
import { editData, fetchDataFromApi } from "../../utils/api";

const statusOptions = [
  "draft",
  "confirmed",
  "scheduled",
  "in_progress",
  "completed",
  "cancelled",
];

const statusLabelMap = {
  draft: "Draft",
  confirmed: "Confirmed",
  scheduled: "Scheduled",
  in_progress: "In Progress",
  completed: "Completed",
  cancelled: "Cancelled",
};

const formatPaymentLabel = (value = "") =>
  String(value || "pending")
    .replace(/_/g, " ")
    .replace(/\b\w/g, (char) => char.toUpperCase());

const normalizeStatus = (status = "", paymentStatus = "") => {
  const normalizedStatus = String(status || "").toLowerCase();
  const normalizedPaymentStatus = String(paymentStatus || "").toLowerCase();

  if (statusOptions.includes(normalizedStatus)) {
    return normalizedStatus;
  }

  if (normalizedStatus === "confirm") return "confirmed";
  if (normalizedStatus === "delivered") return "completed";
  if (normalizedStatus === "pending") return "draft";
  if (normalizedStatus === "canceled") return "cancelled";

  if (normalizedPaymentStatus === "failed") return "cancelled";
  if (["paid", "authorized", "cash_on_visit"].includes(normalizedPaymentStatus)) return "confirmed";

  return "draft";
};

const normalizeBookingRecord = (booking) => {
  const paymentStatus = booking?.paymentStatus || booking?.orderId?.payment_status || "pending";
  const bookingReference = booking?.bookingReference || booking?.bookingId || booking?._id || "Pending";
  const scheduleDate = booking?.schedule?.date || booking?.bookingDate || booking?.schedule?.dayLabel || booking?.bookingDayLabel || "Date pending";
  const scheduleSlot =
    booking?.schedule?.slotLabel ||
    booking?.slotLabel ||
    [booking?.schedule?.startTime || booking?.startTime, booking?.schedule?.endTime || booking?.endTime].filter(Boolean).join(" - ") ||
    "Time pending";

  return {
    id: String(booking?.bookingId || booking?._id || bookingReference || booking?.createdAt),
    bookingId: String(booking?.bookingId || booking?._id || ""),
    bookingReference,
    customerName: booking?.customerInfo?.name || booking?.userId?.name || "Guest",
    customerEmail: booking?.customerInfo?.email || booking?.userId?.email || "No email",
    serviceName: booking?.serviceName || booking?.serviceSnapshot?.name || booking?.serviceId?.name || "Service pending",
    serviceMeta: booking?.addOns?.length
      ? `${booking.addOns.length} add-on${booking.addOns.length > 1 ? "s" : ""}`
      : `Qty ${booking?.quantity || 1}`,
    scheduleDate,
    scheduleSlot,
    professionalName: booking?.assignedProfessional?.name || booking?.professionalSnapshot?.name || booking?.professionalId?.name || "Auto assign",
    paymentMethod: booking?.paymentMethod || booking?.orderId?.paymentMethod || "card",
    paymentStatus: formatPaymentLabel(paymentStatus),
    total: Number(booking?.summary?.total ?? booking?.orderId?.totalAmt ?? 0),
    status: normalizeStatus(booking?.status, paymentStatus),
  };
};

const Bookings = () => {
  const context = useContext(MyContext);
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");

  const loadBookings = async () => {
    setLoading(true);
    setErrorMessage("");

    const response = await fetchDataFromApi("/api/bookings");

    if (response?.error === false && Array.isArray(response?.data)) {
      setItems(response.data.map(normalizeBookingRecord));
      setErrorMessage("");
    } else {
      setItems([]);
      setErrorMessage(response?.message || "Unable to load bookings.");
    }

    setLoading(false);
  };

  useEffect(() => {
    loadBookings();
  }, []);

  const filteredItems = useMemo(
    () =>
      items.filter((item) => {
        const matchesStatus = statusFilter === "all" ? true : item.status === statusFilter;
        const haystack = [
          item.bookingReference,
          item.customerName,
          item.customerEmail,
          item.serviceName,
          item.professionalName,
        ]
          .join(" ")
          .toLowerCase();

        return matchesStatus && haystack.includes(search.toLowerCase());
      }),
    [items, search, statusFilter]
  );

  const updateStatus = async (bookingId, status) => {
    const response = await editData(`/api/bookings/${bookingId}/status`, { status });
    const responseData = response?.data || response;

    if (responseData?.error === false || responseData?.success) {
      context?.alertBox("success", responseData?.message || "Booking updated successfully");
      loadBookings();
      return;
    }

    context?.alertBox("error", responseData?.message || "Unable to update booking");
  };

  return (
    <div className="card my-4 rounded-[18px] bg-white p-5 shadow-md">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <h2 className="text-[22px] font-[700] text-[#1f2937]">Bookings</h2>
          <p className="mt-1 text-[13px] text-gray-500">
            Track booking IDs, assigned professionals, payment references, and live appointment status.
          </p>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <TextField
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search booking, customer, or service"
            size="small"
          />
          <Select
            size="small"
            value={statusFilter}
            onChange={(event) => setStatusFilter(event.target.value)}
          >
            <MenuItem value="all">All statuses</MenuItem>
            {statusOptions.map((status) => (
              <MenuItem key={status} value={status}>
                {statusLabelMap[status] || status}
              </MenuItem>
            ))}
          </Select>
        </div>
      </div>

      <TableContainer className="mt-5">
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Booking ID</TableCell>
              <TableCell>Customer</TableCell>
              <TableCell>Service</TableCell>
              <TableCell>Schedule</TableCell>
              <TableCell>Professional</TableCell>
              <TableCell>Payment</TableCell>
              <TableCell>Total</TableCell>
              <TableCell>Status</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={8}>
                  <div className="py-12 text-center text-[14px] text-gray-500">Loading bookings...</div>
                </TableCell>
              </TableRow>
            ) : null}

            {!loading &&
              filteredItems.map((item) => (
                <TableRow key={item.id}>
                  <TableCell>
                    <p className="font-[700] text-primary">{item.bookingReference}</p>
                  </TableCell>
                  <TableCell>
                    <p className="font-[700] text-[#1f2937]">{item.customerName}</p>
                    <p className="text-[12px] text-gray-500">{item.customerEmail}</p>
                  </TableCell>
                  <TableCell>
                    <p className="font-[700] text-[#1f2937]">{item.serviceName}</p>
                    <p className="text-[12px] text-gray-500">{item.serviceMeta}</p>
                  </TableCell>
                  <TableCell>
                    <p className="font-[600] text-[#1f2937]">{item.scheduleDate}</p>
                    <p className="text-[12px] text-gray-500">{item.scheduleSlot}</p>
                  </TableCell>
                  <TableCell>{item.professionalName}</TableCell>
                  <TableCell>
                    <p className="font-[600] capitalize text-[#1f2937]">{item.paymentMethod}</p>
                    <p className="text-[12px] text-gray-500">{item.paymentStatus}</p>
                  </TableCell>
                  <TableCell>AED {item.total.toFixed(2)}</TableCell>
                  <TableCell>
                    <Select
                      size="small"
                      value={item.status}
                      onChange={(event) => updateStatus(item.bookingId, event.target.value)}
                    >
                      {statusOptions.map((status) => (
                        <MenuItem key={status} value={status}>
                          {statusLabelMap[status] || status}
                        </MenuItem>
                      ))}
                    </Select>
                  </TableCell>
                </TableRow>
              ))}

            {!loading && !filteredItems.length ? (
              <TableRow>
                <TableCell colSpan={8}>
                  <div className="py-12 text-center text-[14px] text-gray-500">
                    {errorMessage || "No bookings match the current filters."}
                  </div>
                </TableCell>
              </TableRow>
            ) : null}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
};

export default Bookings;
