import React, { useContext, useEffect, useState } from "react";
import {
  Button,
  Checkbox,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  InputLabel,
  ListItemText,
  MenuItem,
  Select,
  Switch,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
} from "@mui/material";
import { AiOutlineEdit } from "react-icons/ai";
import { GoTrash } from "react-icons/go";
import { MyContext } from "../../App";
import { deleteData, editData, fetchDataFromApi, postData } from "../../utils/api";

const initialForm = {
  name: "",
  title: "",
  avatar: "",
  bio: "",
  rating: 4.8,
  yearsExperience: 3,
  responseTimeMinutes: 30,
  city: "Dubai",
  languages: "English, Arabic",
  specialties: "",
  badges: "",
  serviceIds: [],
  isAutoAssignable: true,
  isActive: true,
};

const Professionals = () => {
  const context = useContext(MyContext);
  const [items, setItems] = useState([]);
  const [services, setServices] = useState([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState("");
  const [form, setForm] = useState(initialForm);

  const loadData = async () => {
    const [professionalRes, serviceRes] = await Promise.all([
      fetchDataFromApi("/api/professionals?limit=100"),
      fetchDataFromApi("/api/product/getAllProducts?page=1&limit=250&includeTotal=false"),
    ]);

    setItems(Array.isArray(professionalRes?.data) ? professionalRes.data : []);
    setServices(Array.isArray(serviceRes?.products) ? serviceRes.products : []);
  };

  useEffect(() => {
    loadData();
  }, []);

  const resetForm = () => {
    setEditingId("");
    setForm(initialForm);
  };

  const openCreateDialog = () => {
    resetForm();
    setDialogOpen(true);
  };

  const openEditDialog = (item) => {
    setEditingId(item._id);
    setForm({
      name: item.name || "",
      title: item.title || "",
      avatar: item.avatar || "",
      bio: item.bio || "",
      rating: item.rating || 4.8,
      yearsExperience: item.yearsExperience || 3,
      responseTimeMinutes: item.responseTimeMinutes || 30,
      city: item.city || "Dubai",
      languages: Array.isArray(item.languages) ? item.languages.join(", ") : "",
      specialties: Array.isArray(item.specialties) ? item.specialties.join(", ") : "",
      badges: Array.isArray(item.badges) ? item.badges.join(", ") : "",
      serviceIds: Array.isArray(item.serviceIds) ? item.serviceIds : [],
      isAutoAssignable: item.isAutoAssignable !== false,
      isActive: item.isActive !== false,
    });
    setDialogOpen(true);
  };

  const saveItem = async () => {
    const normalizeList = (value) =>
      String(value || "")
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean);

    const payload = {
      ...form,
      languages: normalizeList(form.languages),
      specialties: normalizeList(form.specialties),
      badges: normalizeList(form.badges),
    };

    const response = editingId
      ? await editData(`/api/professionals/${editingId}`, payload)
      : await postData("/api/professionals", payload);

    const responseData = response?.data || response;

    if (responseData?.error === false || responseData?.success) {
      context?.alertBox("success", responseData?.message || "Professional saved");
      setDialogOpen(false);
      resetForm();
      loadData();
    } else {
      context?.alertBox("error", responseData?.message || "Unable to save professional");
    }
  };

  const removeItem = async (id) => {
    const response = await deleteData(`/api/professionals/${id}`);

    if (response?.error === false || response?.success) {
      context?.alertBox("success", response?.message || "Professional deleted");
      loadData();
      return;
    }

    context?.alertBox("error", response?.message || "Unable to delete professional");
  };

  return (
    <div className="card my-4 shadow-md sm:rounded-lg bg-white p-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-[22px] font-[700] text-[#1f2937]">Professionals</h2>
          <p className="mt-1 text-[13px] text-gray-500">
            Control who appears in the booking flow and auto-assignment pool.
          </p>
        </div>
        <Button className="btn-blue !text-white" onClick={openCreateDialog}>
          Add Professional
        </Button>
      </div>

      <TableContainer className="mt-5">
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Professional</TableCell>
              <TableCell>Experience</TableCell>
              <TableCell>Rating</TableCell>
              <TableCell>Response time</TableCell>
              <TableCell>Status</TableCell>
              <TableCell align="right">Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {items.map((item) => (
              <TableRow key={item._id}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <img
                      src={item.avatar || "/user.jpg"}
                      alt={item.name}
                      className="h-12 w-12 rounded-full object-cover"
                    />
                    <div>
                      <p className="font-[700] text-[#1f2937]">{item.name}</p>
                      <p className="text-[12px] text-gray-500">{item.title}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell>{item.yearsExperience} years</TableCell>
                <TableCell>{item.rating}</TableCell>
                <TableCell>{item.responseTimeMinutes} mins</TableCell>
                <TableCell>{item.isActive === false ? "Inactive" : "Active"}</TableCell>
                <TableCell align="right">
                  <div className="flex items-center justify-end gap-2">
                    <Button
                      className="!min-w-[38px] !w-[38px] !h-[38px] !rounded-full !bg-[#f8fafc]"
                      onClick={() => openEditDialog(item)}
                    >
                      <AiOutlineEdit className="text-[18px]" />
                    </Button>
                    <Button
                      className="!min-w-[38px] !w-[38px] !h-[38px] !rounded-full !bg-[#fff1f2]"
                      onClick={() => removeItem(item._id)}
                    >
                      <GoTrash className="text-[18px]" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
            {!items.length && (
              <TableRow>
                <TableCell colSpan={6}>
                  <div className="py-12 text-center text-[14px] text-gray-500">
                    No professionals added yet.
                  </div>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>{editingId ? "Edit Professional" : "Create Professional"}</DialogTitle>
        <DialogContent className="!pt-4">
          <div className="grid gap-4 md:grid-cols-2">
            <TextField
              label="Name"
              value={form.name}
              onChange={(event) => setForm((prev) => ({ ...prev, name: event.target.value }))}
            />
            <TextField
              label="Title"
              value={form.title}
              onChange={(event) => setForm((prev) => ({ ...prev, title: event.target.value }))}
            />
            <TextField
              label="Avatar URL"
              value={form.avatar}
              onChange={(event) => setForm((prev) => ({ ...prev, avatar: event.target.value }))}
            />
            <TextField
              label="City"
              value={form.city}
              onChange={(event) => setForm((prev) => ({ ...prev, city: event.target.value }))}
            />
            <TextField
              label="Rating"
              type="number"
              value={form.rating}
              onChange={(event) => setForm((prev) => ({ ...prev, rating: event.target.value }))}
            />
            <TextField
              label="Years of experience"
              type="number"
              value={form.yearsExperience}
              onChange={(event) => setForm((prev) => ({ ...prev, yearsExperience: event.target.value }))}
            />
            <TextField
              label="Response time (minutes)"
              type="number"
              value={form.responseTimeMinutes}
              onChange={(event) => setForm((prev) => ({ ...prev, responseTimeMinutes: event.target.value }))}
            />
            <TextField
              label="Languages"
              value={form.languages}
              onChange={(event) => setForm((prev) => ({ ...prev, languages: event.target.value }))}
              placeholder="English, Arabic"
            />
            <TextField
              label="Specialties"
              value={form.specialties}
              onChange={(event) => setForm((prev) => ({ ...prev, specialties: event.target.value }))}
              placeholder="Nails, Facial, Waxing"
              className="md:col-span-2"
            />
            <TextField
              label="Badges"
              value={form.badges}
              onChange={(event) => setForm((prev) => ({ ...prev, badges: event.target.value }))}
              placeholder="Top rated, Fast response"
              className="md:col-span-2"
            />
            <TextField
              label="Bio"
              multiline
              minRows={3}
              value={form.bio}
              onChange={(event) => setForm((prev) => ({ ...prev, bio: event.target.value }))}
              className="md:col-span-2"
            />

            <FormControl className="md:col-span-2">
              <InputLabel>Services</InputLabel>
              <Select
                multiple
                value={form.serviceIds}
                label="Services"
                onChange={(event) => setForm((prev) => ({ ...prev, serviceIds: event.target.value }))}
                renderValue={(selected) =>
                  services
                    .filter((item) => selected.includes(item._id))
                    .map((item) => item.name)
                    .join(", ")
                }
              >
                {services.map((service) => (
                  <MenuItem key={service._id} value={service._id}>
                    <Checkbox checked={form.serviceIds.includes(service._id)} />
                    <ListItemText primary={service.name} />
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <div className="flex items-center justify-between rounded-xl border px-4 py-3">
              <span className="text-[14px] font-[600]">Auto assign enabled</span>
              <Switch
                checked={form.isAutoAssignable}
                onChange={(event) => setForm((prev) => ({ ...prev, isAutoAssignable: event.target.checked }))}
              />
            </div>
            <div className="flex items-center justify-between rounded-xl border px-4 py-3">
              <span className="text-[14px] font-[600]">Active</span>
              <Switch
                checked={form.isActive}
                onChange={(event) => setForm((prev) => ({ ...prev, isActive: event.target.checked }))}
              />
            </div>
          </div>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={saveItem}>
            Save Professional
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default Professionals;
