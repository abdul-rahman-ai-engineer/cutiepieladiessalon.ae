import React, { useContext, useEffect, useMemo, useState } from "react";
import {
  Button,
  Checkbox,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  InputLabel,
  ListItemText,
  MenuItem,
  Select,
  Switch,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
} from "@mui/material";
import { AiOutlineEdit } from "react-icons/ai";
import { GoTrash } from "react-icons/go";
import { MyContext } from "../../App";
import { deleteData, deleteImages, editData, fetchDataFromApi, postData } from "../../utils/api";
import UploadBox from "../../Components/UploadBox";
import { IoMdClose } from "react-icons/io";

const buildFlatCategories = (categories = []) => {
  const rows = [];

  const visit = (items = [], prefix = "") => {
    items.forEach((item) => {
      rows.push({
        _id: item._id,
        name: prefix ? `${prefix} / ${item.name}` : item.name,
      });
      if (item.children?.length) {
        visit(item.children, prefix ? `${prefix} / ${item.name}` : item.name);
      }
    });
  };

  visit(categories);
  return rows;
};

const initialForm = {
  name: "",
  description: "",
  image: "",
  durationMinutes: 15,
  price: 0,
  oldPrice: 0,
  badge: "",
  tags: "",
  categoryIds: [],
  serviceIds: [],
  isFeatured: false,
  isGlobal: false,
  isActive: true,
};

const AddOns = () => {
  const context = useContext(MyContext);
  const [items, setItems] = useState([]);
  const [services, setServices] = useState([]);
  const [categories, setCategories] = useState([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState("");
  const [form, setForm] = useState(initialForm);
  const [imagePreviews, setImagePreviews] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isImageUploading, setIsImageUploading] = useState(false);

  const categoryOptions = useMemo(() => buildFlatCategories(categories), [categories]);

  const loadData = async () => {
    setLoading(true);
    const [addOnRes, serviceRes, categoryRes] = await Promise.all([
      fetchDataFromApi("/api/addons?limit=100"),
      fetchDataFromApi("/api/product/getAllProducts?page=1&limit=250&includeTotal=false"),
      fetchDataFromApi("/api/category"),
    ]);

    setItems(Array.isArray(addOnRes?.data) ? addOnRes.data : []);
    setServices(Array.isArray(serviceRes?.products) ? serviceRes.products : []);
    setCategories(Array.isArray(categoryRes?.data) ? categoryRes.data : []);
    setLoading(false);
  };

  useEffect(() => {
    loadData();
  }, []);

  const resetForm = () => {
    setEditingId("");
    setForm(initialForm);
    setImagePreviews([]);
  };

  const openCreateDialog = () => {
    resetForm();
    setDialogOpen(true);
  };

  const openEditDialog = (item) => {
    setEditingId(item._id);
    setForm({
      name: item.name || "",
      description: item.description || "",
      image: item.image || "",
      durationMinutes: item.durationMinutes || 15,
      price: item.price || 0,
      oldPrice: item.oldPrice || 0,
      badge: item.badge || "",
      tags: Array.isArray(item.tags) ? item.tags.join(", ") : "",
      categoryIds: Array.isArray(item.categoryIds) ? item.categoryIds : [],
      serviceIds: Array.isArray(item.serviceIds) ? item.serviceIds : [],
      isFeatured: Boolean(item.isFeatured),
      isGlobal: Boolean(item.isGlobal),
      isActive: item.isActive !== false,
    });
    setImagePreviews(item.image ? [item.image] : []);
    setDialogOpen(true);
  };

  const setImagePreviewsFun = (previewsArr = []) => {
    const normalizedImages = Array.isArray(previewsArr) ? previewsArr.filter(Boolean) : [];
    setImagePreviews(normalizedImages);
    setForm((prev) => ({
      ...prev,
      image: normalizedImages[0] || "",
    }));
  };

  const removeImage = async (image, index) => {
    await deleteImages(`/api/addons/deteleImage?img=${image}`);
    setImagePreviews((prev) => prev.filter((_, itemIndex) => itemIndex !== index));
    setForm((prev) => ({
      ...prev,
      image: "",
    }));
  };

  const saveItem = async () => {
    if (!String(form.name || "").trim()) {
      context?.alertBox("error", "Please enter add-on name");
      return;
    }

    if (isImageUploading) {
      context?.alertBox("error", "Please wait for the image upload to finish");
      return;
    }

    setIsSaving(true);

    const payload = {
      ...form,
      tags: String(form.tags || "")
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean),
    };

    try {
      const response = editingId
        ? await editData(`/api/addons/${editingId}`, payload)
        : await postData("/api/addons", payload);

      const responseData = response?.data || response;

      if (responseData?.error === false || responseData?.success) {
        context?.alertBox("success", responseData?.message || "Add-on saved");
        setDialogOpen(false);
        resetForm();
        loadData();
      } else {
        context?.alertBox("error", responseData?.message || "Unable to save add-on");
      }
    } catch (error) {
      context?.alertBox("error", error?.response?.data?.message || error?.message || "Unable to save add-on");
    } finally {
      setIsSaving(false);
    }
  };

  const removeItem = async (id) => {
    const response = await deleteData(`/api/addons/${id}`);
    if (response?.error === false || response?.success) {
      context?.alertBox("success", response?.message || "Add-on deleted");
      loadData();
      return;
    }

    context?.alertBox("error", response?.message || "Unable to delete add-on");
  };

  return (
    <div className="card my-4 shadow-md sm:rounded-lg bg-white p-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-[22px] font-[700] text-[#1f2937]">Add-ons</h2>
          <p className="mt-1 text-[13px] text-gray-500">
            Manage optional upgrades that can be attached to salon services.
          </p>
        </div>
        <Button className="btn-blue !text-white" onClick={openCreateDialog}>
          Add Add-on
        </Button>
      </div>

      <TableContainer className="mt-5">
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Duration</TableCell>
              <TableCell>Price</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Visibility</TableCell>
              <TableCell align="right">Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {!loading && items.map((item) => (
              <TableRow key={item._id}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <img
                      src={item.image || "/icon.svg"}
                      alt={item.name}
                      className="h-12 w-12 rounded-xl object-cover"
                    />
                    <div>
                      <p className="font-[700] text-[#1f2937]">{item.name}</p>
                      <p className="text-[12px] text-gray-500">{item.description}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell>{item.durationMinutes} mins</TableCell>
                <TableCell>AED {Number(item.price || 0).toFixed(2)}</TableCell>
                <TableCell>{item.isActive === false ? "Inactive" : "Active"}</TableCell>
                <TableCell>{item.isGlobal ? "Global" : "Service linked"}</TableCell>
                <TableCell align="right">
                  <div className="flex items-center justify-end gap-2">
                    <Button
                      className="!min-w-[38px] !w-[38px] !h-[38px] !rounded-full !bg-[#f8fafc]"
                      onClick={() => openEditDialog(item)}
                    >
                      <AiOutlineEdit className="text-[18px]" />
                    </Button>
                    <Button
                      className="!min-w-[38px] !w-[38px] !h-[38px] !rounded-full !bg-[#fff1f2]"
                      onClick={() => removeItem(item._id)}
                    >
                      <GoTrash className="text-[18px]" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
            {!loading && !items.length && (
              <TableRow>
                <TableCell colSpan={6}>
                  <div className="py-12 text-center text-[14px] text-gray-500">
                    No add-ons found yet.
                  </div>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>{editingId ? "Edit Add-on" : "Create Add-on"}</DialogTitle>
        <DialogContent className="!pt-4">
          <div className="grid gap-4 md:grid-cols-2">
            <TextField
              label="Name"
              value={form.name}
              onChange={(event) => setForm((prev) => ({ ...prev, name: event.target.value }))}
            />
            <TextField
              label="Badge"
              value={form.badge}
              onChange={(event) => setForm((prev) => ({ ...prev, badge: event.target.value }))}
            />
            <TextField
              label="Tags"
              value={form.tags}
              onChange={(event) => setForm((prev) => ({ ...prev, tags: event.target.value }))}
              placeholder="hydration, massage, prep"
            />
            <div className="md:col-span-2">
              <h3 className="mb-2 text-[14px] font-[600] text-[#1f2937]">Add-on Image</h3>
              <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
                {imagePreviews.map((image, index) => (
                  <div className="uploadBoxWrapper relative" key={image}>
                    <span
                      className="absolute -right-[5px] -top-[5px] z-50 flex h-[20px] w-[20px] cursor-pointer items-center justify-center overflow-hidden rounded-full bg-red-700"
                      onClick={() => removeImage(image, index)}
                    >
                      <IoMdClose className="text-[17px] text-white" />
                    </span>

                    <div className="uploadBox relative flex h-[150px] w-full cursor-pointer flex-col items-center justify-center overflow-hidden rounded-md border border-dashed border-[rgba(0,0,0,0.3)] bg-gray-100 p-0">
                      <img src={image} alt="Add-on" className="h-full w-full object-cover" />
                    </div>
                  </div>
                ))}

                {!imagePreviews.length && (
                  <UploadBox
                    multiple={false}
                    name="images"
                    url="/api/product/uploadImages"
                    setPreviewsFun={setImagePreviewsFun}
                    onUploadingChange={setIsImageUploading}
                  />
                )}
              </div>
            </div>
            <TextField
              label="Duration (minutes)"
              type="number"
              value={form.durationMinutes}
              onChange={(event) => setForm((prev) => ({ ...prev, durationMinutes: event.target.value }))}
            />
            <TextField
              label="Price"
              type="number"
              value={form.price}
              onChange={(event) => setForm((prev) => ({ ...prev, price: event.target.value }))}
            />
            <TextField
              label="Old Price"
              type="number"
              value={form.oldPrice}
              onChange={(event) => setForm((prev) => ({ ...prev, oldPrice: event.target.value }))}
            />
            <TextField
              label="Description"
              multiline
              minRows={3}
              value={form.description}
              onChange={(event) => setForm((prev) => ({ ...prev, description: event.target.value }))}
              className="md:col-span-2"
            />

            <FormControl className="md:col-span-2">
              <InputLabel>Categories</InputLabel>
              <Select
                multiple
                value={form.categoryIds}
                label="Categories"
                onChange={(event) => setForm((prev) => ({ ...prev, categoryIds: event.target.value }))}
                renderValue={(selected) =>
                  categoryOptions
                    .filter((item) => selected.includes(item._id))
                    .map((item) => item.name)
                    .join(", ")
                }
              >
                {categoryOptions.map((category) => (
                  <MenuItem key={category._id} value={category._id}>
                    <Checkbox checked={form.categoryIds.includes(category._id)} />
                    <ListItemText primary={category.name} />
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl className="md:col-span-2">
              <InputLabel>Services</InputLabel>
              <Select
                multiple
                value={form.serviceIds}
                label="Services"
                onChange={(event) => setForm((prev) => ({ ...prev, serviceIds: event.target.value }))}
                renderValue={(selected) =>
                  services
                    .filter((item) => selected.includes(item._id))
                    .map((item) => item.name)
                    .join(", ")
                }
              >
                {services.map((service) => (
                  <MenuItem key={service._id} value={service._id}>
                    <Checkbox checked={form.serviceIds.includes(service._id)} />
                    <ListItemText primary={service.name} />
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <div className="flex items-center justify-between rounded-xl border px-4 py-3">
              <span className="text-[14px] font-[600]">Active</span>
              <Switch
                checked={form.isActive}
                onChange={(event) => setForm((prev) => ({ ...prev, isActive: event.target.checked }))}
              />
            </div>
            <div className="flex items-center justify-between rounded-xl border px-4 py-3">
              <span className="text-[14px] font-[600]">Featured</span>
              <Switch
                checked={form.isFeatured}
                onChange={(event) => setForm((prev) => ({ ...prev, isFeatured: event.target.checked }))}
              />
            </div>
            <div className="flex items-center justify-between rounded-xl border px-4 py-3 md:col-span-2">
              <span className="text-[14px] font-[600]">Show on all services</span>
              <Switch
                checked={form.isGlobal}
                onChange={(event) => setForm((prev) => ({ ...prev, isGlobal: event.target.checked }))}
              />
            </div>
          </div>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={saveItem} disabled={isSaving || isImageUploading}>
            Save Add-on
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default AddOns;
