import { useContext, useEffect, useState } from "react";
import { Button } from "@mui/material";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import { FaPlus } from "react-icons/fa6";
import DashboardBoxes from "../../Components/DashboardBoxes";
import Products from "../Products";
import { MyContext } from "../../App";
import { fetchDataFromApi } from "../../utils/api";

const Dashboard = () => {
  const context = useContext(MyContext);
  const [chartData, setChartData] = useState([]);
  const [stats, setStats] = useState({
    bookings: 0,
    products: 0,
    users: 0,
    reviews: 0,
  });

  useEffect(() => {
    context?.setProgress(30);

    fetchDataFromApi("/api/product/getAllProductsCount").then((res) => {
      setStats((prev) => ({
        ...prev,
        products: Number(res?.productCount ?? 0),
      }));
    });

    fetchDataFromApi("/api/bookings/count").then((res) => {
      setStats((prev) => ({
        ...prev,
        bookings: Number(res?.count ?? 0),
      }));
    });

    fetchDataFromApi("/api/user/getAllUsers").then((res) => {
      setStats((prev) => ({
        ...prev,
        users: Array.isArray(res?.users) ? res.users.length : 0,
      }));
    });

    fetchDataFromApi("/api/user/getAllReviews").then((res) => {
      setStats((prev) => ({
        ...prev,
        reviews: Array.isArray(res?.reviews) ? res.reviews.length : 0,
      }));
    });

    fetchDataFromApi("/api/order/sales").then((res) => {
      const monthlySales = Array.isArray(res?.monthlySales) ? res.monthlySales : [];
      setChartData(
        monthlySales.map((item) => ({
          name: item?.name || "",
          TotalSales: Number(item?.TotalSales ?? 0),
        }))
      );
      context?.setProgress(100);
    });
  }, [context]);

  return (
    <>
      <div className="w-full py-4 lg:py-1 px-5 border bg-[#f1faff] border-[rgba(0,0,0,0.1)] flex items-center gap-8 mb-5 justify-between rounded-md">
        <div className="info">
          <h1 className="text-[26px] lg:text-[35px] font-bold leading-8 lg:leading-10 mb-3">
            Welcome,
            <br />
            <span className="text-primary">{context?.userData?.name || "Admin"}</span>
          </h1>
          <p>Manage services, bookings, professionals, and home content from one place.</p>
          <br />
          <Button
            className="btn-blue btn !capitalize"
            onClick={() =>
              context.setIsOpenFullScreenPanel({
                open: true,
                model: "Add Service",
              })
            }
          >
            <FaPlus /> Add Service
          </Button>
        </div>

        <img src="/shop-illustration.webp" className="w-[250px] hidden lg:block" />
      </div>

      <DashboardBoxes
        bookings={stats.bookings}
        products={stats.products}
        users={stats.users}
        reviews={stats.reviews}
        category={Array.isArray(context?.catData) ? context.catData.length : 0}
      />

      <div className="card my-4 shadow-md sm:rounded-lg bg-white">
        <div className="flex items-center justify-between px-5 py-5 pb-0">
          <h2 className="text-[18px] font-[600]">Monthly Sales</h2>
        </div>

        <div className="px-5 py-5 overflow-x-auto">
          {chartData.length > 0 ? (
            <BarChart
              width={context?.windowWidth > 920 ? context.windowWidth - 350 : 800}
              height={400}
              data={chartData}
              margin={{ top: 5, right: 5, left: 5, bottom: 5 }}
            >
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Legend />
              <CartesianGrid strokeDasharray="3 3" horizontal={false} vertical={false} />
              <Bar dataKey="TotalSales" fill="#16a34a" />
            </BarChart>
          ) : (
            <div className="py-8 text-[14px] text-gray-500">No sales data available.</div>
          )}
        </div>
      </div>

      <Products />
    </>
  );
};

export default Dashboard;
