import { Router } from "express";
import auth from "../middlewares/auth.js";
import adminAuth from "../middlewares/adminAuth.js";
import upload from "../middlewares/multer.js";
import { removeImageFromCloudinary } from "../controllers/category.controller.js";
import {
    createAddOn,
    deleteAddOn,
    getAddOn,
    listAddOns,
    uploadImages,
    updateAddOn,
} from "../controllers/addon.controller.js";

const addOnRouter = Router();

addOnRouter.get("/", listAddOns);
addOnRouter.get("/:id", getAddOn);
addOnRouter.post("/uploadImages", auth, adminAuth, upload.array("images"), uploadImages);
addOnRouter.post("/", auth, adminAuth, createAddOn);
addOnRouter.put("/:id", auth, adminAuth, updateAddOn);
addOnRouter.delete("/deteleImage", auth, adminAuth, removeImageFromCloudinary);
addOnRouter.delete("/:id", auth, adminAuth, deleteAddOn);

export default addOnRouter;
