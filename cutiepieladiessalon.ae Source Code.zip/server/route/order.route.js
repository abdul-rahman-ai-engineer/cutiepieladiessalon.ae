import { Router } from "express";
import auth from "../middlewares/auth.js";
import adminAuth from "../middlewares/adminAuth.js";
import { captureOrderPaypalController, createOrderController, createOrderPaypalController, createOrderTamaraController, deleteOrder, finalizeTamaraOrderController, getOrderDetailsController, getTotalOrdersCountController, getUserOrderDetailsController, totalSalesController, totalUsersController, updateOrderStatusController } from "../controllers/order.controller.js";

const orderRouter = Router();

orderRouter.post('/create',auth,createOrderController)
orderRouter.get("/order-list",auth,adminAuth,getOrderDetailsController)
orderRouter.get('/create-order-paypal',auth,createOrderPaypalController)
orderRouter.post('/create-order-tamara',auth,createOrderTamaraController)
orderRouter.post('/finalize-tamara',auth,finalizeTamaraOrderController)
orderRouter.post('/capture-order-paypal',auth,captureOrderPaypalController)
orderRouter.put('/order-status/:id',auth,adminAuth,updateOrderStatusController)
orderRouter.get('/count',auth,adminAuth,getTotalOrdersCountController)
orderRouter.get('/sales',auth,adminAuth,totalSalesController)
orderRouter.get('/users',auth,adminAuth,totalUsersController)
orderRouter.get('/order-list/orders',auth,getUserOrderDetailsController)
orderRouter.delete('/deleteOrder/:id',auth,adminAuth,deleteOrder)

export default orderRouter;
