import { Router } from "express";
import auth from "../middlewares/auth.js";
import adminAuth from "../middlewares/adminAuth.js";
import {
    createBookingController,
    createBookingTamaraCheckoutController,
    getAdminBookingsController,
    getBookingsCountController,
    getMyBookingsController,
    getSingleBookingController,
    getTamaraBookingConfigController,
    finalizeTamaraBookingController,
    quoteBookingController,
    tamaraBookingWebhookController,
    updateBookingStatusController,
} from "../controllers/booking.controller.js";

const bookingRouter = Router();

bookingRouter.post("/quote", quoteBookingController);
bookingRouter.get("/tamara/config", getTamaraBookingConfigController);
bookingRouter.post("/tamara/webhook", tamaraBookingWebhookController);
bookingRouter.post("/tamara/checkout", auth, createBookingTamaraCheckoutController);
bookingRouter.post("/tamara/finalize", auth, finalizeTamaraBookingController);
bookingRouter.get("/count", auth, adminAuth, getBookingsCountController);
bookingRouter.post("/create-order-tamara", auth, createBookingTamaraCheckoutController);
bookingRouter.post("/finalize-tamara", auth, finalizeTamaraBookingController);
bookingRouter.post("/", auth, createBookingController);
bookingRouter.get("/", auth, adminAuth, getAdminBookingsController);
bookingRouter.get("/mine", auth, getMyBookingsController);
bookingRouter.get("/admin", auth, adminAuth, getAdminBookingsController);
bookingRouter.get("/:id", auth, getSingleBookingController);
bookingRouter.put("/:id/status", auth, adminAuth, updateBookingStatusController);

export default bookingRouter;
