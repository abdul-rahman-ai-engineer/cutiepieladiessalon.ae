import { Router } from "express";
import auth from "../middlewares/auth.js";
import adminAuth from "../middlewares/adminAuth.js";
import {
    createProfessional,
    deleteProfessional,
    getProfessional,
    listProfessionals,
    updateProfessional,
} from "../controllers/professional.controller.js";

const professionalRouter = Router();

professionalRouter.get("/", listProfessionals);
professionalRouter.get("/:id", getProfessional);
professionalRouter.post("/", auth, adminAuth, createProfessional);
professionalRouter.put("/:id", auth, adminAuth, updateProfessional);
professionalRouter.delete("/:id", auth, adminAuth, deleteProfessional);

export default professionalRouter;
