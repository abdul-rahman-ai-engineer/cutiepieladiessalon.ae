import { Router } from "express";
import {
    getServiceBookingExperience,
    getServiceById,
    getServiceHomePayload,
    listServices,
} from "../controllers/service.controller.js";

const serviceRouter = Router();

serviceRouter.get("/", listServices);
serviceRouter.get("/home", getServiceHomePayload);
serviceRouter.get("/:id", getServiceById);
serviceRouter.get("/:id/booking", getServiceBookingExperience);

export default serviceRouter;
