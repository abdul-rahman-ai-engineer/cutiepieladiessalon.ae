import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
dotenv.config();
import cookieParser from 'cookie-parser'
import morgan from 'morgan';
import helmet from 'helmet';
import path from 'path';
import { fileURLToPath } from 'url';
import connectDB from './config/connectDb.js';
import userRouter from './route/user.route.js'
import categoryRouter from './route/category.route.js';
import productRouter from './route/product.route.js';
import cartRouter from './route/cart.route.js';
import myListRouter from './route/mylist.route.js';
import addressRouter from './route/address.route.js';
import homeSlidesRouter from './route/homeSlides.route.js';
import bannerV1Router from './route/bannerV1.route.js';
import bannerList2Router from './route/bannerList2.route.js';
import blogRouter from './route/blog.route.js';
import orderRouter from './route/order.route.js';
import logoRouter from './route/logo.route.js';
import addOnRouter from './route/addon.route.js';
import professionalRouter from './route/professional.route.js';
import bookingRouter from './route/booking.route.js';
import serviceRouter from './route/service.route.js';


const app = express();
const port = Number(process.env.PORT) || 3000;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const frontendDistDir = path.resolve(__dirname, '../frontend/dist');
const backendDistDir = path.resolve(__dirname, '../backend/dist');
const frontendDevUrl = (process.env.FRONTEND_DEV_URL || 'http://localhost:5173').replace(/\/+$/, '');
const adminDevUrl = (process.env.ADMIN_DEV_URL || 'http://localhost:5174').replace(/\/+$/, '');
const isProduction = process.env.NODE_ENV === 'production';
const localHostNames = new Set(['localhost', '127.0.0.1', '::1']);
const frontendHostNames = new Set([
    'cutiepieladiessalon.ae',
    'www.cutiepieladiessalon.ae',
    
]);
const adminHostNames = new Set([
    'server.cutiepieladiessalon.ae',
]);
const apiHostNames = new Set([
    'backend.cutiepieladiessalon.ae',
]);
const developmentAllowedOrigins = [
    'http://localhost:3000',
    'http://localhost:3001',
    'http://localhost:5173',
    'http://localhost:5174',
    'http://localhost:5175',
    'http://127.0.0.1:3000',
    'http://127.0.0.1:3001',
    'http://127.0.0.1:5173',
    'http://127.0.0.1:5174',
    'http://127.0.0.1:5175',
];
const productionAllowedOrigins = [
    'https://cutiepieladiessalon.ae',
    'https://www.cutiepieladiessalon.ae',
    'https://backend.cutiepieladiessalon.ae',
    'https://server.cutiepieladiessalon.ae',
];
const defaultAllowedOrigins = isProduction
    ? productionAllowedOrigins
    : [...developmentAllowedOrigins, ...productionAllowedOrigins];

const configuredAllowedOrigins = (process.env.CORS_ORIGINS || process.env.CORS_ORIGIN || '')
    .split(',')
    .map((origin) => origin.trim())
    .filter(Boolean);

const allowedOrigins = configuredAllowedOrigins.length > 0
    ? Array.from(new Set([...defaultAllowedOrigins, ...configuredAllowedOrigins]))
    : defaultAllowedOrigins;

const effectiveAllowedOrigins = Array.from(new Set([
    'https://cutiepieladiessalon.ae',
    'https://www.cutiepieladiessalon.ae',
    'https://backend.cutiepieladiessalon.ae',
    'https://server.cutiepieladiessalon.ae',
    ...allowedOrigins,
    ...developmentAllowedOrigins,
]));

const serveFrontendStatic = express.static(frontendDistDir);
const serveAdminStatic = express.static(backendDistDir);

const getRequestHostName = (request) => {
    const forwardedHost = request.headers['x-forwarded-host'];
    const hostHeader = Array.isArray(forwardedHost) ? forwardedHost[0] : (forwardedHost || request.headers.host || '');
    return hostHeader.split(',')[0].trim().split(':')[0].toLowerCase();
};

const isLocalRequest = (request) => {
    return localHostNames.has(getRequestHostName(request));
};

const wantsHtml = (request) => {
    const acceptHeader = request.headers.accept || '';
    return acceptHeader.includes('text/html');
};

const isFrontendHost = (request) => frontendHostNames.has(getRequestHostName(request));
const isAdminHost = (request) => adminHostNames.has(getRequestHostName(request));
const isApiHost = (request) => apiHostNames.has(getRequestHostName(request));

const sendSpaIndex = (response, distDir, next) => {
    return response.sendFile(path.join(distDir, 'index.html'), (error) => {
        if (error && next) {
            next();
        }
    });
};


const corsOptions = {
    origin(origin, callback) {
        // Allow non-browser requests and configured frontend origins.
        if (!origin || effectiveAllowedOrigins.includes(origin)) {
            return callback(null, true);
        }

        return callback(new Error(`CORS blocked for origin: ${origin}`));
    },
    credentials: true,
};

app.use(cors(corsOptions));
app.options('*', cors(corsOptions))



app.use(express.json({ limit: '200mb' }))
app.use(cookieParser())
// app.use(morgan())
app.use(helmet({
    crossOriginResourcePolicy: false
}))


app.get("/api/health", (request, response) => {
    response.json({
        message: "Server is running " + port
    });
});

app.get("/admin", (request, response) => {
    if (isLocalRequest(request) && wantsHtml(request)) {
        return response.redirect(`${adminDevUrl}/login`);
    }

    return response.redirect('/admin/');
});

app.use('/admin', express.static(backendDistDir));

app.get('/admin/*', (request, response, next) => {
    if (isLocalRequest(request) && wantsHtml(request)) {
        return response.redirect(`${adminDevUrl}${request.path.replace(/^\/admin/, '') || '/'}`);
    }

    return response.sendFile(path.join(backendDistDir, 'index.html'), (error) => {
        if (error) {
            next();
        }
    });
});

app.use((request, response, next) => {
    if (request.path.startsWith('/api/')) {
        return next();
    }

    if (isAdminHost(request)) {
        return serveAdminStatic(request, response, next);
    }

    if (isApiHost(request)) {
        return next();
    }

    return serveFrontendStatic(request, response, next);
});

app.get("/", (request, response, next) => {
    if (isLocalRequest(request) && wantsHtml(request)) {
        return response.redirect(frontendDevUrl);
    }

    if (isAdminHost(request)) {
        return sendSpaIndex(response, backendDistDir, next);
    }

    if (isApiHost(request)) {
        return response.json({
            message: "Server is running " + port
        });
    }

    return response.sendFile(path.join(frontendDistDir, 'index.html'), (error) => {
        if (error) {
            response.json({
                message: "Server is running " + port
            });
        }
    });
});


app.use('/api/user',userRouter)
app.use('/api/category',categoryRouter)
app.use('/api/product',productRouter);
app.use('/api/products',productRouter);
app.use("/api/cart",cartRouter)
app.use("/api/myList",myListRouter)
app.use("/api/address",addressRouter)
app.use("/api/homeSlides",homeSlidesRouter)
app.use("/api/bannerV1",bannerV1Router)
app.use("/api/bannerList2",bannerList2Router)
app.use("/api/blog",blogRouter)
app.use("/api/order",orderRouter)
app.use("/api/logo",logoRouter)
app.use("/api/addons", addOnRouter)
app.use("/api/professionals", professionalRouter)
app.use("/api/bookings", bookingRouter)
app.use("/api/services", serviceRouter)

app.get('*', (request, response, next) => {
    if (request.path.startsWith('/api/')) {
        return next();
    }

    if (isLocalRequest(request) && wantsHtml(request)) {
        return response.redirect(`${frontendDevUrl}${request.path}`);
    }

    if (isAdminHost(request)) {
        return sendSpaIndex(response, backendDistDir, next);
    }

    if (isApiHost(request)) {
        return response.status(404).json({
            success: false,
            error: true,
            message: 'API route not found',
        });
    }

    return sendSpaIndex(response, frontendDistDir, next);
});


connectDB().then(() => {
    app.listen(port, () => {
        console.log("Server is running", port);
    })
})







