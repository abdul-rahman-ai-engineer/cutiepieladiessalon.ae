import ProfessionalModel from "../models/professional.model.js";
import { serializeProfessional } from "../utils/booking.utils.js";

const toIdList = (value) => {
    if (!Array.isArray(value)) return [];
    return value.filter(Boolean);
};

const toStringList = (value) => {
    if (!Array.isArray(value)) return [];
    return value.map((item) => String(item || "").trim()).filter(Boolean);
};

export const listProfessionals = async (request, response) => {
    try {
        const page = Math.max(1, Number.parseInt(request.query.page, 10) || 1);
        const limit = Math.min(100, Math.max(1, Number.parseInt(request.query.limit, 10) || 50));
        const search = String(request.query.search || "").trim();
        const serviceId = String(request.query.serviceId || "").trim();
        const categoryId = String(request.query.categoryId || "").trim();
        const activeOnly = String(request.query.activeOnly || "").toLowerCase() === "true";

        const filter = {};
        if (activeOnly) filter.isActive = true;
        if (serviceId) filter.serviceIds = serviceId;
        if (categoryId) filter.categoryIds = categoryId;
        if (search) {
            filter.$or = [
                { name: { $regex: search, $options: "i" } },
                { title: { $regex: search, $options: "i" } },
                { specialties: { $regex: search, $options: "i" } },
            ];
        }

        const [items, total] = await Promise.all([
            ProfessionalModel.find(filter)
                .sort({ sortOrder: 1, createdAt: -1 })
                .skip((page - 1) * limit)
                .limit(limit)
                .lean(),
            ProfessionalModel.countDocuments(filter),
        ]);

        return response.status(200).json({
            success: true,
            error: false,
            data: items.map(serializeProfessional),
            total,
            page,
            totalPages: Math.max(1, Math.ceil(total / limit)),
        });
    } catch (error) {
        return response.status(500).json({
            success: false,
            error: true,
            message: error.message || "Unable to load professionals",
        });
    }
};

export const getProfessional = async (request, response) => {
    try {
        const item = await ProfessionalModel.findById(request.params.id).lean();

        if (!item) {
            return response.status(404).json({
                success: false,
                error: true,
                message: "Professional not found",
            });
        }

        return response.status(200).json({
            success: true,
            error: false,
            data: serializeProfessional(item),
        });
    } catch (error) {
        return response.status(500).json({
            success: false,
            error: true,
            message: error.message || "Unable to load professional",
        });
    }
};

export const createProfessional = async (request, response) => {
    try {
        const document = await ProfessionalModel.create({
            name: request.body.name,
            title: request.body.title,
            avatar: request.body.avatar,
            bio: request.body.bio,
            rating: Number(request.body.rating || 4.8),
            reviewCount: Number(request.body.reviewCount || 0),
            yearsExperience: Number(request.body.yearsExperience || 3),
            responseTimeMinutes: Number(request.body.responseTimeMinutes || 30),
            city: request.body.city || "Dubai",
            languages: toStringList(request.body.languages),
            specialties: toStringList(request.body.specialties),
            badges: toStringList(request.body.badges),
            isAutoAssignable: request.body.isAutoAssignable !== false,
            isActive: request.body.isActive !== false,
            sortOrder: Number(request.body.sortOrder || 0),
            categoryIds: toIdList(request.body.categoryIds),
            serviceIds: toIdList(request.body.serviceIds),
            availabilityWindow: {
                startHour: Number(request.body?.availabilityWindow?.startHour || 10),
                endHour: Number(request.body?.availabilityWindow?.endHour || 22),
                intervalMinutes: Number(request.body?.availabilityWindow?.intervalMinutes || 30),
            },
        });

        return response.status(201).json({
            success: true,
            error: false,
            message: "Professional created successfully",
            data: serializeProfessional(document),
        });
    } catch (error) {
        return response.status(500).json({
            success: false,
            error: true,
            message: error.message || "Unable to create professional",
        });
    }
};

export const updateProfessional = async (request, response) => {
    try {
        const document = await ProfessionalModel.findByIdAndUpdate(
            request.params.id,
            {
                name: request.body.name,
                title: request.body.title,
                avatar: request.body.avatar,
                bio: request.body.bio,
                rating: Number(request.body.rating || 4.8),
                reviewCount: Number(request.body.reviewCount || 0),
                yearsExperience: Number(request.body.yearsExperience || 3),
                responseTimeMinutes: Number(request.body.responseTimeMinutes || 30),
                city: request.body.city || "Dubai",
                languages: toStringList(request.body.languages),
                specialties: toStringList(request.body.specialties),
                badges: toStringList(request.body.badges),
                isAutoAssignable: request.body.isAutoAssignable !== false,
                isActive: request.body.isActive !== false,
                sortOrder: Number(request.body.sortOrder || 0),
                categoryIds: toIdList(request.body.categoryIds),
                serviceIds: toIdList(request.body.serviceIds),
                availabilityWindow: {
                    startHour: Number(request.body?.availabilityWindow?.startHour || 10),
                    endHour: Number(request.body?.availabilityWindow?.endHour || 22),
                    intervalMinutes: Number(request.body?.availabilityWindow?.intervalMinutes || 30),
                },
            },
            { new: true }
        ).lean();

        if (!document) {
            return response.status(404).json({
                success: false,
                error: true,
                message: "Professional not found",
            });
        }

        return response.status(200).json({
            success: true,
            error: false,
            message: "Professional updated successfully",
            data: serializeProfessional(document),
        });
    } catch (error) {
        return response.status(500).json({
            success: false,
            error: true,
            message: error.message || "Unable to update professional",
        });
    }
};

export const deleteProfessional = async (request, response) => {
    try {
        const document = await ProfessionalModel.findByIdAndDelete(request.params.id).lean();

        if (!document) {
            return response.status(404).json({
                success: false,
                error: true,
                message: "Professional not found",
            });
        }

        return response.status(200).json({
            success: true,
            error: false,
            message: "Professional deleted successfully",
        });
    } catch (error) {
        return response.status(500).json({
            success: false,
            error: true,
            message: error.message || "Unable to delete professional",
        });
    }
};
