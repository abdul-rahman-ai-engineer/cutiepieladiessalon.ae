import AddressModel from "../models/address.model.js";
import UserModel from "../models/user.model.js";

const DUBAI_CITY = "Dubai";
const DUBAI_STATE = "Dubai";
const UAE_COUNTRY = "United Arab Emirates";
const DUBAI_ONLY_MESSAGE = "We currently operate only in Dubai.";

const createRequestError = (message, statusCode = 400) =>
    Object.assign(new Error(message), { statusCode });

const normalizeText = (value = "") => String(value ?? "").trim();

const sanitizePhoneNumber = (value) => {
    const digits = String(value ?? "").replace(/[^\d]/g, "").trim();
    return digits ? Number(digits) : null;
};

const sanitizeCoordinate = (value) => {
    const numericValue = Number(value);
    return Number.isFinite(numericValue) ? numericValue : null;
};

const normalizeAddressType = (value = "") => {
    const normalized = normalizeText(value).toLowerCase();

    if (normalized === "home") return "Home";
    if (normalized === "office" || normalized === "work") return "Work";
    if (normalized === "other") return "Other";

    return "Home";
};

const validateDubaiOnly = ({ city = "", state = "", country = "" }) => {
    const normalizedCity = normalizeText(city).toLowerCase();
    const normalizedState = normalizeText(state).toLowerCase();
    const normalizedCountry = normalizeText(country).toLowerCase();

    if (normalizedCity && normalizedCity !== "dubai") {
        throw createRequestError(DUBAI_ONLY_MESSAGE);
    }

    if (normalizedState && normalizedState !== "dubai") {
        throw createRequestError(DUBAI_ONLY_MESSAGE);
    }

    if (
        normalizedCountry &&
        normalizedCountry !== "united arab emirates" &&
        normalizedCountry !== "uae"
    ) {
        throw createRequestError(DUBAI_ONLY_MESSAGE);
    }
};

const buildAddressPayload = (payload = {}, userId = "") => {
    validateDubaiOnly(payload);

    return {
        address_line1: normalizeText(payload?.address_line1),
        city: DUBAI_CITY,
        state: DUBAI_STATE,
        pincode: normalizeText(payload?.pincode),
        country: UAE_COUNTRY,
        lat: sanitizeCoordinate(payload?.lat),
        lng: sanitizeCoordinate(payload?.lng),
        mobile: sanitizePhoneNumber(payload?.mobile),
        userId: String(userId || payload?.userId || ""),
        landmark: normalizeText(payload?.landmark),
        addressType: normalizeAddressType(payload?.addressType),
    };
};

// addAddressController

export const addAddressController = async (request, response) => {
    try {
        const userId = String(request.userId || request.body?.userId || "");
        const payload = buildAddressPayload(request.body, userId);

        if (!payload.address_line1) {
            return response.status(400).json({
                message: "Please provide the address or building name.",
                error: true,
                success: false,
            });
        }

        if (!payload.userId) {
            return response.status(400).json({
                message: "Unable to identify the current user.",
                error: true,
                success: false,
            });
        }

        const address = new AddressModel(payload);
        const savedAddress = await address.save();

        await UserModel.updateOne(
            { _id: payload.userId },
            {
                $push: {
                    address_details: savedAddress?._id,
                },
            }
        );

        return response.status(200).json({
            data: savedAddress,
            message: "Location added successfully",
            error: false,
            success: true,
        });
    } catch (error) {
        return response.status(error?.statusCode || 500).json({
            message: error.message || error,
            error: true,
            success: false,
        });
    }
};

// getAddressController

export const getAddressController = async (request, response) => {
    try {
        const userId = String(request.userId || request?.query?.userId || "");
        const address = await AddressModel.find({ userId });

        return response.status(200).json({
            error: false,
            success: true,
            data: address,
        });
    } catch (error) {
        return response.status(error?.statusCode || 500).json({
            message: error.message || error,
            error: true,
            success: false,
        });
    }
};

// deleteAddressController

export const deleteAddressController = async (request, response) => {
    try {
        const userId = String(request.userId || "");
        const _id = request.params.id;

        if (!_id) {
            return response.status(400).json({
                message: "Provide _id",
                error: true,
                success: false,
            });
        }

        const deleteItem = await AddressModel.deleteOne({ _id, userId });

        if (!deleteItem?.deletedCount) {
            return response.status(404).json({
                message: "The location was not found",
                error: true,
                success: false,
            });
        }

        await UserModel.updateOne(
            { _id: userId },
            {
                $pull: {
                    address_details: _id,
                },
            }
        );

        return response.json({
            message: "Location removed",
            error: false,
            success: true,
            data: deleteItem,
        });
    } catch (error) {
        return response.status(error?.statusCode || 500).json({
            message: error.message || error,
            error: true,
            success: false,
        });
    }
};

// getSingleAddressController

export const getSingleAddressController = async (request, response) => {
    try {
        const id = request.params.id;
        const userId = String(request.userId || "");

        const address = await AddressModel.findOne({ _id: id, userId });

        if (!address) {
            return response.status(404).json({
                message: "Location not found",
                error: true,
                success: false,
            });
        }

        return response.status(200).json({
            error: false,
            success: true,
            address,
        });
    } catch (error) {
        return response.status(error?.statusCode || 500).json({
            message: error.message || error,
            error: true,
            success: false,
        });
    }
};

// editAddress

export async function editAddress(request, response) {
    try {
        const id = request.params.id;
        const userId = String(request.userId || "");
        const payload = buildAddressPayload(request.body, userId);

        if (!payload.address_line1) {
            return response.status(400).json({
                message: "Please provide the address or building name.",
                error: true,
                success: false,
            });
        }

        const address = await AddressModel.findOneAndUpdate(
            { _id: id, userId },
            payload,
            { new: true }
        );

        if (!address) {
            return response.status(404).json({
                message: "Location not found",
                error: true,
                success: false,
            });
        }

        return response.json({
            message: "Location updated successfully",
            error: false,
            success: true,
            address,
        });
    } catch (error) {
        return response.status(error?.statusCode || 500).json({
            message: error.message || error,
            error: true,
            success: false,
        });
    }
}
