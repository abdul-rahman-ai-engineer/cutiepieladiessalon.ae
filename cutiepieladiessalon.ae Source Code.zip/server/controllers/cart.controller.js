import CartProductModel from "../models/cartProduct.modal.js";
import ProductModel from "../models/product.modal.js";
import { isServiceProduct } from "../utils/productType.utils.js";

const SERVICE_CART_MESSAGE = "Service items must be booked from the service page and cannot be added to the retail cart.";

const hydrateCartItems = async (cartItems = []) => {
    const productIds = Array.from(new Set(
        cartItems
            .map((item) => String(item?.productId || ""))
            .filter(Boolean)
    ));

    if (!productIds.length) {
        return cartItems;
    }

    const productDocs = await ProductModel.find({ _id: { $in: productIds } })
        .select("_id serviceType bookingEnabled catName subCat thirdsubCat")
        .lean();

    const productMap = new Map(productDocs.map((product) => [String(product._id), product]));

    return cartItems.map((item) => {
        const productDoc = productMap.get(String(item?.productId || ""));
        const inferredServiceType = productDoc
            ? (isServiceProduct(productDoc) ? "service" : "product")
            : item?.serviceType || "product";

        return {
            ...item,
            serviceType: inferredServiceType,
        };
    });
};

//addToCartItemController

export const addToCartItemController = async (request, response) => {
    try {
        const userId = request.userId //middleware
        const { productTitle, image, rating, price, oldPrice, quantity, subTotal, productId, countInStock, discount,size, weight, ram, brand } = request.body

        if (!productId) {
            return response.status(402).json({
                message: "Provide productId",
                error: true,
                success: false
            })
        }

        const productDoc = await ProductModel.findById(productId)
            .select("_id serviceType bookingEnabled catName subCat thirdsubCat")
            .lean();

        if (!productDoc) {
            return response.status(404).json({
                message: "Selected item was not found",
                error: true,
                success: false,
            });
        }

        if (isServiceProduct(productDoc)) {
            return response.status(400).json({
                message: SERVICE_CART_MESSAGE,
                error: true,
                success: false,
            });
        }


        const checkItemCart = await CartProductModel.findOne({
            userId: userId,
            productId: productId
        })

        if (checkItemCart) {
            return response.status(400).json({
                message: "Item already in cart"
            })
        }


        const cartItem = new CartProductModel({
            productTitle:productTitle,
            image:image,
            rating:rating,
            price:price,
            oldPrice:oldPrice,
            quantity:quantity,
            subTotal:subTotal,
            productId:productId,
            countInStock:countInStock,
            userId:userId,
            brand:brand,
            discount:discount,
            size:size,
            weight:weight,
            ram:ram,
            serviceType: "product",
        })

        const save = await cartItem.save();


        return response.status(200).json({
            data: save,
            message: "Item add successfully",
            error: false,
            success: true
        })


    } catch (error) {
        return response.status(500).json({
            message: error.message || error,
            error: true,
            success: false
        })
    }
}

//getCartItemController

export const getCartItemController = async (request, response) => {
    try {
        const userId = request.userId;

        const cartItems = await CartProductModel.find({
            userId: userId
        }).lean();

        const hydratedItems = await hydrateCartItems(cartItems);

        return response.json({
            data: hydratedItems,
            error: false,
            success: true
        })


    } catch (error) {
        return response.status(500).json({
            message: error.message || error,
            error: true,
            success: false
        })
    }
}

//updateCartItemQtyController

export const updateCartItemQtyController = async (request, response) => {
    try {

        const userId = request.userId
        const { _id, qty , subTotal, size, weight, ram} = request.body



        if (!_id || !qty) {
            return response.status(400).json({
                message: "provide _id, qty"
            })
        }

        const updateCartitem = await CartProductModel.updateOne(
            {
                _id: _id,
                userId: userId
            },
            {
                quantity: qty,
                subTotal:subTotal,
                size:size,
                ram:ram,
                weight:weight
            },
            { new: true }
        )


        return response.json({
            message: "Update cart item",
            success: true,
            error: false,
            data: updateCartitem
        })



    } catch (error) {
        return response.status(500).json({
            message: error.message || error,
            error: true,
            success: false
        })
    }
}

//deleteCartItemQtyController

export const deleteCartItemQtyController = async (request, response) => {
    try {
        const userId = request.userId // middleware
        const { id } = request.params


        if(!id){
            return response.status(400).json({
                message : "Provide _id",
                error : true,
                success : false
            })
          }


          const deleteCartItem  = await CartProductModel.deleteOne({_id : id, userId : userId })

          if(!deleteCartItem){
            return response.status(404).json({
                message:"The product in the cart is not found",
                error:true,
                success:false
            })
          }
         

          return response.status(200).json({
            message : "Item remove",
            error : false,
            success : true,
            data : deleteCartItem
          })


    } catch (error) {
        return response.status(500).json({
            message: error.message || error,
            error: true,
            success: false
        })
    }
}

//emptyCartController

export const emptyCartController = async (request, response) => {
    try {
        const userId = request.params.id // middlewar

        await CartProductModel.deleteMany({userId:userId })

          return response.status(200).json({
            error : false,
            success : true,
          })

    } catch (error) {
        return response.status(500).json({
            message: error.message || error,
            error: true,
            success: false
        })
    }
}
