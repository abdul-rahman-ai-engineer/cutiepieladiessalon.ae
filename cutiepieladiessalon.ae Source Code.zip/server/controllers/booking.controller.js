import axios from "axios";
import jwt from "jsonwebtoken";
import AddressModel from "../models/address.model.js";
import BookingModel from "../models/booking.model.js";
import OrderModel from "../models/order.model.js";
import ProfessionalModel from "../models/professional.model.js";
import ProductModel from "../models/product.modal.js";
import UserModel from "../models/user.model.js";
import {
    calculateBookingQuote,
    serializeProfessional,
} from "../utils/booking.utils.js";
import { isServiceProduct } from "../utils/productType.utils.js";

const defaultTamaraApiBaseUrl = "https://api.tamara.co";
const localHostNames = new Set(["localhost", "127.0.0.1", "::1"]);
const acceptedTamaraStatuses = new Set([
    "authorised",
    "authorized",
    "approved",
    "fully_captured",
    "partially_captured",
]);
const tamaraAuthorizedStatuses = new Set([
    "authorised",
    "authorized",
    "approved",
]);
const tamaraPaidStatuses = new Set([
    "fully_captured",
    "partially_captured",
]);
const tamaraFailedStatuses = new Set([
    "failed",
    "declined",
    "canceled",
    "cancelled",
    "expired",
]);
const DEFAULT_TAMARA_MIN_AMOUNT = 0;

const toAmount = (value) => Number(Number(value || 0).toFixed(2));

const buildAddressSnapshot = (address) => ({
    addressType: address?.addressType || "",
    addressLine1: address?.address_line1 || "",
    city: address?.city || "",
    state: address?.state || "",
    country: address?.country || "",
    landmark: address?.landmark || "",
    pincode: address?.pincode || "",
    mobile: String(address?.mobile || ""),
});

const splitCustomerName = (fullName = "") => {
    const normalized = String(fullName || "").trim().replace(/\s+/g, " ");

    if (!normalized) {
        return { firstName: "Customer", lastName: "User" };
    }

    const [firstName, ...rest] = normalized.split(" ");

    return {
        firstName,
        lastName: rest.join(" ") || "User",
    };
};

const normalizePhoneNumber = (phoneNumber) => String(phoneNumber ?? "")
    .replace(/[^\d]/g, "")
    .slice(0, 32);

const getCountryCode = (country = "") => {
    const normalized = String(country || "").toLowerCase();

    if (normalized.includes("united arab emirates") || normalized.includes("uae")) {
        return "AE";
    }

    if (normalized.includes("saudi")) {
        return "SA";
    }

    return "AE";
};

const getBaseSiteUrl = (request) => {
    const configuredUrl = (
        process.env.FRONTEND_URL
        || process.env.SITE_URL
        || process.env.PUBLIC_SITE_URL
        || request.headers.origin
        || "https://cutiepieladiessalon.ae"
    );

    const normalizedConfiguredUrl = configuredUrl.replace(/\/+$/, "");

    try {
        const parsedConfiguredUrl = new URL(normalizedConfiguredUrl);
        const requestOrigin = String(request.headers.origin || "").replace(/\/+$/, "");

        if (requestOrigin && localHostNames.has(parsedConfiguredUrl.hostname)) {
            const parsedRequestOrigin = new URL(requestOrigin);
            if (!localHostNames.has(parsedRequestOrigin.hostname)) {
                return requestOrigin;
            }
        }
    } catch {
        return normalizedConfiguredUrl;
    }

    return normalizedConfiguredUrl;
};

const getNumericEnvValue = (...keys) => {
    for (const key of keys) {
        const rawValue = process.env[key];

        if (rawValue === undefined || rawValue === null || rawValue === "") {
            continue;
        }

        const numericValue = Number(rawValue);
        if (Number.isFinite(numericValue)) {
            return numericValue;
        }
    }

    return null;
};

const getTamaraSettings = () => {
    const tamaraApiToken = process.env.TAMARA_API_TOKEN || "";
    const tamaraApiBaseUrl = (process.env.TAMARA_API_BASE_URL || defaultTamaraApiBaseUrl).replace(/\/+$/, "");
    const tamaraNotificationToken = process.env.TAMARA_NOTIFICATION_TOKEN || "";
    const tamaraPublicKey = process.env.TAMARA_PUBLIC_KEY || "";
    const configuredMinAmount = getNumericEnvValue(
        "TAMARA_MIN_AMOUNT",
        "TAMARA_INSTALLMENT_MIN_AMOUNT",
        "TAMARA_MIN_TOTAL"
    );
    const configuredMaxAmount = getNumericEnvValue(
        "TAMARA_MAX_AMOUNT",
        "TAMARA_INSTALLMENT_MAX_AMOUNT",
        "TAMARA_MAX_TOTAL"
    );
    const installments = getNumericEnvValue("TAMARA_INSTALLMENTS") || 4;

    return {
        tamaraApiToken,
        tamaraApiBaseUrl,
        tamaraNotificationToken,
        tamaraPublicKey,
        minAmount: configuredMinAmount ?? DEFAULT_TAMARA_MIN_AMOUNT,
        maxAmount: configuredMaxAmount,
        installments,
    };
};

const getTamaraEligibility = (amount) => {
    const totalAmount = toAmount(amount);
    const settings = getTamaraSettings();
    const minAmount = Number(settings.minAmount || 0);
    const hasMaxAmount = Number.isFinite(settings.maxAmount);
    const maxAmount = hasMaxAmount ? Number(settings.maxAmount) : null;

    if (!settings.tamaraApiToken) {
        return {
            eligible: false,
            minAmount,
            maxAmount,
            reason: "Tamara is not configured yet.",
        };
    }

    if (totalAmount <= 0) {
        return {
            eligible: false,
            minAmount,
            maxAmount,
            reason: "Add a service before using Tamara.",
        };
    }

    if (totalAmount < minAmount) {
        return {
            eligible: false,
            minAmount,
            maxAmount,
            reason: `Tamara is available from AED ${toAmount(minAmount).toFixed(2)}.`,
        };
    }

    if (hasMaxAmount && totalAmount > maxAmount) {
        return {
            eligible: false,
            minAmount,
            maxAmount,
            reason: `Tamara is available up to AED ${toAmount(maxAmount).toFixed(2)}.`,
        };
    }

    return {
        eligible: true,
        minAmount,
        maxAmount,
        reason: "",
    };
};

const getBookingOrderStatus = (paymentStatus) => {
    if (paymentStatus === "failed") return "cancelled";
    if (paymentStatus === "cash_on_visit") return "confirm";
    if (paymentStatus === "paid" || paymentStatus === "authorized") return "confirm";
    return "pending";
};

const getBookingStatus = (paymentStatus) => {
    if (paymentStatus === "failed") return "cancelled";
    if (paymentStatus === "cash_on_visit") return "confirmed";
    if (paymentStatus === "paid" || paymentStatus === "authorized") return "confirmed";
    return "draft";
};

const getTamaraBookingPaymentStatus = (tamaraStatus = "") => {
    const normalizedStatus = String(tamaraStatus || "").toLowerCase();

    if (tamaraPaidStatuses.has(normalizedStatus)) {
        return "paid";
    }

    if (tamaraAuthorizedStatuses.has(normalizedStatus)) {
        return "authorized";
    }

    if (tamaraFailedStatuses.has(normalizedStatus)) {
        return "failed";
    }

    return "pending";
};

const getBookingReference = (booking = {}) => {
    if (booking?.bookingReference) {
        return booking.bookingReference;
    }

    const bookingId = String(booking?._id || "");
    if (!bookingId) {
        return "";
    }

    return `BKG-${bookingId.slice(-8).toUpperCase()}`;
};

const serializeBookingForApi = (booking = {}) => ({
    ...booking,
    bookingId: String(booking?._id || ""),
    bookingReference: getBookingReference(booking),
    customerInfo: {
        name: booking?.userId?.name || "",
        email: booking?.userId?.email || "",
        mobile: String(booking?.userId?.mobile || booking?.addressSnapshot?.mobile || ""),
        address: booking?.addressSnapshot || {},
    },
    serviceName: booking?.serviceSnapshot?.name || booking?.serviceId?.name || "",
    schedule: {
        date: booking?.bookingDate || "",
        dayLabel: booking?.bookingDayLabel || "",
        startTime: booking?.startTime || "",
        endTime: booking?.endTime || "",
        slotLabel: booking?.slotLabel || "",
    },
    assignedProfessional: {
        id: booking?.professionalId?._id || booking?.professionalId || null,
        name: booking?.professionalSnapshot?.name || booking?.professionalId?.name || "Auto assign",
        title: booking?.professionalSnapshot?.title || booking?.professionalId?.title || "",
    },
});

const prepareBookingRequestData = async ({
    requestBody = {},
    userId,
}) => {
    const {
        serviceId,
        quantity,
        addOnIds,
        voucherCode,
        instantRequested,
        professionalId,
        professionalPreference,
        bookingDate,
        bookingDayLabel,
        startTime,
        endTime,
        slotLabel,
        instructions,
        addressId,
    } = requestBody || {};

    const user = await UserModel.findById(userId).select("name email mobile createdAt orderHistory");

    if (!user) {
        throw new Error("User account not found");
    }

    const address = addressId
        ? await AddressModel.findById(addressId)
        : null;

    if (!address) {
        throw new Error("Please select a valid address before booking.");
    }

    const quote = await calculateBookingQuote({
        serviceId,
        quantity,
        addOnIds,
        instantRequested,
        voucherCode,
    });

    const serviceDoc = await ProductModel.findById(serviceId).lean();

    if (!serviceDoc) {
        throw new Error("Selected service could not be found.");
    }

    if (!isServiceProduct(serviceDoc)) {
        throw new Error("Selected item is not a bookable service.");
    }

    let professionalDoc = null;
    if (professionalId) {
        professionalDoc = await ProfessionalModel.findById(professionalId).lean();

        if (!professionalDoc) {
            throw new Error("Selected professional could not be found.");
        }
    }

    const professionalSnapshot = professionalDoc ? serializeProfessional(professionalDoc) : {};

    return {
        requestData: {
            serviceId,
            quantity,
            addOnIds,
            voucherCode,
            instantRequested: Boolean(instantRequested),
            professionalId: professionalDoc?._id || null,
            professionalPreference:
                professionalPreference === "specific" && professionalDoc
                    ? "specific"
                    : "auto",
            bookingDate: bookingDate || new Date().toISOString().slice(0, 10),
            bookingDayLabel: bookingDayLabel || "",
            startTime: startTime || (instantRequested ? "ASAP" : ""),
            endTime: endTime || "",
            slotLabel: slotLabel || "",
            instructions: instructions || "",
            addressId: address._id,
        },
        user,
        address,
        addressSnapshot: buildAddressSnapshot(address),
        quote,
        serviceDoc,
        professionalDoc,
        professionalSnapshot,
    };
};

const createBookingAndOrderRecord = async ({
    userId,
    preparedBooking,
    paymentMethod,
    paymentStatus,
    bookingStatus,
    paymentId,
    paymentReferenceId,
    addToUserHistory = true,
}) => {
    void addToUserHistory;

    const {
        requestData,
        address,
        addressSnapshot,
        quote,
        professionalDoc,
        professionalSnapshot,
    } = preparedBooking;

    const booking = await BookingModel.create({
        userId,
        serviceId: requestData.serviceId,
        serviceSnapshot: {
            name: quote.service.name,
            image: quote.service.primaryImage,
            categoryName: quote.service.subCat || quote.service.catName,
            durationMinutes: quote.service.durationMinutes,
            price: quote.service.price,
        },
        quantity: quote.quantity,
        addOns: quote.addOns.map((item) => ({
            addOnId: item._id,
            name: item.name,
            image: item.image,
            durationMinutes: item.durationMinutes,
            price: item.price,
        })),
        professionalId: professionalDoc?._id || null,
        professionalSnapshot: professionalDoc
            ? {
                name: professionalSnapshot.name,
                title: professionalSnapshot.title,
                avatar: professionalSnapshot.avatar,
                rating: professionalSnapshot.rating,
            }
            : {},
        professionalPreference: requestData.professionalPreference,
        instantRequested: requestData.instantRequested,
        bookingDate: requestData.bookingDate,
        bookingDayLabel: requestData.bookingDayLabel,
        startTime: requestData.startTime,
        endTime: requestData.endTime,
        slotLabel: requestData.slotLabel,
        instructions: requestData.instructions,
        addressId: address._id,
        addressSnapshot,
        voucher: {
            code: quote.voucher.code,
            label: quote.voucher.label,
            type: quote.voucher.type,
            amount: quote.summary.discount,
        },
        paymentMethod,
        paymentStatus,
        paymentId: paymentId || "",
        paymentReferenceId: paymentReferenceId || "",
        status: bookingStatus,
        summary: quote.summary,
    });

    return {
        booking,
        order: null,
    };
};

const fetchTamaraOrderStatus = async ({
    tamaraApiBaseUrl,
    tamaraHeaders,
    tamaraOrderId,
    shouldAuthoriseApprovedOrder = false,
}) => {
    const orderDetailsResponse = await axios.get(
        `${tamaraApiBaseUrl}/orders/${tamaraOrderId}`,
        { headers: tamaraHeaders }
    );

    let tamaraOrder = orderDetailsResponse?.data;
    let tamaraStatus = String(
        tamaraOrder?.status
        || tamaraOrder?.order_status
        || tamaraOrder?.payment_status
        || ""
    ).toLowerCase();

    if (shouldAuthoriseApprovedOrder && tamaraStatus === "approved") {
        await axios.post(
            `${tamaraApiBaseUrl}/orders/${tamaraOrderId}/authorise`,
            {},
            { headers: tamaraHeaders }
        );

        const refreshedOrderResponse = await axios.get(
            `${tamaraApiBaseUrl}/orders/${tamaraOrderId}`,
            { headers: tamaraHeaders }
        );

        tamaraOrder = refreshedOrderResponse?.data;
        tamaraStatus = String(
            tamaraOrder?.status
            || tamaraOrder?.order_status
            || tamaraOrder?.payment_status
            || "authorised"
        ).toLowerCase();
    }

    return {
        tamaraOrder,
        tamaraStatus,
    };
};

const syncTamaraBookingState = async ({
    booking,
    tamaraOrderId,
    tamaraStatus,
    orderReferenceId,
}) => {
    const normalizedTamaraStatus = String(tamaraStatus || "").toLowerCase();
    const paymentStatus = getTamaraBookingPaymentStatus(normalizedTamaraStatus);
    const nextBookingStatus = getBookingStatus(paymentStatus);
    const orderStatus = getBookingOrderStatus(paymentStatus);
    const paymentStatusLabel = paymentStatus === "pending"
        ? "TAMARA_PENDING"
        : `TAMARA_${normalizedTamaraStatus.toUpperCase()}`;
    const orderId = booking.orderId?._id || booking.orderId || null;

    booking.paymentMethod = "tamara";
    booking.paymentId = tamaraOrderId || booking.paymentId || "";
    booking.paymentReferenceId = orderReferenceId || booking.paymentReferenceId || "";
    booking.paymentStatus = paymentStatus;
    booking.status = nextBookingStatus;
    await booking.save();

    if (orderId) {
        await OrderModel.findByIdAndUpdate(orderId, {
            paymentMethod: "tamara",
            paymentId: tamaraOrderId || booking.paymentId || "",
            paymentReferenceId: orderReferenceId || booking.paymentReferenceId || "",
            payment_status: paymentStatusLabel,
            order_status: orderStatus,
        });
    }

    if (orderId && (paymentStatus === "authorized" || paymentStatus === "paid")) {
        await UserModel.findByIdAndUpdate(booking.userId, {
            $addToSet: {
                orderHistory: orderId,
            },
        });
    }

    return {
        paymentStatus,
        bookingStatus: nextBookingStatus,
        orderStatus,
    };
};

const findBookingByTamaraReference = async ({
    tamaraOrderId,
    orderReferenceId,
}) => {
    let booking = null;

    if (tamaraOrderId) {
        booking = await BookingModel.findOne({ paymentId: tamaraOrderId }).populate("orderId");
    }

    if (!booking && orderReferenceId) {
        booking = await BookingModel.findOne({ paymentReferenceId: orderReferenceId }).populate("orderId");
    }

    return booking;
};

const verifyTamaraWebhookToken = (request) => {
    const bearerToken = String(request.headers.authorization || "").replace(/^Bearer\s+/i, "");
    const queryToken = String(request.query?.tamaraToken || "");
    const tamaraToken = queryToken || bearerToken;
    const { tamaraNotificationToken } = getTamaraSettings();

    if (!tamaraNotificationToken) {
        throw new Error("Tamara notification token is missing.");
    }

    if (!tamaraToken) {
        throw new Error("Tamara notification token was not provided.");
    }

    jwt.verify(tamaraToken, tamaraNotificationToken, { algorithms: ["HS256"] });
};

export const quoteBookingController = async (request, response) => {
    try {
        const result = await calculateBookingQuote({
            serviceId: request.body.serviceId,
            quantity: request.body.quantity,
            addOnIds: request.body.addOnIds,
            instantRequested: request.body.instantRequested,
            voucherCode: request.body.voucherCode,
        });

        return response.status(200).json({
            success: true,
            error: false,
            ...result,
        });
    } catch (error) {
        return response.status(400).json({
            success: false,
            error: true,
            message: error.message || "Unable to generate booking quote",
        });
    }
};

export const getTamaraBookingConfigController = async (_request, response) => {
    try {
        const settings = getTamaraSettings();

        return response.status(200).json({
            success: true,
            error: false,
            enabled: Boolean(settings.tamaraApiToken),
            widgetEnabled: Boolean(settings.tamaraPublicKey),
            publicKey: settings.tamaraPublicKey,
            installments: settings.installments,
            minAmount: settings.minAmount,
            maxAmount: settings.maxAmount,
            countryCode: "AE",
            currency: "AED",
            description: "Split into 4 payments. No late fees. Sharia compliant.",
        });
    } catch (error) {
        return response.status(500).json({
            success: false,
            error: true,
            message: error.message || "Unable to load Tamara settings",
        });
    }
};

export const createBookingController = async (request, response) => {
    try {
        const selectedPaymentMethod = request.body?.paymentMethod === "cash" ? "cash" : request.body?.paymentMethod === "tamara" ? "tamara" : "card";

        if (selectedPaymentMethod === "tamara") {
            return response.status(400).json({
                success: false,
                error: true,
                message: "Tamara bookings must be started through the Tamara checkout route.",
            });
        }

        const preparedBooking = await prepareBookingRequestData({
            requestBody: request.body,
            userId: request.userId,
        });

        const selectedPaymentStatus = selectedPaymentMethod === "cash"
            ? "cash_on_visit"
            : "authorized";

        const { booking, order } = await createBookingAndOrderRecord({
            userId: request.userId,
            preparedBooking,
            paymentMethod: selectedPaymentMethod,
            paymentStatus: selectedPaymentStatus,
            bookingStatus: "confirmed",
            paymentId: `BOOK-${Date.now()}-${String(preparedBooking.requestData.serviceId).slice(-6)}`,
            paymentReferenceId: "",
        });

        return response.status(201).json({
            success: true,
            error: false,
            message: "Booking confirmed successfully",
            booking,
            order,
        });
    } catch (error) {
        return response.status(500).json({
            success: false,
            error: true,
            message: error.message || "Unable to create booking",
        });
    }
};

export const createBookingTamaraCheckoutController = async (request, response) => {
    let bookingDraft = null;
    let orderDraft = null;

    try {
        const {
            successUrl,
            failureUrl,
            cancelUrl,
        } = request.body || {};

        const preparedBooking = await prepareBookingRequestData({
            requestBody: request.body,
            userId: request.userId,
        });

        const eligibility = getTamaraEligibility(preparedBooking.quote?.summary?.total);
        if (!eligibility.eligible) {
            return response.status(400).json({
                success: false,
                error: true,
                message: eligibility.reason,
                tamara: {
                    minAmount: eligibility.minAmount,
                    maxAmount: eligibility.maxAmount,
                },
            });
        }

        const {
            tamaraApiToken,
            tamaraApiBaseUrl,
        } = getTamaraSettings();

        if (!tamaraApiToken) {
            return response.status(400).json({
                success: false,
                error: true,
                message: "Tamara API token is missing. Add TAMARA_API_TOKEN to the server environment.",
            });
        }

        const { firstName, lastName } = splitCustomerName(preparedBooking.user?.name);
        const phoneNumber = normalizePhoneNumber(
            preparedBooking.user?.mobile || preparedBooking.address?.mobile
        );

        if (!phoneNumber) {
            return response.status(400).json({
                success: false,
                error: true,
                message: "Customer phone number is required for Tamara checkout.",
            });
        }

        const orderReferenceId = `BOOK-${Date.now()}-${String(preparedBooking.requestData.serviceId).slice(-6)}`;

        const draftRecords = await createBookingAndOrderRecord({
            userId: request.userId,
            preparedBooking,
            paymentMethod: "tamara",
            paymentStatus: "pending",
            bookingStatus: "draft",
            paymentId: "",
            paymentReferenceId: orderReferenceId,
            addToUserHistory: false,
        });

        bookingDraft = draftRecords.booking;
        orderDraft = draftRecords.order;

        const countryCode = getCountryCode(preparedBooking.address?.country);
        const baseSiteUrl = getBaseSiteUrl(request);
        const totalSummary = preparedBooking.quote.summary;
        const productPageUrl = `${baseSiteUrl}/product/${preparedBooking.requestData.serviceId}`;
        const serviceCategoryLabel =
            preparedBooking.quote.service.catName
            || preparedBooking.quote.service.subCat
            || "Women's Salon Services";
        const safeSuccessUrl = successUrl || `${baseSiteUrl}/booking/success?provider=tamara`;
        const safeFailureUrl = failureUrl || `${baseSiteUrl}/booking/failed?provider=tamara`;
        const safeCancelUrl = cancelUrl || `${productPageUrl}?payment=tamara-cancelled`;
        const voucherDiscount = toAmount(totalSummary.discount);

        const payload = {
            total_amount: {
                amount: toAmount(totalSummary.total),
                currency: "AED",
            },
            shipping_amount: {
                amount: toAmount(totalSummary.serviceFee),
                currency: "AED",
            },
            tax_amount: {
                amount: 0,
                currency: "AED",
            },
            order_reference_id: orderReferenceId,
            order_number: `BOOKING-${bookingDraft._id}`,
            description: `${preparedBooking.quote.quantity || 1}x ${preparedBooking.quote.service.name} - ${serviceCategoryLabel}.`,
            country_code: countryCode,
            payment_type: "PAY_BY_INSTALMENTS",
            locale: "en_US",
            is_mobile: false,
            platform: "cutiepieladiessalon.ae",
            merchant_url: {
                success: safeSuccessUrl,
                failure: safeFailureUrl,
                cancel: safeCancelUrl,
            },
            consumer: {
                first_name: firstName,
                last_name: lastName,
                phone_number: phoneNumber,
                email: preparedBooking.user?.email || "",
            },
            shipping_address: {
                first_name: firstName,
                last_name: lastName,
                line1: preparedBooking.address?.address_line1 || "NA",
                line2: preparedBooking.address?.landmark || "",
                region: preparedBooking.address?.state || preparedBooking.address?.city || "Dubai",
                city: preparedBooking.address?.city || "Dubai",
                country_code: countryCode,
                postal_code: preparedBooking.address?.pincode || "00000",
                phone_number: phoneNumber,
            },
            discount: voucherDiscount > 0
                ? {
                    amount: {
                        amount: voucherDiscount,
                        currency: "AED",
                    },
                    name: preparedBooking.quote.voucher?.label || preparedBooking.quote.voucher?.code || "Voucher discount",
                }
                : undefined,
            risk_assessment: {
                is_premium_customer: false,
                account_creation_date: new Date(
                    preparedBooking.user?.createdAt || Date.now()
                ).toLocaleDateString("en-GB").replace(/\//g, "-"),
                total_order_count: Array.isArray(preparedBooking.user?.orderHistory)
                    ? preparedBooking.user.orderHistory.length
                    : 0,
                risk_score: 0,
                is_existing_customer: Boolean((preparedBooking.user?.orderHistory || []).length),
                is_guest_user: false,
                is_phone_verified: Boolean(phoneNumber),
            },
            items: [
                {
                    reference_id: String(preparedBooking.serviceDoc?._id || preparedBooking.requestData.serviceId),
                    sku: String(preparedBooking.serviceDoc?._id || preparedBooking.requestData.serviceId),
                    type: "Physical",
                    name: String(preparedBooking.quote.service.name || "Salon service").slice(0, 255),
                    quantity: Number(preparedBooking.quote.quantity || 1),
                    item_url: productPageUrl,
                    image_url: preparedBooking.quote.service.primaryImage || "",
                    unit_price: {
                        amount: toAmount(preparedBooking.quote.service.price),
                        currency: "AED",
                    },
                    tax_amount: {
                        amount: 0,
                        currency: "AED",
                    },
                    discount_amount: {
                        amount: 0,
                        currency: "AED",
                    },
                    total_amount: {
                        amount: toAmount(totalSummary.serviceBase),
                        currency: "AED",
                    },
                },
                ...preparedBooking.quote.addOns.map((item) => ({
                    reference_id: String(item?._id || item?.addOnId || ""),
                    sku: String(item?._id || item?.addOnId || ""),
                    type: "Physical",
                    name: String(item?.name || "Add-on").slice(0, 255),
                    quantity: Number(preparedBooking.quote.quantity || 1),
                    item_url: productPageUrl,
                    image_url: item?.image || "",
                    unit_price: {
                        amount: toAmount(item?.price),
                        currency: "AED",
                    },
                    tax_amount: {
                        amount: 0,
                        currency: "AED",
                    },
                    discount_amount: {
                        amount: 0,
                        currency: "AED",
                    },
                    total_amount: {
                        amount: toAmount(Number(item?.price || 0) * Number(preparedBooking.quote.quantity || 1)),
                        currency: "AED",
                    },
                })),
            ],
        };

        const tamaraResponse = await axios.post(
            `${tamaraApiBaseUrl}/checkout`,
            payload,
            {
                headers: {
                    Authorization: `Bearer ${tamaraApiToken}`,
                    "Content-Type": "application/json",
                },
            }
        );

        const tamaraOrderId = tamaraResponse?.data?.order_id || "";
        const checkoutId = tamaraResponse?.data?.checkout_id || "";

        bookingDraft.paymentId = tamaraOrderId;
        bookingDraft.paymentReferenceId = orderReferenceId;
        await bookingDraft.save();

        if (orderDraft?._id) {
            await OrderModel.findByIdAndUpdate(orderDraft._id, {
                paymentId: tamaraOrderId || orderReferenceId,
                paymentReferenceId: orderReferenceId,
                payment_status: "TAMARA_PENDING",
                order_status: "pending",
            });
        }

        return response.status(200).json({
            success: true,
            error: false,
            message: "Tamara checkout initialized successfully.",
            bookingId: bookingDraft._id,
            checkoutUrl: tamaraResponse?.data?.checkout_url || "",
            tamaraOrderId,
            orderId: tamaraOrderId,
            checkoutId,
            orderReferenceId,
            data: tamaraResponse?.data,
        });
    } catch (error) {
        if (bookingDraft?._id) {
            await BookingModel.findByIdAndDelete(bookingDraft._id).catch(() => null);
        }

        if (orderDraft?._id) {
            await OrderModel.findByIdAndDelete(orderDraft._id).catch(() => null);
        }

        return response.status(500).json({
            message: error?.response?.data?.message || error?.response?.data || error.message || error,
            error: true,
            success: false,
        });
    }
};

export const finalizeTamaraBookingController = async (request, response) => {
    try {
        const {
            bookingId,
            tamaraOrderId,
        } = request.body || {};

        if (!request.userId || !bookingId || !tamaraOrderId) {
            return response.status(400).json({
                success: false,
                error: true,
                message: "Missing required fields to finalize the Tamara booking.",
            });
        }

        const booking = await BookingModel.findOne({
            _id: bookingId,
            userId: request.userId,
        }).populate("orderId");

        if (!booking) {
            return response.status(404).json({
                success: false,
                error: true,
                message: "Booking not found.",
            });
        }

        if (booking.paymentMethod !== "tamara") {
            return response.status(400).json({
                success: false,
                error: true,
                message: "This booking is not using Tamara.",
            });
        }

        if (booking.paymentStatus === "authorized" || booking.paymentStatus === "paid") {
            return response.status(200).json({
                success: true,
                error: false,
                message: "Tamara booking already finalized.",
                booking,
                order: booking.orderId,
            });
        }

        const {
            tamaraApiToken,
            tamaraApiBaseUrl,
        } = getTamaraSettings();

        if (!tamaraApiToken) {
            return response.status(400).json({
                success: false,
                error: true,
                message: "Tamara API token is missing. Add TAMARA_API_TOKEN to the server environment.",
            });
        }

        const tamaraHeaders = {
            Authorization: `Bearer ${tamaraApiToken}`,
            "Content-Type": "application/json",
        };

        const {
            tamaraOrder,
            tamaraStatus,
        } = await fetchTamaraOrderStatus({
            tamaraApiBaseUrl,
            tamaraHeaders,
            tamaraOrderId,
            shouldAuthoriseApprovedOrder: true,
        });

        if (!acceptedTamaraStatuses.has(tamaraStatus)) {
            return response.status(400).json({
                success: false,
                error: true,
                message: `Tamara order is not ready yet. Current status: ${tamaraStatus || "unknown"}.`,
            });
        }

        const updatedState = await syncTamaraBookingState({
            booking,
            tamaraOrderId,
            tamaraStatus,
            orderReferenceId: tamaraOrder?.order_reference_id || booking.paymentReferenceId,
        });

        const refreshedBooking = await BookingModel.findById(booking._id).populate("orderId");

        return response.status(200).json({
            success: true,
            error: false,
            message: "Tamara booking finalized successfully.",
            booking: refreshedBooking,
            order: refreshedBooking?.orderId || null,
            tamaraStatus,
            paymentStatus: updatedState.paymentStatus,
        });
    } catch (error) {
        return response.status(500).json({
            message: error?.response?.data?.message || error?.response?.data || error.message || error,
            error: true,
            success: false,
        });
    }
};

export const tamaraBookingWebhookController = async (request, response) => {
    try {
        verifyTamaraWebhookToken(request);

        const {
            order_id: tamaraOrderId,
            order_reference_id: orderReferenceId,
            event_type: eventType,
        } = request.body || {};

        if (!tamaraOrderId && !orderReferenceId) {
            return response.status(400).json({
                success: false,
                error: true,
                message: "Missing Tamara order identifiers.",
            });
        }

        const booking = await findBookingByTamaraReference({
            tamaraOrderId,
            orderReferenceId,
        });

        if (!booking) {
            return response.status(202).json({
                success: true,
                error: false,
                message: "Tamara webhook accepted. No matching booking was found yet.",
            });
        }

        const {
            tamaraApiToken,
            tamaraApiBaseUrl,
        } = getTamaraSettings();

        const tamaraHeaders = {
            Authorization: `Bearer ${tamaraApiToken}`,
            "Content-Type": "application/json",
        };

        let nextTamaraStatus = "";

        if (eventType === "order_approved" || eventType === "order_authorised") {
            const tamaraOrderState = await fetchTamaraOrderStatus({
                tamaraApiBaseUrl,
                tamaraHeaders,
                tamaraOrderId: tamaraOrderId || booking.paymentId,
                shouldAuthoriseApprovedOrder: eventType === "order_approved",
            });

            nextTamaraStatus = tamaraOrderState.tamaraStatus;

            await syncTamaraBookingState({
                booking,
                tamaraOrderId: tamaraOrderId || booking.paymentId,
                tamaraStatus: nextTamaraStatus,
                orderReferenceId: tamaraOrderState.tamaraOrder?.order_reference_id || orderReferenceId,
            });
        } else if (eventType === "order_captured") {
            nextTamaraStatus = "fully_captured";

            await syncTamaraBookingState({
                booking,
                tamaraOrderId: tamaraOrderId || booking.paymentId,
                tamaraStatus: nextTamaraStatus,
                orderReferenceId,
            });
        } else if (eventType === "order_declined" || eventType === "order_canceled" || eventType === "order_cancelled" || eventType === "order_expired") {
            nextTamaraStatus =
                eventType === "order_expired"
                    ? "expired"
                    : eventType === "order_declined"
                    ? "declined"
                    : "cancelled";

            await syncTamaraBookingState({
                booking,
                tamaraOrderId: tamaraOrderId || booking.paymentId,
                tamaraStatus: nextTamaraStatus,
                orderReferenceId,
            });
        }

        return response.status(200).json({
            success: true,
            error: false,
            message: "Tamara booking webhook processed successfully.",
            eventType,
            tamaraStatus: nextTamaraStatus,
        });
    } catch (error) {
        const statusCode = /token/i.test(error.message || "") ? 401 : 500;

        return response.status(statusCode).json({
            success: false,
            error: true,
            message: error.message || "Unable to process Tamara webhook.",
        });
    }
};

export const getMyBookingsController = async (request, response) => {
    try {
        const bookings = await BookingModel.find({ userId: request.userId })
            .sort({ createdAt: -1 })
            .populate("serviceId", "name images price")
            .populate("professionalId", "name avatar title")
            .populate("orderId", "paymentId paymentReferenceId paymentMethod payment_status totalAmt createdAt")
            .lean({ virtuals: true });

        return response.status(200).json({
            success: true,
            error: false,
            data: bookings.map(serializeBookingForApi),
        });
    } catch (error) {
        return response.status(500).json({
            success: false,
            error: true,
            message: error.message || "Unable to load your bookings",
        });
    }
};

export const getAdminBookingsController = async (_request, response) => {
    try {
        const bookings = await BookingModel.find()
            .sort({ createdAt: -1 })
            .populate("userId", "name email mobile")
            .populate("serviceId", "name images price")
            .populate("professionalId", "name avatar title")
            .populate("orderId", "paymentMethod payment_status totalAmt paymentReferenceId")
            .lean({ virtuals: true });

        return response.status(200).json({
            success: true,
            error: false,
            data: bookings.map(serializeBookingForApi),
        });
    } catch (error) {
        return response.status(500).json({
            success: false,
            error: true,
            message: error.message || "Unable to load bookings",
        });
    }
};

export const getSingleBookingController = async (request, response) => {
    try {
        const booking = await BookingModel.findById(request.params.id)
            .populate("userId", "name email mobile")
            .populate("serviceId", "name images price")
            .populate("professionalId", "name avatar title")
            .populate("orderId")
            .lean({ virtuals: true });

        if (!booking) {
            return response.status(404).json({
                success: false,
                error: true,
                message: "Booking not found",
            });
        }

        if (String(booking.userId?._id || booking.userId) !== String(request.userId)) {
            const requester = await UserModel.findById(request.userId).select("role").lean();
            if (String(requester?.role || "").trim().toUpperCase() !== "ADMIN") {
                return response.status(403).json({
                    success: false,
                    error: true,
                    message: "You do not have access to this booking",
                });
            }
        }

        return response.status(200).json({
            success: true,
            error: false,
            data: serializeBookingForApi(booking),
        });
    } catch (error) {
        return response.status(500).json({
            success: false,
            error: true,
            message: error.message || "Unable to load booking",
        });
    }
};

export const getBookingsCountController = async (_request, response) => {
    try {
        const count = await BookingModel.countDocuments();

        return response.status(200).json({
            success: true,
            error: false,
            count,
        });
    } catch (error) {
        return response.status(500).json({
            success: false,
            error: true,
            message: error.message || "Unable to load booking count",
        });
    }
};

export const updateBookingStatusController = async (request, response) => {
    try {
        const booking = await BookingModel.findByIdAndUpdate(
            request.params.id,
            {
                status: request.body.status,
                paymentStatus: request.body.paymentStatus,
            },
            { new: true }
        ).lean();

        if (!booking) {
            return response.status(404).json({
                success: false,
                error: true,
                message: "Booking not found",
            });
        }

        if (booking.orderId) {
            await OrderModel.findByIdAndUpdate(booking.orderId, {
                order_status: request.body.status || booking.status,
                payment_status: request.body.paymentStatus || booking.paymentStatus,
            });
        }

        return response.status(200).json({
            success: true,
            error: false,
            message: "Booking updated successfully",
            data: booking,
        });
    } catch (error) {
        return response.status(500).json({
            success: false,
            error: true,
            message: error.message || "Unable to update booking",
        });
    }
};
