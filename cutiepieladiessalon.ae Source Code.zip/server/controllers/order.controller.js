import OrderModel from "../models/order.model.js";
import ProductModel from '../models/product.modal.js';
import UserModel from '../models/user.model.js';
import paypal from "@paypal/checkout-server-sdk";
import axios from "axios";
import OrderConfirmationEmail from "../utils/orderEmailTemplate.js";
import sendEmailFun from "../config/sendEmail.js";
import AddressModel from "../models/address.model.js";
import CartProductModel from "../models/cartProduct.modal.js";
import { isServiceProduct } from "../utils/productType.utils.js";

const defaultTamaraApiBaseUrl = "https://api.tamara.co";
const localHostNames = new Set(["localhost", "127.0.0.1", "::1"]);
const SERVICE_CHECKOUT_MESSAGE = "Service items must be booked from the service page. Remove them from the cart and complete the booking there.";

const toAmount = (value) => Number(Number(value || 0).toFixed(2));

const formatOrderDate = () => new Date().toLocaleString("en-US", {
    month: "short",
    day: "2-digit",
    year: "numeric",
});

const splitCustomerName = (fullName = "") => {
    const normalized = String(fullName || "").trim().replace(/\s+/g, " ");
    if (!normalized) {
        return { firstName: "Customer", lastName: "User" };
    }

    const [firstName, ...rest] = normalized.split(" ");
    return {
        firstName,
        lastName: rest.join(" ") || "User",
    };
};

const normalizePhoneNumber = (phoneNumber) => String(phoneNumber ?? "")
    .replace(/[^\d]/g, "")
    .slice(0, 32);

const getCountryCode = (country = "") => {
    const normalized = String(country || "").toLowerCase();

    if (normalized.includes("united arab emirates") || normalized.includes("uae")) {
        return "AE";
    }

    if (normalized.includes("saudi")) {
        return "SA";
    }

    return "AE";
};

const getBaseSiteUrl = (request) => {
    const configuredUrl = (
        process.env.FRONTEND_URL
        || process.env.SITE_URL
        || process.env.PUBLIC_SITE_URL
        || request.headers.origin
        || "https://cutiepieladiessalon.ae"
    );

    const normalizedConfiguredUrl = configuredUrl.replace(/\/+$/, "");

    try {
        const parsedConfiguredUrl = new URL(normalizedConfiguredUrl);
        const requestOrigin = String(request.headers.origin || "").replace(/\/+$/, "");

        if (requestOrigin && localHostNames.has(parsedConfiguredUrl.hostname)) {
            const parsedRequestOrigin = new URL(requestOrigin);
            if (!localHostNames.has(parsedRequestOrigin.hostname)) {
                return requestOrigin;
            }
        }
    } catch {
        return normalizedConfiguredUrl;
    }

    return normalizedConfiguredUrl;
};

const getTamaraApiConfig = () => {
    const tamaraApiToken = process.env.TAMARA_API_TOKEN || "";
    const tamaraApiBaseUrl = (process.env.TAMARA_API_BASE_URL || defaultTamaraApiBaseUrl).replace(/\/+$/, "");

    return {
        tamaraApiToken,
        tamaraApiBaseUrl,
    };
};

const createHttpError = (message, statusCode = 400) => Object.assign(new Error(message), { statusCode });

const resolveCheckoutProducts = async (products = []) => {
    if (!Array.isArray(products) || products.length === 0) {
        throw createHttpError("Add at least one product before checking out.");
    }

    const productIds = Array.from(new Set(
        products
            .map((item) => String(item?.productId || item?._id || ""))
            .filter(Boolean)
    ));

    if (!productIds.length) {
        throw createHttpError("Add at least one product before checking out.");
    }

    const productDocs = await ProductModel.find({ _id: { $in: productIds } })
        .select("_id name price images brand countInStock sale serviceType bookingEnabled catName subCat thirdsubCat")
        .lean();

    const productMap = new Map(productDocs.map((product) => [String(product._id), product]));

    const normalizedProducts = products.map((item) => {
        const productId = String(item?.productId || item?._id || "");
        const productDoc = productMap.get(productId);

        if (!productDoc) {
            throw createHttpError(`Product ${productId || ""} could not be found.`);
        }

        const quantity = Math.max(1, Number.parseInt(item?.quantity, 10) || 1);
        const price = toAmount(item?.price ?? productDoc?.price ?? 0);

        return {
            productId,
            productTitle: item?.productTitle || item?.name || productDoc?.name || "Product",
            quantity,
            price,
            image: item?.image || productDoc?.images?.[0] || "",
            subTotal: toAmount(price * quantity),
            countInStock: Number(productDoc?.countInStock || 0),
            brand: item?.brand || productDoc?.brand || "",
            serviceType: isServiceProduct(productDoc) ? "service" : "product",
            productDoc,
        };
    });

    const serviceItems = normalizedProducts.filter((item) => item.serviceType === "service");

    if (serviceItems.length > 0) {
        throw createHttpError(SERVICE_CHECKOUT_MESSAGE);
    }

    return normalizedProducts;
};

const normalizeRequestedOrderType = (orderType = "") => {
    const normalizedOrderType = String(orderType || "").trim().toUpperCase();

    if (normalizedOrderType === "BOOKING") return "BOOKING";
    if (normalizedOrderType === "PRODUCT") return "PRODUCT";

    return "";
};

const isBookingLinkedOrder = (order = {}) => {
    if (String(order?.orderType || "").trim().toUpperCase() === "BOOKING") {
        return true;
    }

    return Boolean(order?.bookingId || order?.serviceId);
};

const filterOrdersByType = async (orders = [], orderType = "") => {
    const normalizedOrderType = normalizeRequestedOrderType(orderType);

    if (!normalizedOrderType) {
        return orders;
    }

    if (normalizedOrderType === "BOOKING") {
        return orders.filter((order) => isBookingLinkedOrder(order));
    }

    const productIds = Array.from(new Set(
        orders
            .flatMap((order) => order?.products || [])
            .map((item) => String(item?.productId || ""))
            .filter((productId) => /^[a-f\d]{24}$/i.test(productId))
    ));

    const productDocs = productIds.length
        ? await ProductModel.find({ _id: { $in: productIds } })
            .select("_id serviceType bookingEnabled catName subCat thirdsubCat")
            .lean()
        : [];
    const serviceProductIds = new Set(
        productDocs
            .filter((product) => isServiceProduct(product))
            .map((product) => String(product?._id || ""))
    );

    return orders.filter((order) => {
        if (isBookingLinkedOrder(order)) {
            return false;
        }

        const explicitOrderType = String(order?.orderType || "").trim().toUpperCase();
        if (explicitOrderType && explicitOrderType !== "PRODUCT") {
            return false;
        }

        return !(order?.products || []).some((item) =>
            serviceProductIds.has(String(item?.productId || ""))
        );
    });
};

const createLocalOrderRecord = async ({
    userId,
    products,
    paymentId,
    paymentStatus,
    deliveryAddress,
    totalAmount,
    date,
}) => {
    const normalizedProducts = await resolveCheckoutProducts(products);
    const existingOrder = paymentId ? await OrderModel.findOne({ paymentId }) : null;

    if (existingOrder) {
        return existingOrder;
    }

    let order = new OrderModel({
        userId,
        orderType: "PRODUCT",
        products: normalizedProducts,
        paymentId,
        payment_status: paymentStatus,
        delivery_address: deliveryAddress,
        totalAmt: totalAmount,
        date: date || formatOrderDate(),
    });

    order = await order.save();

    for (let i = 0; i < normalizedProducts.length; i++) {
        const currentItem = normalizedProducts[i];
        const product = currentItem.productDoc || await ProductModel.findOne({ _id: currentItem.productId });

        await ProductModel.findByIdAndUpdate(
            currentItem.productId,
            {
                countInStock: parseInt(currentItem.countInStock - currentItem.quantity),
                sale: parseInt((product?.sale || 0) + currentItem.quantity)
            },
            { new: true }
        );
    }

    const user = await UserModel.findOne({ _id: userId });

    await UserModel.findByIdAndUpdate(
        userId,
        {
            $addToSet: {
                orderHistory: order._id,
            },
        }
    );

    if (user?.email) {
        await sendEmailFun({
            sendTo: [user.email],
            subject: "Order Confirmation",
            text: "",
            html: OrderConfirmationEmail(user?.name, order)
        });
    }

    return order;
};

//createOrderController

export const createOrderController = async (request, response) => {
    try {
        const order = await createLocalOrderRecord({
            userId: request.userId,
            products: request.body.products,
            paymentId: request.body.paymentId,
            paymentStatus: request.body.payment_status,
            deliveryAddress: request.body.delivery_address,
            totalAmount: request.body.totalAmt,
            date: request.body.date,
        });


        return response.status(200).json({
            error: false,
            success: true,
            message: "Order Placed",
            order: order
        });


    } catch (error) {
        return response.status(error.statusCode || 500).json({
            message: error.message || error,
            error: true,
            success: false
        })
    }
}

//getOrderDetailsController

export async function getOrderDetailsController(request, response) {
    try {
        const { page, limit, orderType } = request.query;
        const pageNumber = Number.parseInt(page, 10);
        const limitNumber = Number.parseInt(limit, 10);
        const hasPagination = Number.isFinite(pageNumber) && pageNumber > 0 && Number.isFinite(limitNumber) && limitNumber > 0;
        const allOrders = await OrderModel.find()
            .sort({ createdAt: -1 })
            .populate('delivery_address userId');
        const filteredOrders = await filterOrdersByType(allOrders, orderType);
        const total = filteredOrders.length;
        const orderlist = hasPagination
            ? filteredOrders.slice((pageNumber - 1) * limitNumber, pageNumber * limitNumber)
            : filteredOrders;

        return response.json({
            message: "order list",
            data: orderlist,
            error: false,
            success: true,
            total: total,
            page: hasPagination ? pageNumber : 1,
            totalPages: hasPagination ? Math.ceil(total / limitNumber) : 1
        })
    } catch (error) {
        return response.status(500).json({
            message: error.message || error,
            error: true,
            success: false
        })
    }
}

//getUserOrderDetailsController

export async function getUserOrderDetailsController(request, response) {
    try {
        const userId = request.userId // order id
        const { page, limit, orderType } = request.query;
        const pageNumber = Number.parseInt(page, 10);
        const limitNumber = Number.parseInt(limit, 10);
        const hasPagination = Number.isFinite(pageNumber) && pageNumber > 0 && Number.isFinite(limitNumber) && limitNumber > 0;
        const allOrders = await OrderModel.find({ userId: userId })
            .sort({ createdAt: -1 })
            .populate('delivery_address userId');
        const filteredOrders = await filterOrdersByType(allOrders, orderType);
        const total = filteredOrders.length;
        const orderlist = hasPagination
            ? filteredOrders.slice((pageNumber - 1) * limitNumber, pageNumber * limitNumber)
            : filteredOrders;

        return response.json({
            message: "order list",
            data: orderlist,
            error: false,
            success: true,
            total: total,
            page: hasPagination ? pageNumber : 1,
            totalPages: hasPagination ? Math.ceil(total / limitNumber) : 1
        })
    } catch (error) {
        return response.status(500).json({
            message: error.message || error,
            error: true,
            success: false
        })
    }
}

//getTotalOrdersCountController

export async function getTotalOrdersCountController(request, response) {
    try {
        const ordersCount = await OrderModel.countDocuments();
        return response.status(200).json({
            error: false,
            success: true,
            count: ordersCount
        })

    } catch (error) {
        return response.status(500).json({
            message: error.message || error,
            error: true,
            success: false
        })
    }
}

//getPayPalClient

function getPayPalClient() {

    const environment =
        process.env.PAYPAL_MODE === "live"
            ? new paypal.core.LiveEnvironment(
                process.env.PAYPAL_CLIENT_ID_LIVE,
                process.env.PAYPAL_SECRET_LIVE
            )
            : new paypal.core.SandboxEnvironment(
                process.env.PAYPAL_CLIENT_ID_TEST,
                process.env.PAYPAL_SECRET_TEST
            );

    return new paypal.core.PayPalHttpClient(environment);


}

//createOrderPaypalController

export const createOrderPaypalController = async (request, response) => {
    try {
        const authenticatedUserId = request.userId;
        const cartItems = await CartProductModel.find({ userId: authenticatedUserId }).lean();

        await resolveCheckoutProducts(cartItems);

        const req = new paypal.orders.OrdersCreateRequest();
        req.prefer("return=representation");

        req.requestBody({
            intent: "CAPTURE",
            purchase_units: [{
                amount: {
                    currency_code: 'USD',
                    value: request.query.totalAmount
                }
            }]
        });


        try {
            const client = getPayPalClient();
            const order = await client.execute(req);
            response.json({ id: order.result.id });
        } catch (error) {
            console.error(error);
            response.status(500).send("Error creating PayPal order");
        }

    } catch (error) {
        return response.status(error.statusCode || 500).json({
            message: error.message || error,
            error: true,
            success: false
        })
    }
}

export const createOrderTamaraController = async (request, response) => {
    try {
        const authenticatedUserId = request.userId;
        const {
            delivery_address,
            products,
            totalAmount,
            successUrl,
            failureUrl,
            cancelUrl,
        } = request.body || {};

        if (!authenticatedUserId || !delivery_address || !Array.isArray(products) || products.length === 0) {
            return response.status(400).json({
                error: true,
                success: false,
                message: "Missing required fields for Tamara checkout.",
            });
        }

        const normalizedProducts = await resolveCheckoutProducts(products);

        const { tamaraApiToken, tamaraApiBaseUrl } = getTamaraApiConfig();

        if (!tamaraApiToken) {
            return response.status(400).json({
                error: true,
                success: false,
                message: "Tamara API token is missing. Add TAMARA_API_TOKEN to the server environment.",
            });
        }

        const [user, address] = await Promise.all([
            UserModel.findById(authenticatedUserId),
            AddressModel.findById(delivery_address),
        ]);

        if (!user || !address) {
            return response.status(404).json({
                error: true,
                success: false,
                message: "User or saved location not found.",
            });
        }

        const { firstName, lastName } = splitCustomerName(user?.name);
        const phoneNumber = normalizePhoneNumber(user?.mobile || address?.mobile);
        const countryCode = getCountryCode(address?.country);
        const baseSiteUrl = getBaseSiteUrl(request);
        const orderReferenceId = `TRA-${Date.now()}`;
        const computedTotalAmount = toAmount(
            totalAmount
            || normalizedProducts.reduce((sum, item) => sum + Number(item?.subTotal || 0), 0)
        );

        if (!phoneNumber) {
            return response.status(400).json({
                error: true,
                success: false,
                message: "Customer phone number is required for Tamara checkout.",
            });
        }

        const payload = {
            total_amount: {
                amount: computedTotalAmount,
                currency: "AED",
            },
            shipping_amount: {
                amount: 0,
                currency: "AED",
            },
            tax_amount: {
                amount: 0,
                currency: "AED",
            },
            order_reference_id: orderReferenceId,
            order_number: orderReferenceId,
            description: `Cutie Pie order with ${normalizedProducts.length} item(s)`,
            country_code: countryCode,
            payment_type: "PAY_BY_INSTALMENTS",
            locale: "en_US",
            is_mobile: false,
            platform: "cutiepieladiessalon.ae",
            merchant_url: {
                success: successUrl || `${baseSiteUrl}/order/success`,
                failure: failureUrl || `${baseSiteUrl}/order/failed`,
                cancel: cancelUrl || `${baseSiteUrl}/checkout`,
            },
            consumer: {
                first_name: firstName,
                last_name: lastName,
                phone_number: phoneNumber,
                email: user?.email || "",
            },
                shipping_address: {
                    first_name: firstName,
                    last_name: lastName,
                    line1: address?.address_line1 || "NA",
                    line2: address?.landmark || "",
                    region: address?.state || address?.city || "Dubai",
                    city: address?.city || "Dubai",
                    country_code: countryCode,
                    postal_code: address?.pincode || "00000",
                    phone_number: phoneNumber,
                },
            risk_assessment: {
                is_premium_customer: false,
                account_creation_date: new Date(user?.createdAt || Date.now()).toLocaleDateString("en-GB").replace(/\//g, "-"),
                total_order_count: Array.isArray(user?.orderHistory) ? user.orderHistory.length : 0,
                risk_score: 0,
                is_existing_customer: Boolean((user?.orderHistory || []).length),
                is_guest_user: false,
                is_phone_verified: Boolean(phoneNumber),
            },
            items: normalizedProducts.map((item) => ({
                reference_id: String(item?.productId || ""),
                sku: String(item?.productId || ""),
                type: "Physical",
                name: String(item?.productTitle || "Product").slice(0, 255),
                quantity: Number(item?.quantity || 1),
                item_url: `${baseSiteUrl}/product/${item?.productId || ""}`,
                image_url: item?.image || "",
                unit_price: {
                    amount: toAmount(item?.price),
                    currency: "AED",
                },
                tax_amount: {
                    amount: 0,
                    currency: "AED",
                },
                discount_amount: {
                    amount: 0,
                    currency: "AED",
                },
                total_amount: {
                    amount: toAmount(Number(item?.price || 0) * Number(item?.quantity || 0)),
                    currency: "AED",
                },
            })),
        };

        const tamaraResponse = await axios.post(
            `${tamaraApiBaseUrl}/checkout`,
            payload,
            {
                headers: {
                    Authorization: `Bearer ${tamaraApiToken}`,
                    "Content-Type": "application/json",
                },
            }
        );

        return response.status(200).json({
            success: true,
            error: false,
            checkoutUrl: tamaraResponse?.data?.checkout_url || "",
            orderId: tamaraResponse?.data?.order_id || "",
            checkoutId: tamaraResponse?.data?.checkout_id || "",
            orderReferenceId,
            data: tamaraResponse?.data,
        });
    } catch (error) {
        return response.status(error.statusCode || 500).json({
            message: error?.response?.data?.message || error?.response?.data || error.message || error,
            error: true,
            success: false
        });
    }
};

export const finalizeTamaraOrderController = async (request, response) => {
    try {
        const authenticatedUserId = request.userId;
        const {
            tamaraOrderId,
            delivery_address,
            products,
            totalAmt,
        } = request.body || {};

        if (!authenticatedUserId || !tamaraOrderId || !delivery_address || !Array.isArray(products) || products.length === 0) {
            return response.status(400).json({
                error: true,
                success: false,
                message: "Missing required fields to finalize Tamara order.",
            });
        }

        const normalizedProducts = await resolveCheckoutProducts(products);

        const existingOrder = await OrderModel.findOne({ paymentId: tamaraOrderId });

        if (existingOrder) {
            return response.status(200).json({
                error: false,
                success: true,
                message: "Tamara order already finalized.",
                order: existingOrder,
            });
        }

        const { tamaraApiToken, tamaraApiBaseUrl } = getTamaraApiConfig();

        if (!tamaraApiToken) {
            return response.status(400).json({
                error: true,
                success: false,
                message: "Tamara API token is missing. Add TAMARA_API_TOKEN to the server environment.",
            });
        }

        const tamaraHeaders = {
            Authorization: `Bearer ${tamaraApiToken}`,
            "Content-Type": "application/json",
        };

        const orderDetailsResponse = await axios.get(
            `${tamaraApiBaseUrl}/orders/${tamaraOrderId}`,
            { headers: tamaraHeaders }
        );

        let tamaraOrder = orderDetailsResponse?.data;
        let tamaraStatus = String(
            tamaraOrder?.status
            || tamaraOrder?.order_status
            || tamaraOrder?.payment_status
            || ""
        ).toLowerCase();

        if (tamaraStatus === "approved") {
            await axios.post(
                `${tamaraApiBaseUrl}/orders/${tamaraOrderId}/authorise`,
                {},
                { headers: tamaraHeaders }
            );

            const refreshedOrderResponse = await axios.get(
                `${tamaraApiBaseUrl}/orders/${tamaraOrderId}`,
                { headers: tamaraHeaders }
            );

            tamaraOrder = refreshedOrderResponse?.data;
            tamaraStatus = String(
                tamaraOrder?.status
                || tamaraOrder?.order_status
                || tamaraOrder?.payment_status
                || "authorised"
            ).toLowerCase();
        }

        const acceptedStatuses = new Set([
            "authorised",
            "authorized",
            "approved",
            "fully_captured",
            "partially_captured",
        ]);

        if (!acceptedStatuses.has(tamaraStatus)) {
            return response.status(400).json({
                error: true,
                success: false,
                message: `Tamara order is not ready yet. Current status: ${tamaraStatus || "unknown"}.`,
            });
        }

        const order = await createLocalOrderRecord({
            userId: authenticatedUserId,
            products: normalizedProducts,
            paymentId: tamaraOrderId,
            paymentStatus: `TAMARA_${tamaraStatus.toUpperCase()}`,
            deliveryAddress: delivery_address,
            totalAmount: totalAmt,
            date: formatOrderDate(),
        });

        return response.status(200).json({
            error: false,
            success: true,
            message: "Tamara order finalized successfully.",
            order,
            tamaraStatus,
        });
    } catch (error) {
        return response.status(error.statusCode || 500).json({
            message: error?.response?.data?.message || error?.response?.data || error.message || error,
            error: true,
            success: false
        });
    }
};

//captureOrderPaypalController

export const captureOrderPaypalController = async (request, response) => {
    try {
        const { paymentId } = request.body;

        const req = new paypal.orders.OrdersCaptureRequest(paymentId);
        req.requestBody({});

        const orderInfo = {
            userId: request.userId,
            products: request.body.products,
            paymentId: request.body.paymentId,
            payment_status: request.body.payment_status,
            delivery_address: request.body.delivery_address,
            totalAmt: request.body.totalAmount,
            date: request.body.date
        }

        const order = await createLocalOrderRecord({
            userId: orderInfo.userId,
            products: orderInfo.products,
            paymentId: orderInfo.paymentId,
            paymentStatus: orderInfo.payment_status,
            deliveryAddress: orderInfo.delivery_address,
            totalAmount: orderInfo.totalAmt,
            date: orderInfo.date,
        });


        return response.status(200).json(
            {
                success: true,
                error: false,
                order: order,
                message: "Order Placed"
            }
        );

    } catch (error) {
        return response.status(error.statusCode || 500).json({
            message: error.message || error,
            error: true,
            success: false
        })
    }
}

//updateOrderStatusController

export const updateOrderStatusController = async (request, response) => {
    try {
        const { id, order_status } = request.body;

        const updateOrder = await OrderModel.updateOne(
            {
                _id: id,
            },
            {
                order_status: order_status,
            },
            { new: true }
        )

        return response.json({
            message: "Update order status",
            success: true,
            error: false,
            data: updateOrder
        })
    } catch (error) {
        return response.status(500).json({
            message: error.message || error,
            error: true,
            success: false
        })
    }

}

//totalSalesController

export const totalSalesController = async (request, response) => {
    try {
        const currentYear = new Date().getFullYear();

        const ordersList = await OrderModel.find();

        let totalSales = 0;
        let monthlySales = [
            {
                name: 'JAN',
                TotalSales: 0
            },
            {
                name: 'FEB',
                TotalSales: 0
            },
            {
                name: 'MAR',
                TotalSales: 0
            },
            {
                name: 'APRIL',
                TotalSales: 0
            },
            {
                name: 'MAY',
                TotalSales: 0
            },
            {
                name: 'JUNE',
                TotalSales: 0
            },
            {
                name: 'JULY',
                TotalSales: 0
            },
            {
                name: 'AUG',
                TotalSales: 0
            },
            {
                name: 'SEP',
                TotalSales: 0
            },
            {
                name: 'OCT',
                TotalSales: 0
            },
            {
                name: 'NOV',
                TotalSales: 0
            },
            {
                name: 'DEC',
                TotalSales: 0
            },
        ]


        for (let i = 0; i < ordersList.length; i++) {
            totalSales = totalSales + parseInt(ordersList[i].totalAmt);
            const str = JSON.stringify(ordersList[i]?.createdAt);
            const year = str.substr(1, 4);
            const monthStr = str.substr(6, 8);
            const month = parseInt(monthStr.substr(0, 2));

            if (currentYear == year) {

                if (month === 1) {
                    monthlySales[0] = {
                        name: 'JAN',
                        TotalSales: monthlySales[0].TotalSales = parseInt(monthlySales[0].TotalSales) + parseInt(ordersList[i].totalAmt)
                    }
                }

                if (month === 2) {

                    monthlySales[1] = {
                        name: 'FEB',
                        TotalSales: monthlySales[1].TotalSales = parseInt(monthlySales[1].TotalSales) + parseInt(ordersList[i].totalAmt)
                    }
                }

                if (month === 3) {
                    monthlySales[2] = {
                        name: 'MAR',
                        TotalSales: monthlySales[2].TotalSales = parseInt(monthlySales[2].TotalSales) + parseInt(ordersList[i].totalAmt)
                    }
                }

                if (month === 4) {
                    monthlySales[3] = {
                        name: 'APRIL',
                        TotalSales: monthlySales[3].TotalSales = parseInt(monthlySales[3].TotalSales) + parseInt(ordersList[i].totalAmt)
                    }
                }

                if (month === 5) {
                    monthlySales[4] = {
                        name: 'MAY',
                        TotalSales: monthlySales[4].TotalSales = parseInt(monthlySales[4].TotalSales) + parseInt(ordersList[i].totalAmt)
                    }
                }

                if (month === 6) {
                    monthlySales[5] = {
                        name: 'JUNE',
                        TotalSales: monthlySales[5].TotalSales = parseInt(monthlySales[5].TotalSales) + parseInt(ordersList[i].totalAmt)
                    }
                }

                if (month === 7) {
                    monthlySales[6] = {
                        name: 'JULY',
                        TotalSales: monthlySales[6].TotalSales = parseInt(monthlySales[6].TotalSales) + parseInt(ordersList[i].totalAmt)
                    }
                }

                if (month === 8) {
                    monthlySales[7] = {
                        name: 'AUG',
                        TotalSales: monthlySales[7].TotalSales = parseInt(monthlySales[7].TotalSales) + parseInt(ordersList[i].totalAmt)
                    }
                }

                if (month === 9) {
                    monthlySales[8] = {
                        name: 'SEP',
                        TotalSales: monthlySales[8].TotalSales = parseInt(monthlySales[8].TotalSales) + parseInt(ordersList[i].totalAmt)
                    }
                }

                if (month === 10) {
                    monthlySales[9] = {
                        name: 'OCT',
                        TotalSales: monthlySales[9].TotalSales = parseInt(monthlySales[9].TotalSales) + parseInt(ordersList[i].totalAmt)
                    }
                }

                if (month === 11) {
                    monthlySales[10] = {
                        name: 'NOV',
                        TotalSales: monthlySales[10].TotalSales = parseInt(monthlySales[10].TotalSales) + parseInt(ordersList[i].totalAmt)
                    }
                }

                if (month === 12) {
                    monthlySales[11] = {
                        name: 'DEC',
                        TotalSales: monthlySales[11].TotalSales = parseInt(monthlySales[11].TotalSales) + parseInt(ordersList[i].totalAmt)
                    }
                }

            }


        }


        return response.status(200).json({
            totalSales: totalSales,
            monthlySales: monthlySales,
            error: false,
            success: true
        })

    } catch (error) {
        return response.status(500).json({
            message: error.message || error,
            error: true,
            success: false
        })
    }
}

//totalUsersController

export const totalUsersController = async (request, response) => {
    try {
        const users = await UserModel.aggregate([
            {
                $group: {
                    _id: {
                        year: { $year: "$createdAt" },
                        month: { $month: "$createdAt" }
                    },
                    count: { $sum: 1 },
                },
            },
            {
                $sort: { "_id.year": 1, "_id.month": 1 },
            },
        ]);



        let monthlyUsers = [
            {
                name: 'JAN',
                TotalUsers: 0
            },
            {
                name: 'FEB',
                TotalUsers: 0
            },
            {
                name: 'MAR',
                TotalUsers: 0
            },
            {
                name: 'APRIL',
                TotalUsers: 0
            },
            {
                name: 'MAY',
                TotalUsers: 0
            },
            {
                name: 'JUNE',
                TotalUsers: 0
            },
            {
                name: 'JULY',
                TotalUsers: 0
            },
            {
                name: 'AUG',
                TotalUsers: 0
            },
            {
                name: 'SEP',
                TotalUsers: 0
            },
            {
                name: 'OCT',
                TotalUsers: 0
            },
            {
                name: 'NOV',
                TotalUsers: 0
            },
            {
                name: 'DEC',
                TotalUsers: 0
            },
        ]




        for (let i = 0; i < users.length; i++) {

            if (users[i]?._id?.month === 1) {
                monthlyUsers[0] = {
                    name: 'JAN',
                    TotalUsers: users[i].count
                }
            }

            if (users[i]?._id?.month === 2) {
                monthlyUsers[1] = {
                    name: 'FEB',
                    TotalUsers: users[i].count
                }
            }

            if (users[i]?._id?.month === 3) {
                monthlyUsers[2] = {
                    name: 'MAR',
                    TotalUsers: users[i].count
                }
            }

            if (users[i]?._id?.month === 4) {
                monthlyUsers[3] = {
                    name: 'APRIL',
                    TotalUsers: users[i].count
                }
            }

            if (users[i]?._id?.month === 5) {
                monthlyUsers[4] = {
                    name: 'MAY',
                    TotalUsers: users[i].count
                }
            }

            if (users[i]?._id?.month === 6) {
                monthlyUsers[5] = {
                    name: 'JUNE',
                    TotalUsers: users[i].count
                }
            }

            if (users[i]?._id?.month === 7) {
                monthlyUsers[6] = {
                    name: 'JULY',
                    TotalUsers: users[i].count
                }
            }

            if (users[i]?._id?.month === 8) {
                monthlyUsers[7] = {
                    name: 'AUG',
                    TotalUsers: users[i].count
                }
            }

            if (users[i]?._id?.month === 9) {
                monthlyUsers[8] = {
                    name: 'SEP',
                    TotalUsers: users[i].count
                }
            }

            if (users[i]?._id?.month === 10) {
                monthlyUsers[9] = {
                    name: 'OCT',
                    TotalUsers: users[i].count
                }
            }

            if (users[i]?._id?.month === 11) {
                monthlyUsers[10] = {
                    name: 'NOV',
                    TotalUsers: users[i].count
                }
            }

            if (users[i]?._id?.month === 12) {
                monthlyUsers[11] = {
                    name: 'DEC',
                    TotalUsers: users[i].count
                }
            }

        }



        return response.status(200).json({
            TotalUsers: monthlyUsers,
            error: false,
            success: true
        })

    } catch (error) {
        return response.status(500).json({
            message: error.message || error,
            error: true,
            success: false
        })
    }
}

//deleteOrder

export async function deleteOrder(request, response) {
    const order = await OrderModel.findById(request.params.id);

    console.log(request.params.id)

    if (!order) {
        return response.status(404).json({
            message: "Order Not found",
            error: true,
            success: false
        })
    }


    const deletedOrder = await OrderModel.findByIdAndDelete(request.params.id);

    if (!deletedOrder) {
        response.status(404).json({
            message: "Order not deleted!",
            success: false,
            error: true
        });
    }

    return response.status(200).json({
        success: true,
        error: false,
        message: "Order Deleted!",
    });
}
