import AddOnModel from "../models/addon.model.js";
import BannerList2Model from "../models/bannerList2.model.js";
import BannerV1Model from "../models/bannerV1.model.js";
import BlogModel from "../models/blog.model.js";
import CategoryModel from "../models/category.modal.js";
import HomeSliderModel from "../models/homeSlider.modal.js";
import ProductModel from "../models/product.modal.js";
import ProfessionalModel from "../models/professional.model.js";
import {
    buildAvailabilityCalendar,
    normalizeId,
    serializeAddOn,
    serializeProfessional,
    serializeService,
} from "../utils/booking.utils.js";
import { isServiceProduct } from "../utils/productType.utils.js";

const parsePositiveInt = (value, fallback, max = 100) => {
    const parsed = Number.parseInt(value, 10);
    if (!Number.isFinite(parsed) || parsed <= 0) return fallback;
    return Math.min(parsed, max);
};

const buildServiceFilter = (query) => {
    const filter = {
        serviceType: "service",
        bookingEnabled: { $ne: false },
    };

    if (query.categoryId) {
        filter.$or = [
            { catId: query.categoryId },
            { subCatId: query.categoryId },
            { thirdsubCatId: query.categoryId },
        ];
    }

    if (query.search) {
        filter.$and = [
            ...(filter.$and || []),
            {
                $or: [
                    { name: { $regex: query.search, $options: "i" } },
                    { description: { $regex: query.search, $options: "i" } },
                    { brand: { $regex: query.search, $options: "i" } },
                    { catName: { $regex: query.search, $options: "i" } },
                    { subCat: { $regex: query.search, $options: "i" } },
                    { tags: { $regex: query.search, $options: "i" } },
                ],
            },
        ];
    }

    if (query.featured === "true") filter.isFeatured = true;

    return filter;
};

const buildServiceSort = (sort = "latest") => {
    switch (sort) {
        case "price_asc":
            return { price: 1, createdAt: -1 };
        case "price_desc":
            return { price: -1, createdAt: -1 };
        case "rating":
            return { rating: -1, ratingCount: -1, createdAt: -1 };
        case "popular":
            return { sale: -1, createdAt: -1 };
        default:
            return { createdAt: -1 };
    }
};

const getCategoryIdsFromService = (service) => {
    const ids = [service?.catId, service?.subCatId, service?.thirdsubCatId]
        .map((item) => normalizeId(item?._id || item))
        .filter(Boolean);

    return Array.from(new Set(ids));
};

export const listServices = async (request, response) => {
    try {
        const page = parsePositiveInt(request.query.page, 1, 100000);
        const limit = parsePositiveInt(request.query.limit, 12, 100);
        const filter = buildServiceFilter(request.query);
        const sort = buildServiceSort(request.query.sort);

        const [services, total] = await Promise.all([
            ProductModel.find(filter)
                .sort(sort)
                .skip((page - 1) * limit)
                .limit(limit)
                .lean(),
            ProductModel.countDocuments(filter),
        ]);

        const serialized = services.map(serializeService);

        return response.status(200).json({
            success: true,
            error: false,
            services: serialized,
            products: serialized,
            total,
            page,
            totalPages: Math.max(1, Math.ceil(total / limit)),
        });
    } catch (error) {
        return response.status(500).json({
            success: false,
            error: true,
            message: error.message || "Unable to load services",
        });
    }
};

export const getServiceHomePayload = async (_request, response) => {
    try {
        const [categories, services, homeSlides, promoBanners, secondaryBanners, blogs] = await Promise.all([
            CategoryModel.find({ parentId: null }).sort({ createdAt: 1 }).lean(),
            ProductModel.find({ bookingEnabled: { $ne: false } })
                .sort({ createdAt: -1 })
                .limit(12)
                .lean(),
            HomeSliderModel.find().sort({ createdAt: -1 }).limit(4).lean(),
            BannerV1Model.find().sort({ createdAt: -1 }).limit(8).lean(),
            BannerList2Model.find().sort({ createdAt: -1 }).limit(8).lean(),
            BlogModel.find().sort({ createdAt: -1 }).limit(4).lean(),
        ]);

        return response.status(200).json({
            success: true,
            error: false,
            categories,
            latestServices: services.map(serializeService),
            homeSlides,
            promoBanners,
            secondaryBanners,
            blogs,
        });
    } catch (error) {
        return response.status(500).json({
            success: false,
            error: true,
            message: error.message || "Unable to load home catalog",
        });
    }
};

export const getServiceById = async (request, response) => {
    try {
        const service = await ProductModel.findById(request.params.id).lean();

        if (!service || !isServiceProduct(service)) {
            return response.status(404).json({
                success: false,
                error: true,
                message: "Service not found",
            });
        }

        return response.status(200).json({
            success: true,
            error: false,
            service: serializeService(service),
        });
    } catch (error) {
        return response.status(500).json({
            success: false,
            error: true,
            message: error.message || "Unable to load service",
        });
    }
};

export const getServiceBookingExperience = async (request, response) => {
    try {
        const service = await ProductModel.findById(request.params.id).lean();

        if (!service || !isServiceProduct(service)) {
            return response.status(404).json({
                success: false,
                error: true,
                message: "Service not found",
            });
        }

        const categoryIds = getCategoryIdsFromService(service);
        const serviceId = normalizeId(service._id);

        const [addOns, professionals, relatedServices] = await Promise.all([
            AddOnModel.find({
                isActive: true,
                $or: [
                    { serviceIds: serviceId },
                    { categoryIds: { $in: categoryIds } },
                    { isGlobal: true },
                ],
            }).sort({ sortOrder: 1, createdAt: -1 }).lean(),
            ProfessionalModel.find({
                isActive: true,
                $or: [
                    { serviceIds: serviceId },
                    { categoryIds: { $in: categoryIds } },
                ],
            }).sort({ sortOrder: 1, createdAt: -1 }).lean(),
            ProductModel.find({
                _id: { $ne: service._id },
                serviceType: "service",
                bookingEnabled: { $ne: false },
                $or: [
                    service.subCatId ? { subCatId: service.subCatId } : null,
                    service.catId ? { catId: service.catId } : null,
                ].filter(Boolean),
            }).sort({ rating: -1, createdAt: -1 }).limit(6).lean(),
        ]);

        return response.status(200).json({
            success: true,
            error: false,
            service: serializeService(service),
            addOns: addOns.map(serializeAddOn),
            professionals: professionals.map(serializeProfessional),
            relatedServices: relatedServices.map(serializeService),
            availability: buildAvailabilityCalendar(service),
        });
    } catch (error) {
        return response.status(500).json({
            success: false,
            error: true,
            message: error.message || "Unable to load booking experience",
        });
    }
};
