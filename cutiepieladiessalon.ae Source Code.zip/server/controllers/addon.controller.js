import AddOnModel from "../models/addon.model.js";
import { serializeAddOn } from "../utils/booking.utils.js";
import { v2 as cloudinary } from 'cloudinary';
import fs from 'fs';

cloudinary.config({
    cloud_name: process.env.cloudinary_Config_Cloud_Name,
    api_key: process.env.cloudinary_Config_api_key,
    api_secret: process.env.cloudinary_Config_api_secret,
    secure: true,
});

let imagesArr = [];

const slugify = (value = "") => String(value)
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");

const toIdList = (value) => {
    if (!Array.isArray(value)) return [];
    return value.filter(Boolean);
};

const toStringList = (value) => {
    if (!Array.isArray(value)) return [];
    return value.map((item) => String(item || "").trim()).filter(Boolean);
};

export const uploadImages = async (request, response) => {
    try {
        imagesArr = [];

        const image = request.files;
        const options = {
            use_filename: true,
            unique_filename: false,
            overwrite: false,
        };

        for (let i = 0; i < image?.length; i++) {
            await cloudinary.uploader.upload(
                image[i].path,
                options,
                function (error, result) {
                    imagesArr.push(result.secure_url);
                    fs.unlinkSync(`uploads/${request.files[i].filename}`);
                }
            );
        }

        return response.status(200).json({
            images: imagesArr,
        });
    } catch (error) {
        return response.status(500).json({
            message: error.message || error,
            error: true,
            success: false,
        });
    }
};

export const listAddOns = async (request, response) => {
    try {
        const page = Math.max(1, Number.parseInt(request.query.page, 10) || 1);
        const limit = Math.min(100, Math.max(1, Number.parseInt(request.query.limit, 10) || 50));
        const search = String(request.query.search || "").trim();
        const serviceId = String(request.query.serviceId || "").trim();
        const categoryId = String(request.query.categoryId || "").trim();
        const activeOnly = String(request.query.activeOnly || "").toLowerCase() === "true";

        const filter = {};
        if (activeOnly) filter.isActive = true;
        if (serviceId) filter.serviceIds = serviceId;
        if (categoryId) filter.categoryIds = categoryId;
        if (search) {
            filter.$or = [
                { name: { $regex: search, $options: "i" } },
                { description: { $regex: search, $options: "i" } },
                { tags: { $regex: search, $options: "i" } },
            ];
        }

        const [items, total] = await Promise.all([
            AddOnModel.find(filter)
                .sort({ sortOrder: 1, createdAt: -1 })
                .skip((page - 1) * limit)
                .limit(limit)
                .lean(),
            AddOnModel.countDocuments(filter),
        ]);

        return response.status(200).json({
            success: true,
            error: false,
            data: items.map(serializeAddOn),
            total,
            page,
            totalPages: Math.max(1, Math.ceil(total / limit)),
        });
    } catch (error) {
        return response.status(500).json({
            success: false,
            error: true,
            message: error.message || "Unable to load add-ons",
        });
    }
};

export const getAddOn = async (request, response) => {
    try {
        const item = await AddOnModel.findById(request.params.id).lean();

        if (!item) {
            return response.status(404).json({
                success: false,
                error: true,
                message: "Add-on not found",
            });
        }

        return response.status(200).json({
            success: true,
            error: false,
            data: serializeAddOn(item),
        });
    } catch (error) {
        return response.status(500).json({
            success: false,
            error: true,
            message: error.message || "Unable to load add-on",
        });
    }
};

export const createAddOn = async (request, response) => {
    try {
        const document = await AddOnModel.create({
            name: request.body.name,
            slug: request.body.slug || slugify(request.body.name),
            description: request.body.description,
            image: request.body.image,
            durationMinutes: Number(request.body.durationMinutes || 15),
            price: Number(request.body.price || 0),
            oldPrice: Number(request.body.oldPrice || 0),
            badge: request.body.badge || "",
            tags: toStringList(request.body.tags),
            isGlobal: Boolean(request.body.isGlobal),
            isActive: request.body.isActive !== false,
            isFeatured: Boolean(request.body.isFeatured),
            sortOrder: Number(request.body.sortOrder || 0),
            categoryIds: toIdList(request.body.categoryIds),
            serviceIds: toIdList(request.body.serviceIds),
        });

        return response.status(201).json({
            success: true,
            error: false,
            message: "Add-on created successfully",
            data: serializeAddOn(document),
        });
    } catch (error) {
        return response.status(500).json({
            success: false,
            error: true,
            message: error.message || "Unable to create add-on",
        });
    }
};

export const updateAddOn = async (request, response) => {
    try {
        const document = await AddOnModel.findByIdAndUpdate(
            request.params.id,
            {
                name: request.body.name,
                slug: request.body.slug || slugify(request.body.name),
                description: request.body.description,
                image: request.body.image,
                durationMinutes: Number(request.body.durationMinutes || 15),
                price: Number(request.body.price || 0),
                oldPrice: Number(request.body.oldPrice || 0),
                badge: request.body.badge || "",
                tags: toStringList(request.body.tags),
                isGlobal: Boolean(request.body.isGlobal),
                isActive: request.body.isActive !== false,
                isFeatured: Boolean(request.body.isFeatured),
                sortOrder: Number(request.body.sortOrder || 0),
                categoryIds: toIdList(request.body.categoryIds),
                serviceIds: toIdList(request.body.serviceIds),
            },
            { new: true }
        ).lean();

        if (!document) {
            return response.status(404).json({
                success: false,
                error: true,
                message: "Add-on not found",
            });
        }

        return response.status(200).json({
            success: true,
            error: false,
            message: "Add-on updated successfully",
            data: serializeAddOn(document),
        });
    } catch (error) {
        return response.status(500).json({
            success: false,
            error: true,
            message: error.message || "Unable to update add-on",
        });
    }
};

export const deleteAddOn = async (request, response) => {
    try {
        const document = await AddOnModel.findByIdAndDelete(request.params.id).lean();

        if (!document) {
            return response.status(404).json({
                success: false,
                error: true,
                message: "Add-on not found",
            });
        }

        return response.status(200).json({
            success: true,
            error: false,
            message: "Add-on deleted successfully",
        });
    } catch (error) {
        return response.status(500).json({
            success: false,
            error: true,
            message: error.message || "Unable to delete add-on",
        });
    }
};
