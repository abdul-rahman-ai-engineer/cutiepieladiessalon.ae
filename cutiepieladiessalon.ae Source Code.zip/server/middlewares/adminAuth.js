import UserModel from "../models/user.model.js";
import { buildUserAccessProfile, isAdminUser } from "../utils/admin.utils.js";

const adminAuth = async (request, response, next) => {
    try {
        if (!request.userId) {
            return response.status(401).json({
                success: false,
                error: true,
                message: "Authentication required",
            });
        }

        if (request.isAdmin === true) {
            return next();
        }

        const user = await UserModel.findById(request.userId).select("role isAdmin").lean();

        if (!user || !isAdminUser(user)) {
            return response.status(403).json({
                success: false,
                error: true,
                message: "Admin access required",
            });
        }

        const accessProfile = buildUserAccessProfile(user);
        request.userRole = accessProfile.role;
        request.isAdmin = accessProfile.isAdmin;

        next();
    } catch (error) {
        return response.status(500).json({
            success: false,
            error: true,
            message: error.message || "Unable to verify admin access",
        });
    }
};

export default adminAuth;
