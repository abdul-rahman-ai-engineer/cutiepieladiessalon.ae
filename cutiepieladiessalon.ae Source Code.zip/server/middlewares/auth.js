import jwt from 'jsonwebtoken'
import { isAdminUser, normalizeUserRole } from "../utils/admin.utils.js";

const auth = async(request,response,next)=>{
    try {
        const token = request.cookies.accessToken || request?.headers?.authorization?.split(" ")[1];

        // if(!token){
        //    token = request.query.token; 
        // }

        if(!token){
            return response.status(401).json({
                message : "Provide token"
            })
        }

        const decode = await jwt.verify(token,process.env.SECRET_KEY_ACCESS_TOKEN);

        if(!decode){
            return response.status(401).json({
                message : "unauthorized access",
                error : true,
                success : false
            })
        }

        request.userId = decode?.id || decode?._id
        request.userRole = normalizeUserRole(decode?.role)
        request.isAdmin = isAdminUser(decode)

        next()

    } catch (error) {
        return response.status(401).json({
            message : "You have not login",///error.message || error,
            error : true,
            success : false
        })
    }
}

export default auth





