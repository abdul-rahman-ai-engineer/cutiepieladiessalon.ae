import mongoose from "mongoose";
import connectDB from "../config/connectDb.js";
import UserModel from "../models/user.model.js";

const [, , emailArg, roleArg = "ADMIN"] = process.argv;
const email = String(emailArg || "").trim().toLowerCase();
const normalizedRole = String(roleArg || "ADMIN").trim().toUpperCase() === "ADMIN"
    ? "ADMIN"
    : "USER";
const isAdmin = normalizedRole === "ADMIN";

if (!email) {
    console.error("Usage: npm run admin:set-user -- <email> [ADMIN|USER]");
    process.exit(1);
}

try {
    await connectDB();

    const user = await UserModel.findOneAndUpdate(
        { email },
        {
            $set: {
                role: normalizedRole,
                isAdmin,
            },
        },
        {
            new: true,
        }
    ).select("name email role isAdmin");

    if (!user) {
        console.error(`No user found for ${email}`);
        process.exitCode = 1;
    } else {
        console.log(`Updated ${user.email}`);
        console.log(`Role: ${user.role}`);
        console.log(`isAdmin: ${user.isAdmin}`);
    }
} catch (error) {
    console.error(error?.message || error);
    process.exitCode = 1;
} finally {
    await mongoose.connection.close().catch(() => null);
}
