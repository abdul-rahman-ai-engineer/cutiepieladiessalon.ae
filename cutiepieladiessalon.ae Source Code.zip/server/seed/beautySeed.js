import mongoose from "mongoose";
import dotenv from "dotenv";
import connectDB from "../config/connectDb.js";
import AddOnModel from "../models/addon.model.js";
import BannerList2Model from "../models/bannerList2.model.js";
import BannerV1Model from "../models/bannerV1.model.js";
import BlogModel from "../models/blog.model.js";
import CategoryModel from "../models/category.modal.js";
import HomeSliderModel from "../models/homeSlider.modal.js";
import ProductModel from "../models/product.modal.js";
import ProfessionalModel from "../models/professional.model.js";

dotenv.config();

const shouldReset = process.argv.includes("--reset");

const rootCategories = [
  { name: "Nails", image: "/banner1.webp" },
  { name: "Hair Removal", image: "/banner2.webp" },
  { name: "Facial", image: "/banner3.webp" },
  { name: "Hair", image: "/banner4.jpg" },
  { name: "Massage", image: "/banner5.webp" },
  { name: "Combos", image: "/banner6.webp" },
];

const serviceCatalog = [
  {
    name: "Classic Manicure",
    catName: "Nails",
    description: "A tidy, elegant manicure with shaping, cuticle care, buffing, and glossy polish.",
    image: "/banner1.webp",
    price: 59,
    oldPrice: 80,
    durationMinutes: 45,
    badge: "Most booked",
    highlights: ["Classic nail shaping", "Cuticle cleanup", "Gloss finish"],
    includes: ["Sanitized tool setup", "Polish application", "Aftercare advice"],
    benefits: ["Routine maintenance", "Event-ready hands", "Quick refresh"],
    tags: ["nails", "manicure", "polish"],
  },
  {
    name: "Brazilian Wax",
    catName: "Hair Removal",
    description: "Salon-grade waxing with gentle prep and a soothing finish for smoother skin.",
    image: "/banner5.webp",
    price: 110,
    oldPrice: 145,
    durationMinutes: 40,
    badge: "Smooth skin",
    highlights: ["Pre-wax skin prep", "Sensitive-skin wax", "Aftercare lotion"],
    includes: ["Consultation", "Waxing service", "Soothing gel"],
    benefits: ["Longer-lasting result", "Less daily maintenance", "Soft finish"],
    tags: ["wax", "hair removal"],
  },
  {
    name: "Dermalogica Facial",
    catName: "Facial",
    description: "A brightening at-home facial with double cleanse, exfoliation, mask, and finishing serum.",
    image: "/banner3.webp",
    price: 209,
    oldPrice: 300,
    durationMinutes: 60,
    badge: "Glow boost",
    highlights: ["Deep cleanse", "Hydration mask", "Facial massage"],
    includes: ["Skin consultation", "Premium products", "Glow finishing care"],
    benefits: ["Brighter skin", "Hydration", "Relaxed facial tension"],
    tags: ["facial", "glow", "skincare"],
  },
  {
    name: "Blow-Dry & Curls",
    catName: "Hair",
    description: "A polished blow-dry with soft, camera-ready curls styled for volume and movement.",
    image: "/banner4.jpg",
    price: 89,
    oldPrice: 100,
    durationMinutes: 45,
    badge: "Event prep",
    highlights: ["Heat-protect styling", "Loose curls", "Finishing serum"],
    includes: ["Blow-dry", "Curl styling", "Finishing hold"],
    benefits: ["Party-ready finish", "Smooth texture", "Longer hold"],
    tags: ["hair", "styling", "curls"],
  },
  {
    name: "Relaxing Head Massage",
    catName: "Massage",
    description: "A soothing scalp and temple massage that relieves pressure and eases screen-day tension.",
    image: "/banner2.webp",
    price: 70,
    oldPrice: 90,
    durationMinutes: 30,
    badge: "Stress relief",
    highlights: ["Pressure-point focus", "Temple massage", "Calming finish"],
    includes: ["Scalp massage", "Pressure relief", "Shoulder settling"],
    benefits: ["Relaxation", "Reduced tension", "Quick wellness break"],
    tags: ["massage", "head", "relax"],
  },
  {
    name: "Classic Mani-Pedi Combo",
    catName: "Combos",
    description: "A balanced manicure and pedicure session designed for polished, well-groomed hands and feet.",
    image: "/banner6.webp",
    price: 99,
    oldPrice: 180,
    durationMinutes: 75,
    badge: "Combo deal",
    highlights: ["Hand + foot grooming", "Polish refresh", "All-in-one visit"],
    includes: ["Manicure", "Pedicure", "Cuticle care", "Moisture finish"],
    benefits: ["Great value", "Full refresh", "Longer-lasting polish"],
    tags: ["combo", "mani", "pedi"],
  },
];

const addOnCatalog = [
  {
    name: "Collagen Gloves",
    service: "Classic Manicure",
    price: 25,
    oldPrice: 35,
    durationMinutes: 15,
    image: "/banner1.webp",
    description: "A nourishing collagen treatment for softer, more hydrated hands.",
  },
  {
    name: "Foot Massage",
    service: "Classic Mani-Pedi Combo",
    price: 35,
    oldPrice: 50,
    durationMinutes: 20,
    image: "/banner6.webp",
    description: "Extra foot relaxation with targeted pressure and soothing lotion.",
  },
  {
    name: "Head Massage",
    service: "Dermalogica Facial",
    price: 35,
    oldPrice: 55,
    durationMinutes: 20,
    image: "/banner3.webp",
    description: "A calming scalp add-on that turns the visit into a deeper reset.",
  },
];

const professionalCatalog = [
  {
    name: "Menuka S.",
    title: "Senior Beauty Therapist",
    avatar: "/user.jpg",
    bio: "Known for polished finishes, calm communication, and event-ready beauty styling.",
    services: ["Classic Manicure", "Classic Mani-Pedi Combo", "Dermalogica Facial"],
    specialties: ["Nails", "Facials", "Combo care"],
    badges: ["Top rated", "Fast response"],
  },
  {
    name: "Bharati K.",
    title: "Home Salon Specialist",
    avatar: "/user.jpg",
    bio: "A versatile at-home professional focused on smooth service flow and client comfort.",
    services: ["Brazilian Wax", "Relaxing Head Massage", "Dermalogica Facial"],
    specialties: ["Hair removal", "Massage", "Skin prep"],
    badges: ["Highly requested", "Gentle approach"],
  },
  {
    name: "Ayesha R.",
    title: "Hair Styling Artist",
    avatar: "/user.jpg",
    bio: "Styles camera-ready blow-dries and soft curls with long-wear finishing techniques.",
    services: ["Blow-Dry & Curls"],
    specialties: ["Blow-dry", "Styling", "Occasion hair"],
    badges: ["Event styling", "Salon polish"],
  },
];

const blogEntries = [
  {
    title: "How a Spa Pedicure Differs From a Traditional Pedicure",
    description: "A spa pedicure adds elevated soaking, relaxation, and treatment extras that make the session feel restorative instead of purely maintenance-focused.",
    images: ["/banner6.webp"],
  },
  {
    title: "How Volume Lash Extensions Enhance Definition Without Mascara",
    description: "Volume lash services help create a fuller eye look while keeping everyday makeup faster and lighter.",
    images: ["/banner3.webp"],
  },
  {
    title: "What Makes Polygel Nail Extensions Different From Acrylic or Gel",
    description: "Polygel is lightweight, sculptable, and often chosen for clients who want shape with a softer feel.",
    images: ["/banner1.webp"],
  },
];

const homeSlides = ["/banner1.webp", "/banner2.webp", "/banner3.webp", "/banner4.jpg"];

const upsertCategory = async ({ name, image }) => {
  return CategoryModel.findOneAndUpdate(
    { name, parentId: null },
    {
      name,
      images: [image],
      parentId: null,
      parentCatName: "",
    },
    { upsert: true, new: true }
  );
};

const run = async () => {
  await connectDB();

  if (shouldReset) {
    await Promise.all([
      AddOnModel.deleteMany({}),
      ProfessionalModel.deleteMany({}),
      ProductModel.deleteMany({}),
      BlogModel.deleteMany({}),
      HomeSliderModel.deleteMany({}),
      BannerV1Model.deleteMany({}),
      BannerList2Model.deleteMany({}),
      CategoryModel.deleteMany({}),
    ]);
  }

  const categoryMap = {};
  for (const category of rootCategories) {
    const document = await upsertCategory(category);
    categoryMap[category.name] = document;
  }

  const serviceMap = {};
  for (const service of serviceCatalog) {
    const category = categoryMap[service.catName];
    const document = await ProductModel.findOneAndUpdate(
      { name: service.name },
      {
        name: service.name,
        description: service.description,
        shortDescription: service.description,
        images: [service.image],
        bannerimages: [service.image],
        bannerTitleName: service.badge,
        isDisplayOnHomeBanner: true,
        brand: "Cutie Pie Beauty Salon",
        price: service.price,
        oldPrice: service.oldPrice,
        catName: service.catName,
        catId: category?._id || null,
        subCat: service.catName,
        subCatId: null,
        thirdsubCat: "",
        thirdsubCatId: null,
        category: category?._id || null,
        countInStock: 12,
        rating: 4.8,
        ratingCount: 120,
        isFeatured: true,
        discount: Math.round(((service.oldPrice - service.price) / service.oldPrice) * 100),
        sale: 0,
        productRam: [],
        size: [],
        productWeight: [],
        serviceType: "service",
        bookingEnabled: true,
        locationType: "home",
        durationMinutes: service.durationMinutes,
        instantDurationMinutes: 30,
        serviceFee: 12,
        badge: service.badge,
        highlights: service.highlights,
        includes: service.includes,
        benefits: service.benefits,
        tags: service.tags,
        faqs: [
          {
            question: "Can I book this at home?",
            answer: "Yes. Cutie Pie professionals arrive with salon-grade tools and setup.",
          },
          {
            question: "Can I request a professional?",
            answer: "Yes. You can choose auto-assign or request a preferred specialist during booking.",
          },
        ],
        availabilityWindow: {
          startHour: 10,
          endHour: 22,
          intervalMinutes: 30,
        },
      },
      { upsert: true, new: true }
    );

    serviceMap[service.name] = document;
  }

  for (const addOn of addOnCatalog) {
    const service = serviceMap[addOn.service];
    const category = categoryMap[service?.catName || ""];

    await AddOnModel.findOneAndUpdate(
      { name: addOn.name },
      {
        name: addOn.name,
        slug: addOn.name.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
        description: addOn.description,
        image: addOn.image,
        durationMinutes: addOn.durationMinutes,
        price: addOn.price,
        oldPrice: addOn.oldPrice,
        isActive: true,
        isFeatured: true,
        categoryIds: category ? [category._id] : [],
        serviceIds: service ? [service._id] : [],
      },
      { upsert: true, new: true }
    );
  }

  const allAddOns = await AddOnModel.find().lean();

  for (const professional of professionalCatalog) {
    const linkedServices = professional.services.map((name) => serviceMap[name]?._id).filter(Boolean);
    const linkedCategories = professional.services
      .map((name) => serviceMap[name]?.catId)
      .filter(Boolean);

    await ProfessionalModel.findOneAndUpdate(
      { name: professional.name },
      {
        name: professional.name,
        title: professional.title,
        avatar: professional.avatar,
        bio: professional.bio,
        rating: 4.8,
        reviewCount: 100,
        yearsExperience: 5,
        responseTimeMinutes: 30,
        city: "Dubai",
        languages: ["English", "Arabic"],
        specialties: professional.specialties,
        badges: professional.badges,
        serviceIds: linkedServices,
        categoryIds: linkedCategories,
        isAutoAssignable: true,
        isActive: true,
        availabilityWindow: {
          startHour: 10,
          endHour: 22,
          intervalMinutes: 30,
        },
      },
      { upsert: true, new: true }
    );
  }

  const allProfessionals = await ProfessionalModel.find().lean();

  for (const service of serviceCatalog) {
    const linkedAddOns = allAddOns
      .filter((item) => item.serviceIds.some((serviceId) => String(serviceId) === String(serviceMap[service.name]?._id)))
      .map((item) => item._id);

    const linkedProfessionals = allProfessionals
      .filter((item) => item.serviceIds.some((serviceId) => String(serviceId) === String(serviceMap[service.name]?._id)))
      .map((item) => item._id);

    await ProductModel.findByIdAndUpdate(serviceMap[service.name]?._id, {
      addOnIds: linkedAddOns,
      professionalIds: linkedProfessionals,
    });
  }

  for (const item of blogEntries) {
    await BlogModel.findOneAndUpdate(
      { title: item.title },
      item,
      { upsert: true, new: true }
    );
  }

  if (shouldReset) {
    await HomeSliderModel.deleteMany({});
  }
  for (const image of homeSlides) {
    const exists = await HomeSliderModel.findOne({ images: [image] }).lean();
    if (!exists) {
      await HomeSliderModel.create({ images: [image] });
    }
  }

  await BannerV1Model.findOneAndUpdate(
    { bannerTitle: "Salon Glow Essentials" },
    {
      bannerTitle: "Salon Glow Essentials",
      images: ["/banner3.webp"],
      catId: String(categoryMap.Facial?._id || ""),
      subCatId: "",
      thirdsubCatId: "",
      price: 209,
      alignInfo: "left",
    },
    { upsert: true, new: true }
  );

  await BannerList2Model.findOneAndUpdate(
    { images: ["/banner6.webp"] },
    {
      images: ["/banner6.webp"],
      catId: String(categoryMap.Combos?._id || ""),
      subCatId: "",
      thirdsubCatId: "",
    },
    { upsert: true, new: true }
  );

  console.log("Cutie Pie Beauty Salon seed completed.");
  await mongoose.disconnect();
};

run().catch(async (error) => {
  console.error("Seed failed:", error);
  await mongoose.disconnect();
  process.exit(1);
});
