import mongoose from "mongoose";

const bookingItemSchema = new mongoose.Schema(
    {
        addOnId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "AddOn",
            default: null,
        },
        name: {
            type: String,
            default: '',
        },
        image: {
            type: String,
            default: '',
        },
        durationMinutes: {
            type: Number,
            default: 0,
        },
        price: {
            type: Number,
            default: 0,
        },
    },
    { _id: false }
);

const bookingAddressSchema = new mongoose.Schema(
    {
        addressType: { type: String, default: '' },
        addressLine1: { type: String, default: '' },
        city: { type: String, default: '' },
        state: { type: String, default: '' },
        country: { type: String, default: '' },
        landmark: { type: String, default: '' },
        pincode: { type: String, default: '' },
        mobile: { type: String, default: '' },
    },
    { _id: false }
);

const bookingProfessionalSchema = new mongoose.Schema(
    {
        name: { type: String, default: '' },
        title: { type: String, default: '' },
        avatar: { type: String, default: '' },
        rating: { type: Number, default: 0 },
    },
    { _id: false }
);

const bookingServiceSchema = new mongoose.Schema(
    {
        name: { type: String, default: '' },
        image: { type: String, default: '' },
        categoryName: { type: String, default: '' },
        durationMinutes: { type: Number, default: 0 },
        price: { type: Number, default: 0 },
    },
    { _id: false }
);

const bookingVoucherSchema = new mongoose.Schema(
    {
        code: { type: String, default: '' },
        label: { type: String, default: '' },
        type: { type: String, default: '' },
        amount: { type: Number, default: 0 },
    },
    { _id: false }
);

const bookingSummarySchema = new mongoose.Schema(
    {
        serviceBase: { type: Number, default: 0 },
        addOnTotal: { type: Number, default: 0 },
        subtotal: { type: Number, default: 0 },
        serviceFee: { type: Number, default: 0 },
        discount: { type: Number, default: 0 },
        total: { type: Number, default: 0 },
    },
    { _id: false }
);

const bookingSchema = new mongoose.Schema(
    {
        userId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: true,
        },
        serviceId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Product",
            required: true,
        },
        serviceSnapshot: {
            type: bookingServiceSchema,
            default: () => ({}),
        },
        quantity: {
            type: Number,
            default: 1,
        },
        addOns: {
            type: [bookingItemSchema],
            default: [],
        },
        professionalId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Professional",
            default: null,
        },
        professionalSnapshot: {
            type: bookingProfessionalSchema,
            default: () => ({}),
        },
        professionalPreference: {
            type: String,
            enum: ["auto", "specific"],
            default: "auto",
        },
        instantRequested: {
            type: Boolean,
            default: false,
        },
        bookingDate: {
            type: String,
            default: '',
        },
        bookingDayLabel: {
            type: String,
            default: '',
        },
        startTime: {
            type: String,
            default: '',
        },
        endTime: {
            type: String,
            default: '',
        },
        slotLabel: {
            type: String,
            default: '',
        },
        instructions: {
            type: String,
            default: '',
            trim: true,
        },
        addressId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "address",
            default: null,
        },
        addressSnapshot: {
            type: bookingAddressSchema,
            default: () => ({}),
        },
        voucher: {
            type: bookingVoucherSchema,
            default: () => ({}),
        },
        paymentMethod: {
            type: String,
            enum: ["card", "cash", "tamara"],
            default: "card",
        },
        paymentStatus: {
            type: String,
            enum: ["pending", "authorized", "paid", "cash_on_visit", "failed"],
            default: "pending",
        },
        paymentId: {
            type: String,
            default: '',
        },
        paymentReferenceId: {
            type: String,
            default: '',
        },
        status: {
            type: String,
            enum: ["draft", "confirmed", "scheduled", "in_progress", "completed", "cancelled"],
            default: "confirmed",
        },
        summary: {
            type: bookingSummarySchema,
            default: () => ({}),
        },
        orderId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "order",
            default: null,
        },
    },
    { timestamps: true }
);

bookingSchema.set("toJSON", { virtuals: true });
bookingSchema.set("toObject", { virtuals: true });

bookingSchema.virtual("bookingReference").get(function bookingReferenceGetter() {
    if (!this?._id) {
        return "";
    }

    return `BKG-${String(this._id).slice(-8).toUpperCase()}`;
});

bookingSchema.index({ userId: 1, createdAt: -1 });
bookingSchema.index({ status: 1, bookingDate: 1 });

const BookingModel = mongoose.model("Booking", bookingSchema);

export default BookingModel;
