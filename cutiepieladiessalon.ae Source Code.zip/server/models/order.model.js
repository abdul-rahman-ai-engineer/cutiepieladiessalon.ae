import mongoose from "mongoose";

const orderSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.ObjectId,
        ref: 'User'
    },
    orderType: {
        type: String,
        enum: ['PRODUCT', 'BOOKING'],
        default: 'PRODUCT',
    },
    products: [
        {
            productId: {
                type: String
            },
            productTitle: {
                type: String
            },
            quantity: {
                type: Number
            },
            price: {
                type: Number
            },
            image: {
                type: String
            },
            subTotal: {
                type: Number
            }
        }
    ],
    bookingId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Booking',
        default: null,
    },
    serviceId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Product',
        default: null,
    },
    serviceTitle: {
        type: String,
        default: '',
    },
    bookingDate: {
        type: String,
        default: '',
    },
    bookingSlot: {
        type: String,
        default: '',
    },
    professionalName: {
        type: String,
        default: '',
    },
    paymentMethod: {
        type: String,
        default: '',
    },
    paymentSummary: {
        serviceBase: { type: Number, default: 0 },
        addOnTotal: { type: Number, default: 0 },
        subtotal: { type: Number, default: 0 },
        serviceFee: { type: Number, default: 0 },
        discount: { type: Number, default: 0 },
        total: { type: Number, default: 0 },
    },
    customerNotes: {
        type: String,
        default: '',
    },
    addressSnapshot: {
        addressType: { type: String, default: '' },
        addressLine1: { type: String, default: '' },
        city: { type: String, default: '' },
        state: { type: String, default: '' },
        country: { type: String, default: '' },
        landmark: { type: String, default: '' },
        pincode: { type: String, default: '' },
        mobile: { type: String, default: '' },
    },
    paymentId: {
        type: String,
        default: ""
    },
    paymentReferenceId: {
        type: String,
        default: ""
    },
    payment_status : {
        type : String,
        default : ""
    },
    order_status : {
        type : String,
        default : "confirm"
    },
    delivery_address: {
        type: mongoose.Schema.ObjectId,
        ref: 'address'
    },
    totalAmt: {
        type: Number,
        default: 0
    }
}, {
    timestamps: true
})

const OrderModel = mongoose.model('order', orderSchema)

export default OrderModel
