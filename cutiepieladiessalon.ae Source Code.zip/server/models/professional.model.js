import mongoose from "mongoose";

const professionalSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
            trim: true,
        },
        title: {
            type: String,
            default: '',
            trim: true,
        },
        avatar: {
            type: String,
            default: '',
        },
        bio: {
            type: String,
            default: '',
            trim: true,
        },
        rating: {
            type: Number,
            default: 4.8,
        },
        reviewCount: {
            type: Number,
            default: 0,
        },
        yearsExperience: {
            type: Number,
            default: 3,
        },
        responseTimeMinutes: {
            type: Number,
            default: 30,
        },
        city: {
            type: String,
            default: 'Dubai',
        },
        languages: {
            type: [String],
            default: ['English', 'Arabic'],
        },
        specialties: {
            type: [String],
            default: [],
        },
        badges: {
            type: [String],
            default: [],
        },
        isAutoAssignable: {
            type: Boolean,
            default: true,
        },
        isActive: {
            type: Boolean,
            default: true,
        },
        sortOrder: {
            type: Number,
            default: 0,
        },
        categoryIds: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: "Category",
            }
        ],
        serviceIds: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: "Product",
            }
        ],
        availabilityWindow: {
            startHour: {
                type: Number,
                default: 10,
            },
            endHour: {
                type: Number,
                default: 22,
            },
            intervalMinutes: {
                type: Number,
                default: 30,
            },
        },
    },
    { timestamps: true }
);

professionalSchema.index({ isActive: 1, sortOrder: 1, createdAt: -1 });

const ProfessionalModel = mongoose.model("Professional", professionalSchema);

export default ProfessionalModel;
