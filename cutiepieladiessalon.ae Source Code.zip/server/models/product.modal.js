import mongoose from 'mongoose';

const productAttributeSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            default: '',
            trim: true,
        },
        value: {
            type: String,
            default: '',
        },
    },
    { _id: false }
);

const productFaqSchema = new mongoose.Schema(
    {
        question: {
            type: String,
            default: '',
            trim: true,
        },
        answer: {
            type: String,
            default: '',
            trim: true,
        },
    },
    { _id: false }
);

const availabilityWindowSchema = new mongoose.Schema(
    {
        startHour: {
            type: Number,
            default: 10,
        },
        endHour: {
            type: Number,
            default: 22,
        },
        intervalMinutes: {
            type: Number,
            default: 30,
        },
    },
    { _id: false }
);

const productSchema = mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    sku: {
        type: String,
        default: '',
    },
    product_id: {
        type: String,
        default: '',
    },
    description: {
        type: String,
        required: true
    },
    shortDescription: {
        type: String,
        default: ''
    },
    images: [
        {
            type: String,
            required: true
        }
    ],
    brand: {
        type: String,
        default: ''
    },
    price: {
        type: Number,
        default: 0
    },
    oldPrice: {
        type: Number,
        default: 0
    },
    catName:{
        type:String,
        default:''
    },
    catId:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Category',
        default: null
    },
    subCatId:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Category',
        default: null
    },
    subCat:{
        type:String,
        default:''
    },
    thirdsubCat:{
        type:String,
        default:''
    },
    thirdsubCatId:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Category',
        default: null
    },
    category: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Category',
        default: null
    },
    countInStock: {
        type: Number,
        required: true,
    },
    rating: {
        type: Number,
        default: 0,
    },
    isFeatured: {
        type: Boolean,
        default: false,
    },
    discount: {
        type: Number,
        required: true,
    },
    sale: {
        type: Number,
        default:0
    },
    productRam: [
        {
            type: String,
            default: null,
        }
    ],
    size: [
        {
            type: String,
            default: null,
        }
    ],
    productWeight: [
        {
            type: String,
            default: null,
        }
    ],
    attributes: {
        type: [productAttributeSchema],
        default: [],
    },
    specifications: [
        {
            name: { type: String, default: '' },
            values: { type: [String], default: [] },
            visible: { type: Boolean, default: true },
            scope: { type: String, enum: ['global', 'custom'], default: 'custom' }
        }
    ],
    bannerimages: [
        {
            type: String,
            required: true
        }
    ],
    bannerTitleName: {
        type: String,
        default: '',
    },
    isDisplayOnHomeBanner: {
        type: Boolean,
        default: false,
    },
    serviceType: {
        type: String,
        enum: ['service', 'product'],
        default: 'service',
    },
    bookingEnabled: {
        type: Boolean,
        default: true,
    },
    locationType: {
        type: String,
        enum: ['home', 'salon'],
        default: 'home',
    },
    durationMinutes: {
        type: Number,
        default: 60,
    },
    instantDurationMinutes: {
        type: Number,
        default: 30,
    },
    serviceFee: {
        type: Number,
        default: 12,
    },
    ratingCount: {
        type: Number,
        default: 0,
    },
    badge: {
        type: String,
        default: '',
        trim: true,
    },
    highlights: {
        type: [String],
        default: [],
    },
    includes: {
        type: [String],
        default: [],
    },
    benefits: {
        type: [String],
        default: [],
    },
    tags: {
        type: [String],
        default: [],
    },
    faqs: {
        type: [productFaqSchema],
        default: [],
    },
    availabilityWindow: {
        type: availabilityWindowSchema,
        default: () => ({
            startHour: 10,
            endHour: 22,
            intervalMinutes: 30,
        }),
    },
    addOnIds: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'AddOn',
        }
    ],
    professionalIds: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Professional',
        }
    ],
},{
    timestamps : true
});

productSchema.index({ createdAt: -1 });
productSchema.index({ catId: 1, createdAt: -1 });
productSchema.index({ subCatId: 1, createdAt: -1 });
productSchema.index({ thirdsubCatId: 1, createdAt: -1 });
productSchema.index({ isDisplayOnHomeBanner: 1, createdAt: -1 });
productSchema.index({ bookingEnabled: 1, createdAt: -1 });


const ProductModel = mongoose.model('Product',productSchema)

export default ProductModel
