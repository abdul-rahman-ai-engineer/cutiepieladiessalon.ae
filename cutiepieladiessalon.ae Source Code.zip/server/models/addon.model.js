import mongoose from "mongoose";

const addOnSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
            trim: true,
        },
        slug: {
            type: String,
            default: '',
            trim: true,
        },
        description: {
            type: String,
            default: '',
            trim: true,
        },
        image: {
            type: String,
            default: '',
        },
        durationMinutes: {
            type: Number,
            default: 15,
        },
        price: {
            type: Number,
            default: 0,
        },
        oldPrice: {
            type: Number,
            default: 0,
        },
        badge: {
            type: String,
            default: '',
        },
        tags: {
            type: [String],
            default: [],
        },
        isGlobal: {
            type: Boolean,
            default: false,
        },
        isActive: {
            type: Boolean,
            default: true,
        },
        isFeatured: {
            type: Boolean,
            default: false,
        },
        sortOrder: {
            type: Number,
            default: 0,
        },
        categoryIds: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: "Category",
            }
        ],
        serviceIds: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: "Product",
            }
        ],
    },
    { timestamps: true }
);

addOnSchema.index({ isActive: 1, sortOrder: 1, createdAt: -1 });

const AddOnModel = mongoose.model("AddOn", addOnSchema);

export default AddOnModel;
