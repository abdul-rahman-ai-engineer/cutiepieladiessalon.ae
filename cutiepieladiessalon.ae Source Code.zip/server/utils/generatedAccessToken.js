import jwt from 'jsonwebtoken'
import UserModel from "../models/user.model.js";
import { buildUserAccessClaims } from "./admin.utils.js";

const resolveUserForToken = async (userOrId) => {
    if (userOrId && typeof userOrId === "object" && (userOrId._id || userOrId.id)) {
        return userOrId;
    }

    if (!userOrId) {
        return null;
    }

    return UserModel.findById(userOrId).select("role isAdmin").lean();
};

const generatedAccessToken = async (userOrId) => {
    const resolvedUser = await resolveUserForToken(userOrId);
    const resolvedUserId = resolvedUser?._id || resolvedUser?.id || userOrId;
    const token = await jwt.sign(
        buildUserAccessClaims({
            ...(resolvedUser || {}),
            _id: resolvedUserId,
        }),
        process.env.SECRET_KEY_ACCESS_TOKEN,
        { expiresIn: '24h' }
    )

    return token
}

export default generatedAccessToken
