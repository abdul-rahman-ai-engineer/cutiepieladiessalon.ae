import AddOnModel from "../models/addon.model.js";
import ProductModel from "../models/product.modal.js";

const voucherMap = {
    GLOW10: {
        label: "Glow welcome voucher",
        type: "percent",
        value: 10,
    },
    SALON15: {
        label: "Salon loyalty voucher",
        type: "percent",
        value: 15,
    },
    DUBAI25: {
        label: "Dubai flat voucher",
        type: "flat",
        value: 25,
    },
};

const toCurrencyAmount = (value) => Number(Number(value || 0).toFixed(2));

export const normalizeId = (value) => {
    if (!value) return "";
    return typeof value === "string" ? value : value.toString();
};

export const serializeService = (service) => ({
    _id: service._id,
    id: normalizeId(service._id),
    name: service.name || "",
    description: service.description || "",
    shortDescription: service.shortDescription || service.description || "",
    images: Array.isArray(service.images) ? service.images : [],
    primaryImage: service?.images?.[0] || "",
    price: Number(service.price || 0),
    oldPrice: Number(service.oldPrice || 0),
    brand: service.brand || "Cutie Pie Beauty Salon",
    catName: service.catName || service?.catId?.name || "",
    subCat: service.subCat || service?.subCatId?.name || "",
    thirdsubCat: service.thirdsubCat || service?.thirdsubCatId?.name || "",
    rating: Number(service.rating || 0),
    ratingCount: Number(service.ratingCount || 0),
    discount: Number(service.discount || 0),
    badge: service.badge || "",
    durationMinutes: Number(service.durationMinutes || 60),
    instantDurationMinutes: Number(service.instantDurationMinutes || 30),
    bookingEnabled: service.bookingEnabled !== false,
    locationType: service.locationType || "home",
    serviceFee: Number(service.serviceFee || 12),
    highlights: Array.isArray(service.highlights) ? service.highlights : [],
    includes: Array.isArray(service.includes) ? service.includes : [],
    benefits: Array.isArray(service.benefits) ? service.benefits : [],
    tags: Array.isArray(service.tags) ? service.tags : [],
    faqs: Array.isArray(service.faqs) ? service.faqs : [],
    availabilityWindow: service.availabilityWindow || {
        startHour: 10,
        endHour: 22,
        intervalMinutes: 30,
    },
    addOnIds: Array.isArray(service.addOnIds) ? service.addOnIds.map((item) => normalizeId(item?._id || item)) : [],
    professionalIds: Array.isArray(service.professionalIds) ? service.professionalIds.map((item) => normalizeId(item?._id || item)) : [],
});

export const serializeAddOn = (addOn) => ({
    _id: addOn._id,
    id: normalizeId(addOn._id),
    name: addOn.name || "",
    description: addOn.description || "",
    image: addOn.image || "",
    durationMinutes: Number(addOn.durationMinutes || 0),
    price: Number(addOn.price || 0),
    oldPrice: Number(addOn.oldPrice || 0),
    badge: addOn.badge || "",
    tags: Array.isArray(addOn.tags) ? addOn.tags : [],
    isFeatured: Boolean(addOn.isFeatured),
    isGlobal: Boolean(addOn.isGlobal),
    isActive: addOn.isActive !== false,
    categoryIds: Array.isArray(addOn.categoryIds) ? addOn.categoryIds.map((item) => normalizeId(item?._id || item)) : [],
    serviceIds: Array.isArray(addOn.serviceIds) ? addOn.serviceIds.map((item) => normalizeId(item?._id || item)) : [],
});

export const serializeProfessional = (professional) => ({
    _id: professional._id,
    id: normalizeId(professional._id),
    name: professional.name || "",
    title: professional.title || "",
    avatar: professional.avatar || "",
    bio: professional.bio || "",
    rating: Number(professional.rating || 0),
    reviewCount: Number(professional.reviewCount || 0),
    yearsExperience: Number(professional.yearsExperience || 0),
    responseTimeMinutes: Number(professional.responseTimeMinutes || 30),
    city: professional.city || "Dubai",
    languages: Array.isArray(professional.languages) ? professional.languages : [],
    specialties: Array.isArray(professional.specialties) ? professional.specialties : [],
    badges: Array.isArray(professional.badges) ? professional.badges : [],
    isAutoAssignable: professional.isAutoAssignable !== false,
});

const formatTime = (totalMinutes) => {
    const safeMinutes = Math.max(0, Number(totalMinutes || 0));
    const hours = Math.floor(safeMinutes / 60);
    const minutes = safeMinutes % 60;
    return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
};

export const buildAvailabilityCalendar = (service, days = 7) => {
    const windowConfig = service?.availabilityWindow || {};
    const startHour = Number(windowConfig.startHour ?? 10);
    const endHour = Number(windowConfig.endHour ?? 22);
    const intervalMinutes = Number(windowConfig.intervalMinutes ?? 30);
    const durationMinutes = Number(service?.durationMinutes || 60);
    const instantDurationMinutes = Number(service?.instantDurationMinutes || 30);
    const calendar = [];

    for (let dayIndex = 0; dayIndex < days; dayIndex += 1) {
        const date = new Date();
        date.setHours(0, 0, 0, 0);
        date.setDate(date.getDate() + dayIndex);

        const slots = [];
        const startTotalMinutes = startHour * 60;
        const endTotalMinutes = Math.max(startTotalMinutes + intervalMinutes, endHour * 60);

        for (let current = startTotalMinutes; current + durationMinutes <= endTotalMinutes; current += intervalMinutes) {
            const start = formatTime(current);
            const end = formatTime(current + durationMinutes);

            slots.push({
                label: `${start}-${end}`,
                start,
                end,
            });
        }

        calendar.push({
            value: date.toISOString().slice(0, 10),
            label: date.toLocaleDateString("en-GB", {
                day: "numeric",
                month: "short",
            }),
            dayName: date.toLocaleDateString("en-GB", {
                weekday: "short",
            }),
            instantOption: {
                label: `Instant (${instantDurationMinutes} mins)`,
                start: "ASAP",
                end: `${instantDurationMinutes} mins`,
            },
            slots,
        });
    }

    return calendar;
};

const getVoucherMeta = (voucherCode = "") => {
    const normalizedCode = String(voucherCode || "").trim().toUpperCase();
    if (!normalizedCode) {
        return {
            code: "",
            label: "",
            type: "",
            amount: 0,
        };
    }

    const voucher = voucherMap[normalizedCode];
    if (!voucher) {
        return {
            code: normalizedCode,
            label: "Unknown voucher",
            type: "invalid",
            amount: 0,
        };
    }

    return {
        code: normalizedCode,
        label: voucher.label,
        type: voucher.type,
        amount: voucher.value,
    };
};

export const calculateVoucherDiscount = (subtotal, voucherCode = "") => {
    const meta = getVoucherMeta(voucherCode);

    if (!meta.code || meta.type === "invalid") {
        return {
            ...meta,
            discountAmount: 0,
        };
    }

    let discountAmount = 0;
    if (meta.type === "percent") {
        discountAmount = subtotal * (meta.amount / 100);
    } else if (meta.type === "flat") {
        discountAmount = meta.amount;
    }

    return {
        ...meta,
        discountAmount: toCurrencyAmount(Math.min(subtotal, discountAmount)),
    };
};

export const calculateBookingQuote = async ({
    serviceId,
    quantity = 1,
    addOnIds = [],
    instantRequested = false,
    voucherCode = "",
}) => {
    const service = await ProductModel.findById(serviceId).lean();

    if (!service) {
        throw new Error("Selected service could not be found.");
    }

    const selectedQuantity = Math.max(1, Number.parseInt(quantity, 10) || 1);
    const uniqueAddOnIds = Array.from(new Set((Array.isArray(addOnIds) ? addOnIds : []).filter(Boolean)));
    const addOns = uniqueAddOnIds.length
        ? await AddOnModel.find({
            _id: { $in: uniqueAddOnIds },
            isActive: true,
        }).lean()
        : [];

    const serviceBase = toCurrencyAmount(Number(service.price || 0) * selectedQuantity);
    const addOnTotal = toCurrencyAmount(
        addOns.reduce((sum, addOn) => sum + Number(addOn.price || 0), 0) * selectedQuantity
    );
    const subtotal = toCurrencyAmount(serviceBase + addOnTotal);
    const serviceFee = 0;
    const voucher = calculateVoucherDiscount(subtotal, voucherCode);
    const total = toCurrencyAmount(subtotal + serviceFee - Number(voucher.discountAmount || 0));

    return {
        service: serializeService(service),
        addOns: addOns.map(serializeAddOn),
        quantity: selectedQuantity,
        instantRequested: Boolean(instantRequested),
        voucher,
        summary: {
            serviceBase,
            addOnTotal,
            subtotal,
            serviceFee,
            discount: Number(voucher.discountAmount || 0),
            total,
        },
    };
};
