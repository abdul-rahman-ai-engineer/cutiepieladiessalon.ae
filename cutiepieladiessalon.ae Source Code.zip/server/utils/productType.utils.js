const SERVICE_CATEGORY_TOKENS = new Set([
    "nails",
    "facial",
    "hair",
    "hairremoval",
    "massage",
    "combos",
    "combo",
]);

const normalizeCategoryToken = (value = "") =>
    String(value || "")
        .trim()
        .toLowerCase()
        .replace(/[^a-z]/g, "");

export const isServiceCategoryName = (value = "") =>
    SERVICE_CATEGORY_TOKENS.has(normalizeCategoryToken(value));

export const getProductCategoryNames = (product = {}) => ([
    product?.catName,
    product?.subCat,
    product?.thirdsubCat,
    product?.categoryName,
])
    .filter(Boolean);

export const isServiceProduct = (product = {}) => {
    const normalizedType = String(product?.serviceType || "").trim().toLowerCase();

    if (normalizedType === "service") {
        return true;
    }

    if (normalizedType === "product") {
        return false;
    }

    if (getProductCategoryNames(product).some(isServiceCategoryName)) {
        return true;
    }

    return Boolean(
        product?.bookingEnabled === true
        && (
            product?.durationMinutes
            || product?.instantDurationMinutes
            || product?.serviceFee
            || product?.locationType
        )
    );
};

export const isPhysicalProduct = (product = {}) => !isServiceProduct(product);
