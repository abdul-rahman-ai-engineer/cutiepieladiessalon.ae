import UserModel from "../models/user.model.js"
import jwt from 'jsonwebtoken'
import { buildUserAccessClaims } from "./admin.utils.js";

const genertedRefreshToken = async(userOrId)=>{
    const resolvedUser = userOrId && typeof userOrId === "object" && (userOrId._id || userOrId.id)
        ? userOrId
        : await UserModel.findById(userOrId).select("role isAdmin").lean();
    const userId = resolvedUser?._id || resolvedUser?.id || userOrId;

    const token = await jwt.sign(buildUserAccessClaims({
        ...(resolvedUser || {}),
        _id: userId,
    }),
        process.env.SECRET_KEY_REFRESH_TOKEN,
        { expiresIn : '7d'}
    )

    const updateRefreshTokenUser = await UserModel.updateOne(
        { _id : userId},
        {
            refresh_token : token
        }
    )

    return token
}

export default genertedRefreshToken
