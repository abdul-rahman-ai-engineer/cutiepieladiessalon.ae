export const normalizeUserRole = (role = "") => {
    const normalizedRole = String(role || "").trim().toUpperCase();

    return normalizedRole === "ADMIN" ? "ADMIN" : "USER";
};

export const isAdminUser = (user = {}) => {
    if (user?.isAdmin === true) {
        return true;
    }

    return normalizeUserRole(user?.role) === "ADMIN";
};

export const buildUserAccessClaims = (user = {}) => ({
    id: String(user?._id || user?.id || ""),
    role: normalizeUserRole(user?.role),
    isAdmin: isAdminUser(user),
});

export const buildUserAccessProfile = (user = {}) => ({
    role: isAdminUser(user) ? "ADMIN" : normalizeUserRole(user?.role),
    isAdmin: isAdminUser(user),
});
